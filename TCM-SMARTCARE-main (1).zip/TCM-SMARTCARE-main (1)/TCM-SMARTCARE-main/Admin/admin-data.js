(function () {
    const storageKey = "tcmAdminData";
    let cachedData = null;
    let apiInitialized = false;
    let saveQueue = Promise.resolve();

    const seedData = {
        staff: [
            {
                id: "staff-frontdesk",
                staffId: "staff001",
                email: "staff@tcmsmartcare.com",

                name: "Front Desk Staff",
                role: "staff",
                avatar: "FS"
            }
        ],
        doctors: [
            {
                id: "dr-lim",
                staffId: "doctor001",
                email: "lim@tcmsmartcare.com",

                name: "Dr. Lim Wei Ming",
                role: "doctor",
                avatar: "LW",
                services: ["TCM Consultation", "Acupuncture"]
            },
            {
                id: "dr-tan",
                staffId: "doctor002",
                email: "tan@tcmsmartcare.com",

                name: "Dr. Tan Mei Ling",
                role: "doctor",
                avatar: "TM",
                services: ["TCM Consultation", "Herbal Medicine"]
            },
            {
                id: "dr-wong",
                staffId: "doctor003",
                email: "wong@tcmsmartcare.com",

                name: "Dr. Wong Jun Hao",
                role: "doctor",
                avatar: "WJ",
                services: ["Acupuncture", "Cupping"]
            }
        ],
        patients: [
            {
                id: "PAT-001",
                name: "Jamie Lee",
                email: "jamie@example.com",
                phone: "012-345 6789",
                joined: "2026-09-12",
                lastVisit: "2026-10-01",
                preConsultation: {
                    submitted: true,
                    energy: "Steady",
                    sleep: "Difficulty sleeping",
                    digestion: "Generally comfortable",
                    temperature: "Often feels cold",
                    mood: "High stress",
                    concerns: "Neck and shoulder discomfort",
                    notes: "Tight shoulders after long computer work."
                }
            },
            {
                id: "PAT-002",
                name: "Sarah Tan",
                email: "sarah@example.com",
                phone: "011-234 8899",
                joined: "2026-08-20",
                lastVisit: "2026-09-28",
                preConsultation: {
                    submitted: true,
                    energy: "Afternoon dips",
                    sleep: "Restful",
                    digestion: "Bloating after meals",
                    temperature: "Usually comfortable",
                    mood: "Balanced",
                    concerns: "None selected",
                    notes: "Wants lifestyle guidance."
                }
            },
            {
                id: "PAT-003",
                name: "Alex Wong",
                email: "alex@example.com",
                phone: "017-555 1200",
                joined: "2026-07-18",
                lastVisit: "2026-09-15",
                preConsultation: { submitted: false }
            }
        ],
        appointments: [
            {
                id: "APT-001",
                patientId: "PAT-001",
                patient: "Jamie Lee",
                contact: "012-345 6789",
                service: "TCM Consultation",
                date: "2026-10-06",
                time: "09:00",
                endTime: "09:30",
                doctorId: "dr-lim",
                doctor: "Dr. Lim Wei Ming",
                room: "Room 02",
                status: "Checked In"
            },
            {
                id: "APT-002",
                patientId: "PAT-002",
                patient: "Sarah Tan",
                contact: "011-234 8899",
                service: "Acupuncture",
                date: "2026-10-06",
                time: "10:00",
                endTime: "10:30",
                doctorId: "dr-tan",
                doctor: "Dr. Tan Mei Ling",
                room: "Room 01",
                status: "Scheduled"
            },
            {
                id: "APT-003",
                patientId: "PAT-003",
                patient: "Alex Wong",
                contact: "017-555 1200",
                service: "Cupping",
                date: "2026-10-06",
                time: "11:00",
                endTime: "11:30",
                doctorId: "dr-wong",
                doctor: "Dr. Wong Jun Hao",
                room: "Room 03",
                status: "Scheduled"
            },
            {
                id: "APT-004",
                patientId: "PAT-001",
                patient: "Jamie Lee",
                contact: "012-345 6789",
                service: "Herbal Medicine",
                date: "2026-10-07",
                time: "14:00",
                endTime: "14:30",
                doctorId: "dr-tan",
                doctor: "Dr. Tan Mei Ling",
                room: "Room 01",
                status: "Completed"
            }
        ],
        schedules: [
            {
                doctorId: "dr-lim",
                workingDays: ["Monday", "Wednesday", "Friday"],
                morningStart: "09:00",
                morningEnd: "12:00",
                afternoonStart: "14:00",
                afternoonEnd: "18:00",
                slotDuration: 30,
                capacity: 1,
                unavailable: []
            },
            {
                doctorId: "dr-tan",
                workingDays: ["Tuesday", "Thursday", "Saturday"],
                morningStart: "09:00",
                morningEnd: "12:00",
                afternoonStart: "14:00",
                afternoonEnd: "18:00",
                slotDuration: 30,
                capacity: 1,
                unavailable: []
            },
            {
                doctorId: "dr-wong",
                workingDays: ["Monday", "Tuesday", "Friday"],
                morningStart: "10:00",
                morningEnd: "12:00",
                afternoonStart: "14:00",
                afternoonEnd: "17:00",
                slotDuration: 30,
                capacity: 1,
                unavailable: []
            }
        ],
        products: [
            {
                id: "PROD-001",
                name: "Premium Bird's Nest",
                category: "Bird's Nest",
                description: "Wellness product for general nourishment.",
                price: 89,
                stock: 20,
                lowStockThreshold: 5,
                image: "",
                status: "Active",
                updatedAt: "2026-10-06"
            },
            {
                id: "PROD-002",
                name: "Ginseng Tea",
                category: "Ginseng",
                description: "Herbal tea for daily wellness routines.",
                price: 25,
                stock: 4,
                lowStockThreshold: 5,
                image: "",
                status: "Active",
                updatedAt: "2026-10-06"
            },
            {
                id: "PROD-003",
                name: "Chrysanthemum Tea",
                category: "Herbal Tea",
                description: "Traditional herbal drink.",
                price: 16,
                stock: 12,
                lowStockThreshold: 5,
                image: "",
                status: "Active",
                updatedAt: "2026-10-05"
            },
            {
                id: "PROD-004",
                name: "Herbal Care Balm",
                category: "Wellness",
                description: "Topical care product for demo use.",
                price: 20,
                stock: 2,
                lowStockThreshold: 5,
                image: "",
                status: "Active",
                updatedAt: "2026-10-04"
            }
        ],
        orders: [
            {
                id: "DEMO-170001",
                customer: "Jamie Lee",
                phone: "012-345 6789",
                date: "2026-10-06",
                items: [
                    { productId: "PROD-001", name: "Premium Bird's Nest", quantity: 1, price: 89 },
                    { productId: "PROD-002", name: "Ginseng Tea", quantity: 2, price: 25 }
                ],
                total: 139,
                paymentMethod: "FPX",
                status: "Pending Packing",
                courier: "",
                tracking: ""
            },
            {
                id: "DEMO-170002",
                customer: "Sarah Tan",
                phone: "011-234 8899",
                date: "2026-10-06",
                items: [{ productId: "PROD-003", name: "Chrysanthemum Tea", quantity: 1, price: 16 }],
                total: 16,
                paymentMethod: "Card",
                status: "Paid",
                courier: "",
                tracking: ""
            },
            {
                id: "DEMO-170003",
                customer: "Alex Wong",
                phone: "017-555 1200",
                date: "2026-10-05",
                items: [{ productId: "PROD-004", name: "Herbal Care Balm", quantity: 1, price: 20 }],
                total: 20,
                paymentMethod: "eWallet",
                status: "Pending Packing",
                courier: "",
                tracking: ""
            }
        ],
        messages: [
            {
                id: "MSG-001",
                patient: "Jamie Lee",
                doctorId: "dr-lim",
                category: "Appointment",
                unread: 2,
                lastTime: "10:42 AM",
                messages: [
                    { from: "patient", text: "Can I change my appointment?", time: "10:40 AM" },
                    { from: "staff", text: "Yes, we can help you reschedule.", time: "10:42 AM" }
                ]
            },
            {
                id: "MSG-002",
                patient: "Sarah Tan",
                doctorId: "dr-tan",
                category: "General",
                unread: 0,
                lastTime: "Yesterday",
                messages: [{ from: "patient", text: "Thank you for the appointment confirmation.", time: "Yesterday" }]
            }
        ],
        carePlans: [
            {
                id: "CARE-001",
                appointmentId: "APT-001",
                patientId: "PAT-001",
                doctorId: "dr-lim",
                status: "Saved",
                createdAt: "2026-10-06T09:20:00.000Z",
                notes: {
                    notes: "Neck and shoulder tightness with sleep difficulty. Advise warm compress and posture breaks.",
                    wang: "Pale tongue, slight teeth marks",
                    wen: "Shoulder tension after desk work",
                    questioning: "Sleep interrupted, stress high",
                    qie: "Pulse wiry",
                    recommendation: "Gentle stretching, reduce cold drinks, review sleep in follow-up.",
                    productId: "PROD-002",
                    quantity: "2 packs",
                    daysSupply: "7 days",
                    usage: "Drink once daily after meals",
                    productNotes: "Ginseng Tea for short-term support.",
                    followUp: "7 days",
                    followUpDate: ""
                }
            }
        ],
        feedback: [
            {
                id: "FDB-001",
                patient: "Jamie Lee",
                service: "TCM Consultation",
                doctorId: "dr-lim",
                doctor: "Dr. Lim Wei Ming",
                rating: 5,
                comment: "Very helpful consultation.",
                date: "2026-10-06",
                status: "Visible"
            }
        ],
        announcements: []
    };

    function mergePatientMessages(data) {
        let patientMessages;

        try {
            patientMessages = JSON.parse(
                localStorage.getItem("tcmMessages") || "{}"
            );
        } catch (error) {
            console.error("Could not read patient messages.", error);
            return;
        }

        if (!patientMessages || Array.isArray(patientMessages)) return;
        if (!Array.isArray(data.messages)) data.messages = [];

        Object.entries(patientMessages).forEach(([email, conversations]) => {
            if (!Array.isArray(conversations)) return;

            conversations.forEach((conversation) => {
                if (
                    !conversation ||
                    !conversation.id ||
                    !Array.isArray(conversation.messages) ||
                    conversation.messages.length === 0
                ) {
                    return;
                }

                const id = `PATIENT-${encodeURIComponent(email)}-${encodeURIComponent(conversation.id)}`;
                const thread = {
                    id,
                    patient: conversation.patientName || email,
                    patientEmail: email,
                    patientConversationId: conversation.id,
                    doctorId: conversation.id.startsWith("dr-")
                        ? conversation.id
                        : "",
                    category: conversation.id === "care-team" ? "General" : "Consultation",
                    unread: Number(conversation.staffUnread) || 0,
                    lastTime: conversation.messages.at(-1)?.time || "",
                    messages: conversation.messages.map((message) => ({
                        from: message.from === "me" ? "patient" : "staff",
                        text: String(message.text || ""),
                        time: String(message.time || "")
                    }))
                };

                const existingIndex = data.messages.findIndex(
                    (item) => item.id === id
                );

                if (existingIndex === -1) {
                    data.messages.push(thread);
                } else {
                    data.messages[existingIndex] = {
                        ...data.messages[existingIndex],
                        ...thread
                    };
                }
            });
        });
    }

    function syncPatientMessages(data) {
        const patientMessages = JSON.parse(
            localStorage.getItem("tcmMessages") || "{}"
        );

        if (!patientMessages || Array.isArray(patientMessages)) return;

        data.messages.forEach((thread) => {
            if (!thread.patientEmail || !thread.patientConversationId) return;

            const conversations = patientMessages[thread.patientEmail];
            const conversation = Array.isArray(conversations)
                ? conversations.find(
                    (item) => item.id === thread.patientConversationId
                )
                : null;
            if (!conversation) return;

            const oldMessages = Array.isArray(conversation.messages)
                ? conversation.messages
                : [];
            const newReplies = thread.messages
                .slice(oldMessages.length)
                .filter((message) => message.from !== "patient").length;

            conversation.messages = thread.messages.map((message) => ({
                from: message.from === "patient" ? "me" : "them",
                text: String(message.text || ""),
                time: String(message.time || "")
            }));
            conversation.staffUnread = Number(thread.unread) || 0;
            conversation.userUnread =
                (Number(conversation.userUnread) || 0) + newReplies;
            conversation.unread = conversation.userUnread;
        });

        localStorage.setItem("tcmMessages", JSON.stringify(patientMessages));
    }

    function loadLocal() {
        let data;

        try {
            const saved = JSON.parse(localStorage.getItem(storageKey) || "null");
            data = saved || structuredClone(seedData);
        } catch {
            data = structuredClone(seedData);
        }

        try {
            const purchaseHistory = JSON.parse(
                localStorage.getItem("tcmPurchaseHistory") || "[]"
            );

            if (!Array.isArray(purchaseHistory)) {
                throw new Error("Purchase history data is invalid.");
            }

            if (!Array.isArray(data.orders)) data.orders = [];

            const existingOrderIds = new Set(
                data.orders.map((order) => String(order.id))
            );
            let importedOrders = false;

            purchaseHistory.forEach((order) => {
                if (
                    !order ||
                    !order.orderNumber ||
                    !Array.isArray(order.items) ||
                    existingOrderIds.has(String(order.orderNumber))
                ) {
                    return;
                }

                const method = String(order.paymentMethod || "").toLowerCase();
                const paymentMethod = method.includes("fpx")
                    ? "FPX"
                    : method.includes("card")
                        ? "Card"
                        : method.includes("ewallet") || method.includes("e-wallet")
                            ? "eWallet"
                            : order.paymentMethod || "Other";

                data.orders.push({
                    id: String(order.orderNumber),
                    customer: order.buyer?.name || "Patient",
                    phone: order.buyer?.phone || "",
                    date: String(order.purchasedAt || "").slice(0, 10),
                    items: order.items.map((item) => ({
                        ...item,
                        name: String(item?.name || "Product"),
                        quantity: Number(item?.quantity) || 0,
                        price: Number(item?.price) || 0
                    })),
                    total: Number(order.total) || 0,
                    paymentMethod,
                    status: "Pending Packing",
                    courier: "",
                    tracking: ""
                });

                existingOrderIds.add(String(order.orderNumber));
                importedOrders = true;
            });

            if (importedOrders) {
                localStorage.setItem(storageKey, JSON.stringify(data));
            }
        } catch (error) {
            console.error("Could not import customer purchase history.", error);
        }

        let migratedAppointmentStatuses = false;
        if (Array.isArray(data.appointments)) {
            data.appointments.forEach((appointment) => {
                if (["Pending Confirmation", "Confirmed"].includes(appointment.status)) {
                    appointment.status = "Scheduled";
                    migratedAppointmentStatuses = true;
                } else if (appointment.status === "Waiting") {
                    appointment.status = "Checked In";
                    migratedAppointmentStatuses = true;
                }
            });
        }
        if (migratedAppointmentStatuses) {
            localStorage.setItem(storageKey, JSON.stringify(data));
        }

        mergePatientMessages(data);
        return data;
    }

    function load() {
        return cachedData || loadLocal();
    }

    function safeForBrowser(data) {
        const copy = structuredClone(data);
        // Private clinical details only live in authenticated SQL responses, not localStorage.
        copy.carePlans = [];
        (copy.patients || []).forEach((patient) => { patient.preConsultation = { submitted: false }; });
        ["staff", "doctors"].forEach((key) => {
            (copy[key] || []).forEach((account) => delete account.password);
        });
        return copy;
    }

    function setCachedData(data) {
        cachedData = data;
        localStorage.setItem(storageKey, JSON.stringify(safeForBrowser(data)));
    }

    function restore(data) {
        cachedData = data;
        localStorage.setItem(storageKey, JSON.stringify(safeForBrowser(data)));
    }

    async function initialize(loadRemote = true) {
        if (!loadRemote) return;
        const dataResponse = await fetch("/api/admin/data", {
            credentials: "same-origin",
            cache: "no-store"
        });
        if (!dataResponse.ok) {
            const result = await dataResponse.json().catch(() => ({}));
            throw new Error(result.detail || "Could not load admin data from the database.");
        }
        const result = await dataResponse.json();
        setCachedData(result.data);
        mergePatientMessages(cachedData);
        apiInitialized = true;
    }

    function save(data) {
        cachedData = data;
        localStorage.setItem(storageKey, JSON.stringify(safeForBrowser(data)));
        syncPatientMessages(data);

        if (!apiInitialized) return Promise.resolve(true);

        const snapshot = structuredClone(data);
        saveQueue = saveQueue.then(async () => {
            const response = await fetch("/api/admin/data", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ data: snapshot })
            });
            if (!response.ok) {
                const result = await response.json().catch(() => ({}));
                throw new Error(result.detail || "Could not save admin data to the database.");
            }
            return true;
        }).catch((error) => {
            window.dispatchEvent(new CustomEvent("tcm-admin-api-error", {
                detail: error?.message || "Could not save admin data to the database."
            }));
            return false;
        });
        return saveQueue;
    }

    function reset() {
        const data = structuredClone(seedData);
        save(data);
        return data;
    }

    window.TcmAdminData = { load, save, reset, initialize, restore, seedData };
})();
