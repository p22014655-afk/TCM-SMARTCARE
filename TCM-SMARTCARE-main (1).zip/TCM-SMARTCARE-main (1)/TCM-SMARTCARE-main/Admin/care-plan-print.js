(() => {
    const escapeText = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
    const tidy = value => String(value ?? "").trim();
    const fieldValue = (form, name) => tidy(form?.elements.namedItem(name)?.value);
    const displayValue = value => escapeText(tidy(value) || "Not recorded");
    const formatDate = value => {
        const raw = tidy(value);
        if (!raw) return "Not provided";
        const match = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (!match) return raw;
        const day = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
        return day.toLocaleDateString("en-MY", {day:"numeric",month:"long",year:"numeric"});
    };
    const formatTime = value => {
        const match = tidy(value).match(/^(\d{1,2}):(\d{2})/);
        if (!match) return tidy(value) || "Not provided";
        const hour = Number(match[1]);
        return `${hour % 12 || 12}:${match[2]} ${hour >= 12 ? "PM" : "AM"}`;
    };
    const printSection = (number, title, text, secondary = "") => `
        <section class="tcm-print-section">
            <div class="tcm-print-section-title"><span>${number}</span><h2>${escapeText(title)}</h2></div>
            <div class="tcm-print-section-body">${displayValue(text)}</div>
            ${secondary ? `<p class="tcm-print-section-foot">${escapeText(secondary)}</p>` : ""}
        </section>`;
    const printStyle = `
        <style id="tcm-care-plan-print-style">
            #tcm-care-plan-print {display:none}
            @page {size:A4 portrait;margin:11mm 14mm 12mm}
            @media print {
                html,body {margin:0!important;padding:0!important;overflow:visible!important;background:#fff!important;width:auto!important;height:auto!important}
                body>*:not(#tcm-care-plan-print) {display:none!important}
                #tcm-care-plan-print {display:block!important;position:static!important;visibility:visible!important;margin:0!important;padding:0!important;max-width:none!important;background:#fff!important;color:#173c35!important;font-family:Arial,Helvetica,sans-serif!important;font-size:10pt!important;line-height:1.42!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
                #tcm-care-plan-print * {box-sizing:border-box!important;box-shadow:none!important}
                #tcm-care-plan-print .tcm-print-banner {display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2.5px solid #206550;padding-bottom:9px;margin-bottom:13px;gap:14px}
                #tcm-care-plan-print .tcm-print-brand {font-weight:800;font-size:17pt;color:#165545;letter-spacing:-.6px}
                #tcm-care-plan-print .tcm-print-brand span {color:#7daf9f}
                #tcm-care-plan-print .tcm-print-subbrand {margin-top:3px;color:#73867f;font-size:8pt;letter-spacing:1.4px;text-transform:uppercase}
                #tcm-care-plan-print .tcm-print-document {text-align:right;min-width:160px}
                #tcm-care-plan-print .tcm-print-document h1 {margin:0;color:#173c35;font-size:16pt;font-weight:800;line-height:1.2}
                #tcm-care-plan-print .tcm-print-document p {margin:5px 0 0;font-size:8pt;color:#71847c}
                #tcm-care-plan-print .tcm-print-meta {display:grid;grid-template-columns:1fr 1fr;gap:0 14px;border:1px solid #d8e8e1;border-radius:8px;overflow:hidden;margin-bottom:13px}
                #tcm-care-plan-print .tcm-print-meta-item {padding:7px 10px;border-bottom:1px solid #e5efea;min-height:40px;break-inside:avoid}
                #tcm-care-plan-print .tcm-print-meta-item:nth-last-child(-n+2) {border-bottom:0}
                #tcm-care-plan-print .tcm-print-meta-item:nth-child(4n+1),#tcm-care-plan-print .tcm-print-meta-item:nth-child(4n+2) {background:#f4f9f6}
                #tcm-care-plan-print .tcm-print-label {display:block;color:#62796f;font-size:7.5pt;letter-spacing:.45px;text-transform:uppercase;margin-bottom:4px;font-weight:700}
                #tcm-care-plan-print .tcm-print-value {color:#193d35;font-size:10pt;font-weight:700;overflow-wrap:anywhere}
                #tcm-care-plan-print .tcm-print-section {border:1px solid #dce9e2;border-radius:8px;overflow:hidden;margin:0 0 8px;break-inside:avoid-page;page-break-inside:avoid}
                #tcm-care-plan-print .tcm-print-section-title {display:flex;align-items:center;gap:9px;background:#eaf4ee;border-bottom:1px solid #dce9e2;padding:6px 10px}
                #tcm-care-plan-print .tcm-print-section-title span {display:inline-flex;align-items:center;justify-content:center;background:#206550;border-radius:5px;width:22px;height:22px;color:white;font-size:8pt;font-weight:700}
                #tcm-care-plan-print .tcm-print-section-title h2 {font-size:10.5pt;margin:0;font-weight:800;color:#214d3d}
                #tcm-care-plan-print .tcm-print-section-body {padding:8px 11px;white-space:pre-wrap;overflow-wrap:anywhere;word-break:normal;min-height:36px;line-height:1.5}
                #tcm-care-plan-print .tcm-print-section-foot {margin:0;padding:0 12px 10px;color:#697e75;font-size:8pt}
                #tcm-care-plan-print .tcm-print-pretitle {margin:10px 0 6px;color:#245543;font-size:10pt;font-weight:800;letter-spacing:.2px}
                #tcm-care-plan-print .tcm-print-pregrid {display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:7px}
                #tcm-care-plan-print .tcm-print-preitem {border:1px solid #e3ece7;border-radius:6px;padding:6px;break-inside:avoid-page;background:#fff}
                #tcm-care-plan-print .tcm-print-prevalue {white-space:pre-wrap;overflow-wrap:anywhere;font-size:8.8pt}
                #tcm-care-plan-print .tcm-print-footer {border-top:1px solid #d8e8e1;margin-top:10px;padding-top:7px;display:flex;justify-content:space-between;gap:12px;font-size:8pt;color:#687c73;break-inside:avoid-page}
                #tcm-care-plan-print .tcm-print-flag {background:#fff4e7;color:#875720;font-size:8pt;padding:8px 10px;border:1px solid #eed7b4;border-radius:5px;margin:0 0 10px}
            }
        </style>`;

    function loadPrintData() {
        const form = document.getElementById("carePlanForm");
        const selected = document.querySelector("#carePlanList .selected-row [data-select-care]");
        const appointmentId = selected?.dataset.selectCare;
        const state = window.TcmAdminData?.load?.();
        const appointment = state?.appointments?.find(item => item.id === appointmentId);
        if (!form || !appointment) return null;
        const patient = state.patients?.find(item => item.id === appointment.patientId);
        const records = state.carePlans?.filter(item => item.appointmentId === appointment.id) || [];
        const latest = records.sort((a,b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))[0];
        const notes = {
            notes:fieldValue(form,"notes"),
            careInstructions:fieldValue(form,"careInstructions"),
            formula:fieldValue(form,"formula"),
            daysSupply:fieldValue(form,"daysSupply"),
            followUpRecommendation:fieldValue(form,"followUpRecommendation")
        };
        const saved = latest?.notes || {};
        const changed = ["notes","careInstructions","formula","daysSupply","followUpRecommendation"].some(key => tidy(saved[key]) !== notes[key]);
        return {appointment,patient,notes,latest,changed};
    }

    function prepareDocument({appointment,patient,notes,latest,changed}) {
        const createdOn = new Date().toLocaleString("en-MY",{year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"});
        const doctor = tidy(appointment.doctor) || tidy(document.getElementById("adminName")?.textContent) || "Not assigned";
        const pre = patient?.preConsultation || {};
        const preFields = [
            ["Age",pre.age],["Concern duration",pre.duration],["Energy",pre.energy],
            ["Sleep",pre.sleep],["Digestion",pre.digestion],["Temperature",pre.temperature],
            ["Mood",pre.mood],["Concerns",pre.concerns],["Additional notes",pre.notes]
        ].filter(([,value])=>tidy(value));
        const meta = [
            ["Patient name",patient?.name || appointment.patient],
            ["Patient ID",patient?.id || appointment.patientId],
            ["Appointment ID",appointment.id],
            ["Appointment date",formatDate(appointment.date)],
            ["Appointment time",[formatTime(appointment.time),appointment.endTime ? formatTime(appointment.endTime) : ""].filter(Boolean).join(" - ")],
            ["Doctor",doctor],
            ["Service",appointment.service],
            ["Appointment status",appointment.status]
        ];
        const showDraft = !latest || changed;
        const rootHtml = `
            <div class="tcm-print-banner">
                <div><div class="tcm-print-brand">TCM SMARTCARE<span>+</span></div><div class="tcm-print-subbrand">Traditional Chinese Medicine Clinic</div></div>
                <div class="tcm-print-document"><h1>Clinical Care Plan</h1><p>Prepared ${escapeText(createdOn)}</p></div>
            </div>
            ${showDraft ? '<div class="tcm-print-flag">Print preview of the current form. Some changes may not have been saved to the clinic database.</div>' : ""}
            <div class="tcm-print-meta">${meta.map(([label,value])=>`<div class="tcm-print-meta-item"><span class="tcm-print-label">${escapeText(label)}</span><span class="tcm-print-value">${displayValue(value)}</span></div>`).join("")}</div>
            ${printSection("01","Doctor Consultation — Patient Problem",notes.notes)}
            ${printSection("02","Care Instructions for Staff",notes.careInstructions)}
            ${printSection("03","Traditional Chinese Medicine / Medicine to Prepare",notes.formula)}
            ${printSection("04","Medicine Supply",notes.daysSupply)}
            ${printSection("05","Follow-up Recommendation",notes.followUpRecommendation)}
            ${preFields.length ? `<h2 class="tcm-print-pretitle">Patient pre-consultation summary</h2><div class="tcm-print-pregrid">${preFields.map(([label,value])=>`<div class="tcm-print-preitem"><span class="tcm-print-label">${escapeText(label)}</span><div class="tcm-print-prevalue">${escapeText(value)}</div></div>`).join("")}</div>` : ""}
            <div class="tcm-print-footer"><span>Confidential patient care document · TCM SmartCare+</span><span>${escapeText(appointment.id)} · ${escapeText(createdOn)}</span></div>
        `;
        let root = document.getElementById("tcm-care-plan-print");
        if (!root) {
            root = document.createElement("div");
            root.id = "tcm-care-plan-print";
            root.setAttribute("aria-hidden","true");
            document.body.appendChild(root);
        }
        root.innerHTML = rootHtml;
        if (!document.getElementById("tcm-care-plan-print-style")) document.head.insertAdjacentHTML("beforeend", printStyle);
    }

    let originalTitle = null;
    window.addEventListener("afterprint", () => {
        if (originalTitle !== null) {
            document.title = originalTitle;
            originalTitle = null;
        }
    });
    document.addEventListener("click", event => {
        const button = event.target.closest?.("#printCarePlan");
        if (!button) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        const current = loadPrintData();
        if (!current) {
            window.alert("Please select a patient appointment and open the Care Plan before printing.");
            return;
        }
        prepareDocument(current);
        originalTitle = document.title;
        document.title = `TCM-Care-Plan-${current.appointment.id}`;
        window.requestAnimationFrame(() => window.print());
    }, true);
})();
