(() => {
    const isAdmin = location.pathname.startsWith('/Admin/');
    const prefix = isAdmin ? '/api/admin' : '/api/user';
    const root = document.getElementById('notificationList');
    const count = document.getElementById('notificationCount');
    const tabs = document.querySelectorAll('[data-notification-filter]');
    const markAll = document.getElementById('markAllRead');
    const symbols = {announcement:'📢',order:'📦',appointment:'✓'};
    const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
    let items = [];
    let active = 'all';
    let returnFocus = null;

    const overlay = document.createElement('div');
    overlay.className = 'notification-dialog-backdrop';
    overlay.hidden = true;
    overlay.innerHTML = `<section class="notification-dialog" role="dialog" aria-modal="true" aria-labelledby="notificationDetailTitle" aria-describedby="notificationDetailBody" tabindex="-1"><div class="notification-dialog-header"><span class="notification-dialog-category" id="notificationDetailType"></span><button type="button" class="notification-dialog-close" aria-label="Close notification">×</button></div><h2 id="notificationDetailTitle"></h2><time id="notificationDetailTime"></time><div class="notification-dialog-body" id="notificationDetailBody"></div><p class="notification-dialog-error" id="notificationDetailError" hidden></p><div class="notification-dialog-actions"><a class="notification-dialog-target" id="notificationDetailTarget" hidden></a><button type="button" class="notification-dialog-done">Close</button></div></section>`;
    document.body.append(overlay);
    const dialog = overlay.querySelector('.notification-dialog');
    const detailType = overlay.querySelector('#notificationDetailType');
    const detailTitle = overlay.querySelector('#notificationDetailTitle');
    const detailTime = overlay.querySelector('#notificationDetailTime');
    const detailBody = overlay.querySelector('#notificationDetailBody');
    const detailError = overlay.querySelector('#notificationDetailError');
    const detailTarget = overlay.querySelector('#notificationDetailTarget');

    function formatTime(value) {
        const source = String(value || '');
        const date = new Date(source && !/[zZ]|[+\-]\d\d:\d\d$/.test(source) ? source + 'Z' : source);
        return Number.isNaN(date.getTime()) ? source : date.toLocaleString('en-MY', {dateStyle:'medium',timeStyle:'short'});
    }

    function targetFor(item) {
        const available = isAdmin
            ? {'/Admin/admin-notifications.html':'Notifications'}
            : {'/User/appointments.html':'View my appointments','/User/history.html':'View purchase history','/User/notifications.html':'Notifications'};
        const url = String(item.url || '');
        if (!Object.hasOwn(available, url) || url.endsWith('/notifications.html') || url.endsWith('/admin-notifications.html')) return null;
        return {url, label:available[url]};
    }

    async function request(path, options={}) {
        const response = await fetch(prefix + path, {cache:'no-store',credentials:'same-origin',...options});
        const raw = await response.text();
        let payload;
        try {payload = JSON.parse(raw);} catch {throw new Error('The notifications API did not return valid JSON.');}
        if (!response.ok) throw new Error(typeof payload.detail === 'string' ? payload.detail : `HTTP ${response.status}`);
        return payload;
    }

    function render() {
        const unread = items.filter(item => !item.read).length;
        const filtered = items.filter(item => active !== 'unread' || !item.read);
        count.textContent = `${unread} unread · ${items.length} notifications`;
        markAll.disabled = unread === 0;
        tabs.forEach(tab => {
            const chosen = tab.dataset.notificationFilter === active;
            tab.classList.toggle('selected', chosen);
            tab.setAttribute('aria-pressed', String(chosen));
        });
        if (!filtered.length) {
            root.innerHTML = `<div class="notification-empty">${active === 'unread' ? 'You have no unread notifications.' : 'No notifications yet.'}</div>`;
            return;
        }
        root.innerHTML = filtered.map(item => `<article class="notification-item ${item.read ? '' : 'unread'}"><div class="notification-symbol" aria-hidden="true">${symbols[item.kind] || '•'}</div><div class="notification-copy"><div class="notification-meta"><strong>${escape(item.title)}</strong>${item.read ? '' : '<span class="notification-new">New</span>'}<time>${escape(formatTime(item.createdAt))}</time></div><p>${escape(item.message)}</p><button class="notification-view-button" type="button" data-notification-id="${Number(item.id)}">${item.kind === 'announcement' ? 'View notification' : item.kind === 'order' ? 'View order update' : 'View appointment update'} →</button></div></article>`).join('');
    }

    function closeDialog() {
        if (overlay.hidden) return;
        overlay.hidden = true;
        document.body.classList.remove('notification-dialog-open');
        if (returnFocus && returnFocus.isConnected) returnFocus.focus();
        else document.querySelector('[data-notification-filter="all"]')?.focus();
    }

    async function openDetail(item, trigger) {
        returnFocus = trigger;
        detailType.textContent = item.kind === 'announcement' ? 'Clinic announcement' : item.kind === 'order' ? 'Order update' : 'Appointment update';
        detailTitle.textContent = item.title || 'Notification';
        detailTime.textContent = formatTime(item.createdAt);
        detailBody.textContent = item.message || '';
        detailError.textContent = '';
        detailError.hidden = true;
        const target = targetFor(item);
        detailTarget.hidden = !target;
        if (target) {
            detailTarget.href = target.url;
            detailTarget.textContent = target.label + ' →';
        } else {
            detailTarget.removeAttribute('href');
        }
        overlay.hidden = false;
        document.body.classList.add('notification-dialog-open');
        dialog.focus();
        if (!item.read) {
            try {
                await request(`/notifications/${Number(item.id)}/read`, {method:'POST'});
                item.read = true;
                render();
            } catch (error) {
                detailError.textContent = `Couldn't mark this notification as read: ${error.message}`;
                detailError.hidden = false;
            }
        }
    }

    root.addEventListener('click', event => {
        const button = event.target.closest('[data-notification-id]');
        if (!button) return;
        const item = items.find(entry => Number(entry.id) === Number(button.dataset.notificationId));
        if (item) openDetail(item, button);
    });
    overlay.querySelector('.notification-dialog-close').addEventListener('click', closeDialog);
    overlay.querySelector('.notification-dialog-done').addEventListener('click', closeDialog);
    overlay.addEventListener('click', event => {if (event.target === overlay) closeDialog();});
    document.addEventListener('keydown', event => {
        if (overlay.hidden) return;
        if (event.key === 'Escape') closeDialog();
        if (event.key === 'Tab') {
            const choices = [...overlay.querySelectorAll('button:not([disabled]),a[href]:not([hidden])')];
            if (!choices.length) return;
            if (event.shiftKey && document.activeElement === choices[0]) {event.preventDefault();choices[choices.length - 1].focus();}
            else if (!event.shiftKey && document.activeElement === choices[choices.length - 1]) {event.preventDefault();choices[0].focus();}
        }
    });

    async function load() {
        try {
            const result = await request('/notifications');
            items = Array.isArray(result.notifications) ? result.notifications : [];
            render();
        } catch (error) {
            root.innerHTML = `<div class="notification-error">${escape(error.message)}</div>`;
        }
    }

    tabs.forEach(tab => tab.addEventListener('click', () => {active = tab.dataset.notificationFilter;render();}));
    markAll.addEventListener('click', async () => {
        try {
            await request('/notifications/read-all', {method:'POST'});
            items = items.map(item => ({...item,read:true}));
            render();
        } catch (error) {
            window.alert(error.message);
        }
    });
    load();
    document.addEventListener('visibilitychange', () => {if (!document.hidden) load();});
})();
