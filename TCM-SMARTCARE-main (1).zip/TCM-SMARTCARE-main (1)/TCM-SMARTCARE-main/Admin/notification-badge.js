(() => {
    const admin=location.pathname.startsWith('/Admin/');
    if (admin) {
        const profile = window.TcmAdminAuth?.getCurrentAdmin?.();
        if (profile?.role !== 'doctor') {
            document.querySelectorAll('.notification-dot, .notification-link, button.notification').forEach(element => element.remove());
            return;
        }
    }
    const path=admin?'/Admin/admin-notifications.html':'/User/notifications.html';
    const prefix=admin?'/api/admin':'/api/user';
    const header=document.querySelector('.admin-actions')||document.querySelector('.top-actions')||document.querySelector('.topbar');
    if(!header)return;
    let link=document.querySelector('.notification-link');
    const old=document.querySelector('.notification-dot')||document.querySelector('button.notification');
    if(old){
        link=document.createElement('a');
        link.className=admin?'notification-dot notification-link':'notification notification-link';link.href=path;link.setAttribute('aria-label','Open notifications');
        link.textContent=admin?'':'♧';old.replaceWith(link);
    } else if(!link){
        link=document.createElement('a');link.className='notification-link';link.href=path;
        link.textContent='♧';link.setAttribute('aria-label','Open notifications');
        header.prepend(link);
    }
    async function refresh(){
        try{
            const response=await fetch(prefix+'/notifications',{cache:'no-store',credentials:'same-origin'});
            if(!response.ok)return;
            const data=await response.json();
            const n=Number(data.unreadCount||0);
            let badge=link.querySelector('.notification-link-badge');
            if(n>0){if(!badge){badge=document.createElement('span');badge.className='notification-link-badge';link.append(badge);}badge.textContent=n>99?'99+':String(n);}
            else badge?.remove();
        }catch{}
    }
    refresh();
    setInterval(refresh,30000);
    window.addEventListener('focus',refresh);
})();
