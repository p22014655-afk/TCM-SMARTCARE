(() => {
    let account = null;
    let threads = [];
    let opened = null;
    let selected = "";
    let pending = false;
    let loading = false;
    let polling = false;
    let mountToken = 0;
    let activePanel = null;
    const unreadOnly = new URLSearchParams(window.location.search).get("filter") === "unread";
    const escape = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
    const initials = name => String(name || "TC").trim().split(/\s+/).slice(0, 2).map(word => word[0] || "").join("").toUpperCase();
    const showTime = value => {
        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? "" : date.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
    };

    async function request(path, options = {}) {
        const response = await fetch(path, {credentials:"same-origin",cache:"no-store",...options});
        const text = await response.text();
        let payload;
        try {
            payload = JSON.parse(text);
        } catch {
            throw new Error(`Messages API returned an invalid response (HTTP ${response.status}). Start the unified Python backend on port 8000.`);
        }
        if (!response.ok) throw new Error(typeof payload.detail === "string" ? payload.detail : `Messages request failed (HTTP ${response.status}).`);
        return payload;
    }

    const avatarContent = person => {
        const name = String(person.name || "");
        const photo = String(person.photo || "");
        const picture = /^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(photo)
            ? `<img src="${escape(photo)}" alt="${escape(name)} profile picture" loading="lazy">`
            : escape(initials(name));
        return `<span class="admin-conversation-avatar" aria-label="${escape(name)} profile picture">${picture}</span>`;
    };

    function showProblem(message) {
        const panel = document.getElementById("chatWindow");
        if (!panel || panel !== activePanel) return;
        panel.innerHTML = `<div class="admin-chat-alert" role="alert">${escape(message)}</div>`;
    }

    function showLoading() {
        const panel = document.getElementById("chatWindow");
        if (panel) panel.innerHTML = '<div class="admin-chat-notice">Loading conversations from SQL Server...</div>';
        const list = document.getElementById("messageConversationList");
        if (list) list.innerHTML = '<p class="admin-message-empty-list">Loading conversations...</p>';
    }

    function drawThreads() {
        const list = document.getElementById("messageConversationList");
        if (!list || !account) return;
        const term = (document.getElementById("messageSearch")?.value || "").trim().toLocaleLowerCase();
        const matches = threads.filter(item => (!unreadOnly || Number(item.unread) > 0 || item.id === selected) && `${item.name} ${item.lastMessage || ""}`.toLocaleLowerCase().includes(term));
        const groups = account.role === "doctor"
            ? [["Care Team", matches.filter(item => item.id === "care-team")], ["Patients", matches.filter(item => item.id.startsWith("patient-"))]]
            : [["Patient Support", matches.filter(item => item.id.startsWith("patient-"))], ["Doctors", matches.filter(item => item.id.startsWith("doctor-"))]];
        list.replaceChildren();
        for (const [label, items] of groups) {
            if (!items.length) continue;
            const heading = document.createElement("div");
            heading.className = "admin-message-section-label";
            heading.textContent = label;
            list.append(heading);
            for (const item of items) {
                const button = document.createElement("button");
                button.type = "button";
                button.className = "admin-conversation-item" + (item.id === selected ? " active" : "");
                button.innerHTML = `${avatarContent(item)}<span class="admin-conversation-summary"><strong>${escape(item.name)}</strong><span class="admin-conversation-preview">${escape(item.lastMessage || item.subtitle || "")}</span></span><span class="admin-conversation-meta"><span>${escape(showTime(item.lastAt))}</span>${item.unread ? `<span class="admin-unread-count">${Number(item.unread)}</span>` : ""}</span>`;
                button.addEventListener("click", () => {void openThread(item.id);});
                list.append(button);
            }
        }
        if (!matches.length) list.innerHTML = unreadOnly && !term ? '<p class="admin-message-empty-list">No unread conversations. <a href="admin-messages.html">Show all</a></p>' : '<p class="admin-message-empty-list">No conversations found.</p>';
        if (matches.length && !groups.some(group => group[1].length)) list.innerHTML = '<p class="admin-message-empty-list">No conversations available for this account.</p>';
    }

    function drawConversation() {
        const panel = document.getElementById("chatWindow");
        if (!panel || !opened || !account) return;
        const replies = account.role === "staff"
            ? ["Your appointment has been confirmed.", "Please arrive 10 minutes early.", "Your appointment has been rescheduled.", "Your order has been shipped."]
            : ["Thank you for your message.", "Please follow the care instructions provided.", "We recommend discussing this during your next consultation."];
        panel.innerHTML = `
            <header class="admin-chat-heading">${avatarContent(opened)}<div><h3>${escape(opened.name)}</h3><p>${escape(opened.subtitle || "")}</p></div></header>
            <div class="admin-chat-messages" id="adminChatMessages" aria-live="polite"><div class="admin-message-date">Recent messages</div>
                ${opened.messages.length ? opened.messages.map(item => `<article class="admin-chat-bubble ${item.from === account.role ? "outgoing" : "incoming"}"><div>${escape(item.text)}</div><time>${escape(showTime(item.createdAt))}</time></article>`).join("") : '<p class="admin-chat-notice">No messages yet.</p>'}
            </div>
            <form class="admin-message-form" id="messageReply"><div class="admin-message-composer"><textarea name="text" maxlength="1000" rows="1" placeholder="Write a message..." aria-label="Write a message" required></textarea><button type="submit" class="primary-btn">Send</button></div><label class="admin-quick-reply"><span>Quick reply</span><select id="quickReply"><option value="">Choose a reply (optional)</option>${replies.map(reply => `<option value="${escape(reply)}">${escape(reply)}</option>`).join("")}</select></label></form>`;
        const messages = document.getElementById("adminChatMessages");
        messages.scrollTop = messages.scrollHeight;
        document.getElementById("quickReply").addEventListener("change", event => {
            const field = document.querySelector('#messageReply textarea');
            if (field && event.target.value) field.value = event.target.value;
        });
        document.getElementById("messageReply").addEventListener("submit", async event => {
            event.preventDefault();
            if (pending) return;
            const field = event.currentTarget.elements.text;
            const value = field.value.trim();
            if (!value) return;
            const threadId = selected;
            const button = event.currentTarget.querySelector('button[type="submit"]');
            button.disabled = true;
            pending = true;
            try {
                await verifySession();
                await request(`/api/admin/messages/threads/${encodeURIComponent(threadId)}`, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:value})});
                const response = await request("/api/admin/messages/threads");
                threads = Array.isArray(response.threads) ? response.threads : [];
                if (threadId === selected) await openThread(threadId, true);
                drawThreads();
            } catch (problem) {
                window.alert(problem.message);
                if (field.isConnected) field.value = value;
            } finally {
                pending = false;
                if (button.isConnected) button.disabled = false;
            }
        });
    }

    async function verifySession() {
        const response = await request("/api/auth/me");
        if (!account || !response.user || String(response.user.id) !== String(account.id) || response.user.role !== account.role) {
            throw new Error("The active Staff/Doctor login changed in another tab. Sign in using separate Chrome profiles to keep the two accounts independent.");
        }
    }

    async function openThread(id, quiet = false) {
        if (!account) return;
        selected = id;
        drawThreads();
        const token = mountToken;
        try {
            const response = await request(`/api/admin/messages/threads/${encodeURIComponent(id)}`);
            if (token !== mountToken || selected !== id) return;
            opened = {...response, messages:Array.isArray(response.messages) ? response.messages : []};
            drawConversation();
            drawThreads();
        } catch (problem) {
            if (token === mountToken && !quiet) showProblem(problem.message);
        }
    }

    async function refresh(quiet = false) {
        if (!account || loading || !document.getElementById("messageConversationList")) return;
        const token = mountToken;
        loading = true;
        try {
            await verifySession();
            const response = await request("/api/admin/messages/threads");
            if (token !== mountToken) return;
            threads = Array.isArray(response.threads) ? response.threads : [];
            if (!threads.some(item => item.id === selected)) {
                const firstUnread = unreadOnly ? threads.find(item => Number(item.unread) > 0) : null;
                selected = firstUnread?.id || (unreadOnly ? "" : account.role === "doctor" ? "care-team" : threads[0]?.id || "");
            }
            drawThreads();
            if (selected && !pending) await openThread(selected, true);
            else if (!selected) document.getElementById("chatWindow").innerHTML = unreadOnly
                ? '<div class="admin-chat-empty"><h3>No unread messages</h3><p><a href="admin-messages.html">View all conversations</a></p></div>'
                : '<div class="admin-chat-empty"><h3>No conversations yet</h3></div>';
        } catch (problem) {
            if (token === mountToken) {
                threads = [];
                opened = null;
                drawThreads();
                showProblem(problem.message);
            }
        } finally {
            loading = false;
        }
    }

    async function mount() {
        const container = document.getElementById("messageConversationList");
        const panel = document.getElementById("chatWindow");
        if (!container || !panel || container.dataset.tcmLive === "1") return;
        container.dataset.tcmLive = "1";
        mountToken += 1;
        activePanel = panel;
        const token = mountToken;
        account = null;
        threads = [];
        opened = null;
        selected = "";
        const search = document.getElementById("messageSearch");
        if (search) {
            const clean = search.cloneNode(true);
            search.replaceWith(clean);
            clean.addEventListener("input", drawThreads);
        }
        showLoading();
        try {
            const server = await request("/api/auth/me");
            if (token !== mountToken) return;
            const current = window.TcmAdminAuth?.getCurrentAdmin?.();
            const actual = server.user;
            if (!actual || !["staff","doctor"].includes(actual.role)) throw new Error("Please sign in as Staff or Doctor to open Messages.");
            if (current && (String(current.id) !== String(actual.id) || current.role !== actual.role)) {
                throw new Error("Your Staff and Doctor tabs are using different sign-ins in the same browser profile. Use separate Chrome profiles for Staff and Doctor, then sign in again.");
            }
            account = actual;
            await refresh();
        } catch (problem) {
            if (token === mountToken) {
                container.replaceChildren();
                showProblem(problem.message);
            }
        }
        if (!polling) {
            polling = true;
            window.setInterval(() => {
                if (document.body.dataset.page !== "messages" || document.hidden || pending || document.querySelector('#messageReply textarea')?.value.trim()) return;
                void refresh(true);
            }, 10000);
            window.addEventListener("focus", () => {
                if (document.body.dataset.page === "messages" && !pending && !document.querySelector('#messageReply textarea')?.value.trim()) void refresh(true);
            });
        }
    }

    function observePage() {
        const page = document.getElementById("adminPage");
        if (!page) return;
        const observer = new MutationObserver(() => {if (document.getElementById("messageConversationList")) void mount();});
        observer.observe(page, {childList:true});
        if (document.getElementById("messageConversationList")) void mount();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", observePage);
    else observePage();
    window.TcmAdminMessaging = {mount};
})();
