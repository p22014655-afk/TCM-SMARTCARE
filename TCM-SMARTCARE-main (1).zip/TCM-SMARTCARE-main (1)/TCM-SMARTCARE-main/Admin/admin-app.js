(function () {
    const { formatDate, shortDate, formatTime, generateID, showToast, openModal, closeModal, statusClass, money } = window.TcmAdminUtils;
    const pages = {
        dashboard: renderDashboard,
        appointments: renderAppointments,
        schedule: renderSchedule,
        patients: renderPatients,
        carePlan: renderCarePlan,
        products: renderProducts,
        orders: renderOrders,
        shopReviews: renderShopReviews,
        messages: renderMessages,
        feedback: renderFeedback,
        doctorReviews: renderDoctorReviews,
        announcements: renderAnnouncements,
        analytics: renderAnalytics,
        accounts: renderAccounts
    };
    let activeMessageId = "";
    const analyticsLive = {
        orders: null,
        products: null,
        ordersError: "",
        productsError: "",
        syncedAt: null,
        loading: false,
        polling: false
    };

    async function readAnalyticsApi(path) {
        const response = await fetch(path, {
            credentials: "same-origin",
            cache: "no-store"
        });
        const body = await response.text();
        let payload;
        try {
            payload = JSON.parse(body);
        } catch {
            throw new Error(`API returned an invalid response (${response.status}): ${path}`);
        }
        if (!response.ok) {
            const detail = typeof payload.detail === "string" ? payload.detail : `HTTP ${response.status}`;
            throw new Error(detail);
        }
        return payload;
    }

    async function refreshAnalyticsSql() {
        if (analyticsLive.loading || document.body.dataset.page !== "analytics") return;
        analyticsLive.loading = true;
        try {
            const [ordersResult, productsResult] = await Promise.allSettled([
                readAnalyticsApi("/api/admin/orders"),
                readAnalyticsApi("/api/admin/products")
            ]);
            if (ordersResult.status === "fulfilled" && Array.isArray(ordersResult.value.orders)) {
                analyticsLive.orders = ordersResult.value.orders.map((order) => ({
                    ...order,
                    date: String(order.purchasedAt || "").slice(0, 10),
                    items: Array.isArray(order.items) ? order.items : []
                }));
                analyticsLive.ordersError = "";
                analyticsLive.syncedAt = new Date();
            } else {
                analyticsLive.ordersError = ordersResult.status === "rejected"
                    ? ordersResult.reason?.message || "Unable to load SQL orders."
                    : "Orders API returned invalid data.";
            }
            if (productsResult.status === "fulfilled" && Array.isArray(productsResult.value.products)) {
                analyticsLive.products = productsResult.value.products;
                analyticsLive.productsError = "";
            } else {
                analyticsLive.productsError = productsResult.status === "rejected"
                    ? productsResult.reason?.message || "Unable to load SQL products."
                    : "Products API returned invalid data.";
            }
        } finally {
            analyticsLive.loading = false;
            renderAnalytics();
        }
    }

    function startAnalyticsPolling() {
        if (analyticsLive.polling || document.body.dataset.page !== "analytics") return;
        analyticsLive.polling = true;
        window.setInterval(refreshAnalyticsSql, 10000);
        window.addEventListener("focus", refreshAnalyticsSql);
        void refreshAnalyticsSql();
    }


    function data() {
        return window.TcmAdminData.load();
    }

    function save(nextData) {
        return window.TcmAdminData.save(nextData);
    }

    function current() {
        return window.TcmAdminAuth.getCurrentAdmin();
    }

    function byId(id) {
        return document.getElementById(id);
    }

    function mountView(templateId, target = byId("adminPage")) {
        const template = byId(templateId);
        if (!template || !(template instanceof HTMLTemplateElement)) {
            throw new Error(`Required HTML template "${templateId}" was not found.`);
        }
        target.replaceChildren(template.content.cloneNode(true));
        return target;
    }

    function escapeHtml(value) {
        return String(value ?? "").replace(/[&<>"']/g, (character) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "\"": "&quot;",
            "'": "&#39;"
        })[character]);
    }

    function productCategories(products) {
        const categories = ["Bird's Nest", "Ginseng", "Herbal Tea", "Wellness"];
        const seen = new Set(categories.map((category) => category.toLowerCase()));

        products.forEach((product) => {
            const category = String(product.category || "").trim();
            const normalized = category.toLowerCase();
            if (category && !seen.has(normalized)) {
                categories.push(category);
                seen.add(normalized);
            }
        });

        return categories;
    }

    function doctorName(doctorId, state = data()) {
        return state.doctors.find((doctor) => doctor.id === doctorId)?.name || state.appointments.find((visit) => visit.doctorId === doctorId)?.doctor || "Retired doctor";
    }

    function badge(status) {
        return `<span class="badge ${statusClass(status)}">${escapeHtml(status)}</span>`;
    }

    function protect(page) {
        if (["feedback", "announcements", "analytics", "schedule", "products", "orders", "shopReviews", "accounts"].includes(page)) {
            return window.TcmAdminAuth.checkRole(["staff"]);
        }
        return Boolean(window.TcmAdminAuth.checkAdminSession());
    }

    function initLogin() {
        const form = byId("adminLoginForm");
        const status = byId("loginStatus");
        const password = byId("password");
        byId("togglePassword").addEventListener("click", () => {
            password.type = password.type === "password" ? "text" : "password";
        });

        form.addEventListener("submit", async (event) => {
            event.preventDefault();
            status.textContent = "";
            const button = form.querySelector("button[type='submit']");
            button.disabled = true;
            button.textContent = "Logging in...";
            try {
                await window.TcmAdminAuth.login(byId("identifier").value, password.value);
                window.TcmAdminAuth.redirectByRole();
            } catch (error) {
                status.textContent = error.message || "Could not sign in. Please try again.";
                button.disabled = false;
                button.textContent = "Login";
            }
        });

    }

    function renderShell(page, title) {
        const user = current();
        const nav = document.querySelector(".admin-nav");
        if (nav && !nav.querySelector('[data-nav-page="accounts"]')) {
            const insightsGroup = nav.querySelector('[data-nav-page="analytics"]')?.closest(".nav-group");
            insightsGroup?.insertAdjacentHTML("afterend", `
                <div class="nav-group">
                    <p>Administration</p>
                    <a data-nav-page="accounts" data-staff-only href="admin-accounts.html">
                        <span class="nav-icon icon-users"></span><span>Staff &amp; Accounts</span>
                    </a>
                </div>
            `);
        }
        const storeGroup = nav?.querySelector('[data-nav-page="orders"]')?.closest(".nav-group");
        if (storeGroup && !storeGroup.querySelector('[data-nav-page="shopReviews"]')) {
            const reviewLink = document.createElement("a");
            reviewLink.href = "admin-shop-reviews.html";
            reviewLink.dataset.navPage = "shopReviews";
            reviewLink.setAttribute("data-staff-only", "");
            reviewLink.innerHTML = '<span class="nav-icon admin-reviews-nav-icon">★</span><span>Shop Reviews</span>';
            storeGroup.append(reviewLink);
        }
        byId("adminDate").textContent = formatDate(new Date());
        byId("pageTitle").textContent = title;
        byId("adminAvatar").textContent = user.avatar;
        byId("adminName").textContent = user.name;
        byId("adminRole").textContent = user.role;
        // Staff and doctors share HTML files, but each role should keep its own portal identity
        // as the browser navigates from dashboard to appointments, patients, and clinical notes.
        if (user.role === "doctor") {
            const portalLabel = document.querySelector(".portal-label");
            if (portalLabel) portalLabel.textContent = "DOCTOR PORTAL";
            const workspace = document.querySelector(".workspace-card");
            if (workspace) {
                const heading = workspace.querySelector("strong");
                const subtitle = workspace.querySelector("span");
                if (heading) heading.textContent = "Doctor workspace";
                if (subtitle) subtitle.textContent = "Appointments and clinical care";
            }
            const operationsLabel = nav?.querySelector(".nav-group > p");
            if (operationsLabel) operationsLabel.textContent = "Doctor Workspace";
            const doctorPages = {
                dashboard: ["Doctor Dashboard", "Dashboard"],
                appointments: ["Doctor Appointments", "My Appointments"],
                patients: ["Doctor Patient Records", "Patients"],
                carePlan: ["Doctor Clinical Notes", "Clinical Notes"],
                messages: ["Doctor Messages", "Messages"]
            };
            if (doctorPages[page]) {
                const [heading, navText] = doctorPages[page];
                byId("pageTitle").textContent = heading;
                document.title = `TCM SmartCare+ | ${heading}`;
                const activeLink = nav?.querySelector(`[data-nav-page="${page}"]`);
                const label = activeLink?.querySelector("span:last-of-type");
                if (label) label.textContent = navText;
            }
            // Doctors cannot create appointments from the patient-directory screen.
            // The actual role and authorization still come from the backend session.
        }
        const profileButton = document.querySelector(".admin-profile");
        if (profileButton) {
            profileButton.setAttribute("role", "button");
            profileButton.setAttribute("tabindex", "0");
            profileButton.setAttribute("aria-label", "Edit your profile");
            profileButton.setAttribute("title", "Edit profile");
            profileButton.addEventListener("click", openAdminProfile);
            profileButton.addEventListener("keydown", (event) => {
                if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    openAdminProfile();
                }
            });
        }
        const savedUser = accountDirectory(data()).find((account) => account.id === user.id);
        renderAdminAvatar(profilePictureForViewer(savedUser, user), savedUser?.name || user.name);

        document.querySelectorAll("[data-nav-page]").forEach((link) => {
            const isActive = link.dataset.navPage === page;
            link.classList.toggle("active", isActive);
            if (isActive) link.setAttribute("aria-current", "page");
            else link.removeAttribute("aria-current");
        });
        document.querySelectorAll("[data-staff-only]").forEach((link) => {
            link.hidden = user.role !== "staff";
        });
        if (user.role === "doctor") {
            ["schedule", "feedback", "announcements"].forEach((pageName) => {
                document.querySelector(`[data-nav-page="${pageName}"]`)?.remove();
            });
        }
        if (user.role === 'doctor' && nav && !nav.querySelector('[data-nav-page="doctorReviews"]')) {
            const group = nav.querySelector('[data-nav-page="messages"]')?.closest('.nav-group') || nav;
            const link = document.createElement('a');
            link.href = 'doctor-reviews.html';
            link.dataset.navPage = 'doctorReviews';
            link.innerHTML = '<span class="nav-icon icon-feedback"></span><span>Patient Reviews</span>';
            group.append(link);
            link.classList.toggle('active', page === 'doctorReviews');
        }

        document.querySelectorAll(".admin-nav .nav-group").forEach((group) => {
            group.hidden = !group.querySelector("a:not([hidden])");
        });
        byId("adminLogout").addEventListener("click", window.TcmAdminAuth.logout);
        if (!document.getElementById('tcmNotificationsCss')) {
            const css = document.createElement('link');
            css.id = 'tcmNotificationsCss';
            css.rel = 'stylesheet';
            css.href = 'notification-center.css?v=20261031';
            document.head.appendChild(css);
        }
        if (!document.getElementById('tcmNotificationsBadgeScript')) {
            const badgeScript = document.createElement('script');
            badgeScript.id = 'tcmNotificationsBadgeScript';
            badgeScript.src = 'notification-badge.js?v=20261031';
            document.body.appendChild(badgeScript);
        }
    }

    function profilePictureForViewer(account) {
        return account?.profilePicture || "";
    }

    function renderAdminAvatar(photo, name) {
        const avatar = byId("adminAvatar");
        if (!avatar) return;
        if (photo) {
            avatar.textContent = "";
            avatar.style.backgroundImage = `url("${photo}")`;
            avatar.style.backgroundSize = "cover";
            avatar.style.backgroundPosition = "center";
            avatar.style.backgroundRepeat = "no-repeat";
            avatar.setAttribute("aria-label", `${name} profile picture`);
            return;
        }
        avatar.style.backgroundImage = "";
        avatar.textContent = initials(name);
        avatar.setAttribute("aria-label", `${name} initials`);
    }

    async function openAdminProfile() {
        const user = current();
        // Staff saves doctor pictures to SQL Server. Read that latest copy before
        // opening Edit profile so a doctor does not see the browser's old photo.
        if (user?.role === "doctor") {
            try {
                await window.TcmAdminData.initialize();
            } catch (error) {
                showToast(error?.message || "Could not load your latest profile picture.");
                return;
            }
        }
        const state = data();
        const account = accountDirectory(state).find((item) => item.id === user.id);
        if (!account) {
            showToast("Could not find your account. Please sign in again.");
            return;
        }
        if (user.role === "doctor") {
            renderAdminAvatar(profilePictureForViewer(account, user), account.name);
        }

        let pendingPhoto = profilePictureForViewer(account, user);
        let photoChanged = false;
        openModal("Edit profile", `
            <form class="admin-profile-form" id="adminProfileForm" autocomplete="off">
                <div class="admin-profile-photo-editor">
                    <div class="admin-profile-photo-preview" id="adminProfilePhotoPreview">
                        ${pendingPhoto ? `<img src="${pendingPhoto}" alt="Profile picture preview">` : `<span>${escapeHtml(initials(account.name))}</span>`}
                    </div>
                    <div>
                        <strong>Profile picture</strong>
                        ${user.role === "doctor" ? `<p>Profile picture is managed by clinic staff.</p>` : `
                        <p>Choose an image up to 5 MB. It will be resized before saving.</p>
                        <label class="secondary-btn admin-photo-picker" for="adminProfilePhoto">Choose picture</label>
                        <input id="adminProfilePhoto" type="file" accept="image/png,image/jpeg,image/webp">
                        <button class="mini-btn" id="removeAdminProfilePhoto" type="button">Remove</button>`}
                    </div>
                </div>
                <div class="form-grid">
                    <label class="full"><span>Full name</span><input id="adminProfileName" name="name" maxlength="100" value="${escapeHtml(account.name)}" autocomplete="name" readonly aria-readonly="true" style="background:#f2f6f4;cursor:not-allowed;color:#65736f" required></label>
                    <label class="full"><span>Email address</span><input id="adminProfileEmail" name="email" type="email" maxlength="254" value="${escapeHtml(account.email)}" autocomplete="email" required></label>
                </div>
            </form>
        `, `<button class="primary-btn" id="saveAdminProfile" type="button">Save changes</button>`, { closeOnBackdrop: false });

        const photoInput = byId("adminProfilePhoto");
        photoInput?.addEventListener("change", () => {
            const file = photoInput.files?.[0];
            if (!file) return;
            if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
                showToast("Choose a JPG, PNG, or WEBP image.");
                photoInput.value = "";
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                showToast("Choose an image smaller than 5 MB.");
                photoInput.value = "";
                return;
            }
            const reader = new FileReader();
            reader.addEventListener("error", () => showToast("Could not read that image. Try another file."));
            reader.addEventListener("load", () => {
                const image = new Image();
                image.addEventListener("error", () => showToast("Could not open that image. Try another file."));
                image.addEventListener("load", () => {
                    const scale = Math.min(1, 512 / Math.max(image.width, image.height));
                    const canvas = document.createElement("canvas");
                    canvas.width = Math.max(1, Math.round(image.width * scale));
                    canvas.height = Math.max(1, Math.round(image.height * scale));
                    const context = canvas.getContext("2d");
                    if (!context) {
                        showToast("Could not process the picture in this browser.");
                        return;
                    }
                    context.drawImage(image, 0, 0, canvas.width, canvas.height);
                    pendingPhoto = canvas.toDataURL("image/jpeg", 0.82);
                    photoChanged = true;
                    byId("adminProfilePhotoPreview").innerHTML = `<img src="${pendingPhoto}" alt="Profile picture preview">`;
                });
                image.src = String(reader.result);
            });
            reader.readAsDataURL(file);
        });
        byId("removeAdminProfilePhoto")?.addEventListener("click", () => {
            pendingPhoto = "";
            photoChanged = true;
            photoInput.value = "";
            byId("adminProfilePhotoPreview").innerHTML = pendingPhoto
                ? `<img src="${pendingPhoto}" alt="Profile picture preview">`
                : `<span>${escapeHtml(initials(byId("adminProfileName").value))}</span>`;
        });
        byId("saveAdminProfile").addEventListener("click", async () => {
            const form = byId("adminProfileForm");
            if (!form.reportValidity()) return;
            const email = byId("adminProfileEmail").value.trim().toLowerCase();
            const button = byId("saveAdminProfile");
            if (!email) return;
            if (accountDirectory(state).some((item) => item.id !== account.id && item.email.trim().toLowerCase() === email)) {
                showToast("Another account already uses this email address.");
                return;
            }
            button.disabled = true;
            button.textContent = "Saving...";
            try {
                const updates = { email };
                if (user.role === "staff" && photoChanged) {
                    updates.profilePicture = pendingPhoto;
                }
                const response = await fetch("/api/admin/profile", {
                    method: "PATCH",
                    credentials: "same-origin",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(updates)
                });
                const result = await response.json().catch(() => ({}));
                if (!response.ok) {
                    const detail = result.detail;
                    throw new Error(typeof detail === "string" ? detail : `Could not save profile (HTTP ${response.status}).`);
                }
                account.name = result.profile.name;
                account.email = result.profile.email;
                account.avatar = result.profile.avatar;
                if (user.role === "staff" && photoChanged) account.profilePicture = pendingPhoto;
                window.TcmAdminData.restore(state);
                const updatedSession = {
                    id: account.id,
                    name: account.name,
                    role: account.role,
                    avatar: account.avatar
                };
                sessionStorage.setItem("tcmAdminUser", JSON.stringify(updatedSession));
                byId("adminName").textContent = account.name;
                renderAdminAvatar(profilePictureForViewer(account, user), account.name);
                closeModal();
                showToast("Profile updated successfully.");
            } catch (error) {
                showToast(error?.message || "Could not save your profile.");
            } finally {
                button.disabled = false;
                button.textContent = "Save changes";
            }
        });
    }

    function table(headers, rows) {
        return `
            <table class="admin-table">
                <thead><tr>${headers.map((item) => `<th>${item}</th>`).join("")}</tr></thead>
                <tbody>${rows.join("") || `<tr><td colspan="${headers.length}">No records found.</td></tr>`}</tbody>
            </table>
        `;
    }

    function initials(name) {
        return String(name || "").split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase();
    }

    function timeRange(item) {
        return `${formatTime(item.time)} - ${formatTime(item.endTime)}`;
    }

    function patientAvatar(name, photo = "") {
        // Only allow image data produced by the authenticated User Profile API.
        const safePhoto = typeof photo === "string" &&
            /^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(photo) ? photo : "";
        return safePhoto
            ? `<span class="avatar mini-avatar" style="overflow:hidden;border-radius:50%"><img src="${safePhoto}" alt="${escapeHtml(name)}" style="display:block;width:100%;height:100%;object-fit:cover;border-radius:50%"></span>`
            : `<span class="avatar mini-avatar">${escapeHtml(initials(name))}</span>`;
    }

    // For appointment and clinical-note avatars use the SQL patient key.
    // Names are not unique and can be edited in User My Profile.
    function appointmentPatientAvatar(appointment, state = data()) {
        const patientId = String(appointment?.patientId || "");
        const patient = patientId
            ? state.patients.find((row) => String(row.id) === patientId)
            : null;
        return patientAvatar(patient?.name || appointment?.patient || "", patient?.photo || "");
    }

    function todayAppointments(state = data()) {
        const now = new Date();
        const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
        return state.appointments.filter((appointment) => appointment.date === today);
    }

    function renderDashboard() {
        const user = current();
        const state = data();
        if (user.role === "doctor") {
            renderDoctorDashboard(state, user);
            return;
        }
        renderStaffDashboard(state, user);
    }

    function renderStaffDashboard(state, user) {
        const today = todayAppointments(state);
        const checkedIn = today.filter((item) => item.status === "Checked In").length;
        const pendingOrders = state.orders.filter((item) => item.status === "Pending Packing").length;
        const lowStock = state.products.filter((item) => item.stock <= item.lowStockThreshold).length;
        mountView("admin-staff-dashboard-view");
        byId("staffDashboardGreeting").textContent = `Good Morning, ${user.name}`;
        byId("staffDashboardKpis").innerHTML = [
            kpi(today.length, "Today's Appointments", "+2 compared with yesterday", "admin-appointments.html?date=today", "calendar", true),
            kpi(checkedIn, "Checked In", "Patients who have arrived", "admin-appointments.html?status=Checked%20In", "users"),
            kpi(pendingOrders, "Orders To Process", "Pending packing", "admin-orders.html?status=Pending%20Packing", "box"),
            kpi(lowStock, "Low Stock Products", "Needs restock review", "admin-products.html?stock=low", "bag")
        ].join("");
        byId("staffAppointmentSummary").textContent = `${today.length} appointments · ${checkedIn} checked in`;
        byId("staffAppointmentTable").innerHTML = table(["Time", "Patient / Service", "Doctor / Status", "Action"], today.map((item) => `
            <tr>
                <td>${formatTime(item.time)}</td>
                <td><div class="person-cell">${appointmentPatientAvatar(item, state)}<span><strong>${item.patient}</strong><small>${item.service}</small></span></div></td>
                <td><strong>${item.doctor}</strong><br>${badge(item.status)}</td>
                <td class="row-actions"><button class="mini-btn" data-view-appointment="${item.id}">View</button>${["Scheduled", "Rescheduled"].includes(item.status) ? `<button class="mini-btn" data-check-in="${item.id}">Check-in</button>` : ""}${item.status === "Completed" ? `<a class="text-link" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">View Clinical Notes</a>` : ""}</td>
            </tr>
        `));
        // Always use the browser's local clinic date; never display a hard-coded demo date.
        const localTodayLabel = new Intl.DateTimeFormat("en-MY", {
            weekday: "long", day: "numeric", month: "long", year: "numeric"
        }).format(new Date());
        byId("staffTimelineDate").textContent = `Scheduled appointment times - ${localTodayLabel}`;
        const activeToday = today
            .filter((item) => String(item.status || "").toLowerCase() !== "cancelled")
            .sort((a, b) => String(a.time || "").localeCompare(String(b.time || "")));
        byId("staffTimeline").innerHTML = activeToday.length
            ? activeToday.map((item) => `<div><small>${formatTime(item.time)}</small><strong>${escapeHtml(item.patient)} - ${escapeHtml(item.service)}</strong><span>${escapeHtml(item.doctor)}</span></div>`).join("")
            : `<p class="dashboard-empty-message">No appointments scheduled for today.</p>`;
        byId("dashboardCreateAppointment")?.addEventListener("click", openAppointmentCreate);
        bindAppointmentButtons();
    }

    function renderDoctorDashboard(state, user) {
        const mine = todayAppointments(state).filter((item) => item.doctorId === user.id);
        mountView("admin-doctor-dashboard-view");
        byId("doctorDashboardGreeting").textContent = `Good Morning, ${user.name}`;
        byId("doctorDashboardKpis").innerHTML = [
            kpi(mine.length, "Today's Patients", "Assigned to you", "admin-appointments.html?date=today"),
            kpi(mine.filter((item) => item.status === "Checked In").length, "Checked In", "Ready to start", "admin-appointments.html?status=Checked%20In"),
            kpi(mine.filter((item) => item.status === "Completed").length, "Completed Today", "Consultations completed", "admin-appointments.html?status=Completed"),
            kpi(state.messages.filter((item) => item.doctorId === user.id).reduce((sum, item) => sum + item.unread, 0), "Unread Messages", "Patient conversations", "admin-messages.html?filter=unread")
        ].join("");
        byId("doctorAppointmentTable").innerHTML = table(["Time", "Patient", "Service", "Status", "Action"], mine.map((item) => `
            <tr><td>${formatTime(item.time)}</td><td>${escapeHtml(item.patient)}</td><td>${escapeHtml(item.service)}</td><td>${badge(item.status)}</td>
            <td class="row-actions">${item.status === "Checked In" ? `<button class="mini-btn" data-start-consult="${item.id}">Start</button>` : `<button class="mini-btn" data-view-appointment="${item.id}">View</button>`}<a class="text-link" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">Clinical Notes</a></td></tr>
        `));
        // Doctor alerts: list actual patients assigned to this doctor today.
        // Do not insert seed/demo patients or notifications with hard-coded dates.
        const activePatients = mine
            .filter((item) => String(item.status || "").toLowerCase() !== "cancelled")
            .sort((a, b) => String(a.time || "").localeCompare(String(b.time || "")));
        byId("doctorPatientAlerts").innerHTML = activePatients.length
            ? activePatients.map((item) => {
                const patient = state.patients.find((row) => String(row.id) === String(item.patientId));
                const patientName = patient?.name || item.patient || "Patient";
                const hasAssessment = Boolean(patient?.preConsultation?.submitted);
                const notice = item.status === "Checked In"
                    ? "Patient checked in"
                    : item.status === "In Consultation"
                        ? "In consultation"
                        : hasAssessment ? "Pre-consultation submitted" : "Today's appointment";
                return `<a class="alert-card" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">
                    <span>${escapeHtml(notice)}</span>
                    <strong>${escapeHtml(patientName)}</strong>
                    <small>${formatTime(item.time)} · ${escapeHtml(item.service)} · ${escapeHtml(item.status)}</small>
                </a>`;
            }).join("")
            : `<p class="dashboard-empty-message">No patients assigned for today.</p>`;
        bindAppointmentButtons();
    }

    function kpi(value, label, hint, href, icon = "grid", featured = false) {
        return `<a class="kpi-card ${featured ? "featured" : ""}" href="${href}"><span class="kpi-icon nav-icon icon-${icon}"></span><strong>${value}</strong><span>${label}</span><small>${hint}</small></a>`;
    }

    // Shared date categories for appointments and clinical notes.
    function appointmentLocalToday() {
        const now = new Date();
        return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    }

    function appointmentDateGroup(date) {
        const value = String(date || "").slice(0, 10);
        const today = appointmentLocalToday();
        return value === today ? "today" : value > today ? "upcoming" : "past";
    }

    function compareAppointmentsForDisplay(a, b) {
        const priority = { today: 0, upcoming: 1, past: 2 };
        const aGroup = appointmentDateGroup(a.date);
        const bGroup = appointmentDateGroup(b.date);
        if (priority[aGroup] !== priority[bGroup]) return priority[aGroup] - priority[bGroup];
        const aMoment = `${a.date || ""} ${a.time || ""}`;
        const bMoment = `${b.date || ""} ${b.time || ""}`;
        // Today and upcoming: earliest first. Past: most recent first.
        const order = aGroup === "past" ? bMoment.localeCompare(aMoment) : aMoment.localeCompare(bMoment);
        return order || String(a.id || "").localeCompare(String(b.id || ""));
    }

    function appointmentDateBadge(date) {
        const group = appointmentDateGroup(date);
        const label = { today: "Today", upcoming: "Upcoming", past: "Past" }[group];
        return `<span class="appointment-date-label appointment-date-label--${group}">${label}</span>`;
    }

    function renderAppointments() {
        const user = current();
        const state = data();
        const params = new URLSearchParams(location.search);
        const records = state.appointments.length;
        mountView("admin-appointment-view");
        byId("createAppointment").hidden = !["staff", "doctor"].includes(user.role);
        const availableServices = ["TCM Consultation", "Acupuncture", "Cupping", "Tuina Therapy"];
        byId("filterService").replaceChildren(
            new Option("All Services", ""),
            ...availableServices.map((service) => new Option(service, service))
        );
        byId("filterDoctor").innerHTML = user.role === "doctor"
            ? `<option value="${escapeHtml(user.id)}">My Appointments</option>`
            : `<option value="">All Doctors</option>${state.doctors.map((doctor) => `<option value="${escapeHtml(doctor.id)}">${escapeHtml(doctor.name)}</option>`).join("")}`;
        byId("filterDoctor").disabled = user.role === "doctor";
        byId("appointmentDoctorFilterField").hidden = user.role === "doctor";
        document.querySelector(".appointment-panel .table-toolbar").classList.toggle("doctor-filter-layout", user.role === "doctor");
        if (user.role === "doctor") {
            const scheduledOption = Array.from(byId("filterStatus").options).find((option) => option.value === "Scheduled");
            scheduledOption?.remove();
        }
        const scopedAppointments = user.role === "doctor"
            ? state.appointments.filter((item) => String(item.doctorId) === String(user.id))
            : state.appointments;
        byId("appointmentResultSummary").textContent = `${scopedAppointments.length} records`;
        byId("allAppointmentCount").textContent = scopedAppointments.length;
        byId("checkedInAppointmentCount").textContent = scopedAppointments.filter((item) => item.status === "Checked In").length;
        byId("inConsultationAppointmentCount").textContent = scopedAppointments.filter((item) => item.status === "In Consultation").length;
        byId("completedAppointmentCount").textContent = scopedAppointments.filter((item) => item.status === "Completed").length;
        byId("filterDate").value = params.get("date") || "";
        const requestedStatus = params.get("status") || "";
        byId("filterStatus").value = ({
            "Pending Confirmation": "Scheduled",
            Confirmed: "Scheduled",
            Waiting: "Checked In"
        })[requestedStatus] || requestedStatus;
        document.querySelectorAll("[data-status-tab]").forEach((button) => {
            button.classList.toggle("active", button.dataset.statusTab === byId("filterStatus").value);
        });
        byId("customDateFilter").hidden = byId("filterDate").value !== "custom";
        if (user.role === "doctor") byId("filterDoctor").value = user.id;
        byId("filterDate").addEventListener("change", () => {
            byId("customDateFilter").hidden = byId("filterDate").value !== "custom";
            renderAppointmentTable();
        });
        ["appointmentSearch", "filterDoctor", "filterService", "filterCustomDate"].forEach((id) => byId(id).addEventListener("input", renderAppointmentTable));
        byId("filterStatus").addEventListener("change", () => {
            document.querySelectorAll("[data-status-tab]").forEach((button) => {
                button.classList.toggle("active", button.dataset.statusTab === byId("filterStatus").value);
            });
            renderAppointmentTable();
        });
        document.querySelectorAll("[data-status-tab]").forEach((button) => button.addEventListener("click", () => {
            document.querySelectorAll("[data-status-tab]").forEach((item) => item.classList.remove("active"));
            button.classList.add("active");
            byId("filterStatus").value = button.dataset.statusTab;
            byId("filterDate").value = "";
            byId("customDateFilter").hidden = true;
            renderAppointmentTable();
        }));
        byId("tableView").addEventListener("click", renderAppointmentTable);
        byId("calendarView").addEventListener("click", renderCalendar);
        byId("createAppointment")?.addEventListener("click", openAppointmentCreate);
        renderAppointmentTable();
        drawSelectedAppointment(filteredAppointments()[0]);
    }

    function filteredAppointments() {
        const user = current();
        const state = data();
        const now = new Date();
        const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
        const addDays = (date, days) => {
            const next = new Date(date);
            next.setDate(next.getDate() + days);
            return `${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, "0")}-${String(next.getDate()).padStart(2, "0")}`;
        };
        const weekday = now.getDay();
        const daysSinceMonday = (weekday + 6) % 7;
        const weekStartDate = new Date(now);
        weekStartDate.setDate(now.getDate() - daysSinceMonday);
        const weekStart = `${weekStartDate.getFullYear()}-${String(weekStartDate.getMonth() + 1).padStart(2, "0")}-${String(weekStartDate.getDate()).padStart(2, "0")}`;
        const weekEndDate = new Date(weekStartDate);
        weekEndDate.setDate(weekStartDate.getDate() + 7);
        const weekEnd = `${weekEndDate.getFullYear()}-${String(weekEndDate.getMonth() + 1).padStart(2, "0")}-${String(weekEndDate.getDate()).padStart(2, "0")}`;
        const dateFilter = byId("filterDate")?.value || "";
        const doctorFilter = user.role === "doctor" ? user.id : byId("filterDoctor")?.value;
        const query = (byId("appointmentSearch")?.value || "").trim().toLowerCase();
        return state.appointments.filter((item) => {
            const matchesDate = dateFilter === "today" ? item.date === today
                : dateFilter === "tomorrow" ? item.date === addDays(today, 1)
                    : dateFilter === "next7" ? item.date >= today && item.date < addDays(today, 7)
                        : dateFilter === "week" ? item.date >= weekStart && item.date < weekEnd
                            : dateFilter === "next30" || dateFilter === "upcoming" ? item.date >= today && item.date < addDays(today, 30)
                                : dateFilter === "past" ? item.date < today
                                    : dateFilter === "custom" ? Boolean(byId("filterCustomDate").value) && item.date === byId("filterCustomDate").value
                                        : true;
            return (!query || `${item.id} ${item.patient} ${item.contact}`.toLowerCase().includes(query)) &&
                matchesDate &&
                (!doctorFilter || item.doctorId === doctorFilter) &&
                (!byId("filterService")?.value || item.service === byId("filterService").value) &&
                (!byId("filterStatus")?.value || item.status === byId("filterStatus").value);
        }).sort(compareAppointmentsForDisplay);
    }

    function renderAppointmentTable() {
        const records = filteredAppointments();
        const dateFilter = byId("filterDate").value;
        const dateLabel = {
            upcoming: "upcoming 30 days",
            today: "today",
            tomorrow: "tomorrow",
            next7: "next 7 days",
            week: "this week",
            next30: "next 30 days",
            custom: byId("filterCustomDate").value || "selected date",
            past: "past appointments"
        }[dateFilter] || "all dates";
        byId("appointmentResultSummary").textContent =
            `${records.length} ${records.length === 1 ? "appointment" : "appointments"} · ${dateLabel} · Today → Upcoming → Past`;
        const appointmentViewport = byId("appointmentContent");
        const savedTableScrollTop = appointmentViewport.scrollTop;
        const savedTableScrollLeft = appointmentViewport.scrollLeft;
        appointmentViewport.classList.add("appointment-table-scroll");
        appointmentViewport.innerHTML = table(
            ["Patient / Contact", "Service", "Date / Time", "Doctor / Room", "Status", "Actions"],
            records.map((item, index) => `
                <tr>
                    <td><div class="person-cell">${appointmentPatientAvatar(item)}<span><strong>${escapeHtml(item.patient)}</strong><small>${escapeHtml(item.id)}<br>${escapeHtml(item.contact)}</small></span></div></td>
                    <td>${escapeHtml(item.service)}</td>
                    <td><strong>${shortDate(item.date)}</strong> ${appointmentDateBadge(item.date)}<br><small>${formatTime(item.time)}</small></td>
                    <td>${escapeHtml(item.doctor)}<br><small>${escapeHtml(item.room)}</small></td>
                    <td>${badge(item.status)}</td>
                    <td class="appointment-actions-cell">
                        ${["Scheduled", "Rescheduled"].includes(item.status) ? `<div class="appointment-action-checkin"><button type="button" class="mini-btn primary-mini" data-check-in="${item.id}">Check-in</button></div>` : ""}
                        <div class="appointment-action-group" aria-label="Actions for appointment ${escapeHtml(item.id)}">
                            <button type="button" class="appointment-action-btn appointment-action-view" data-view-appointment="${item.id}">View</button>
                            ${item.status === "Completed" || current().role === "doctor" ? `<a class="appointment-action-btn appointment-action-notes" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">Clinical Notes</a>` : ""}
                            <button type="button" class="appointment-action-btn appointment-action-select" data-select-appointment="${item.id}" aria-label="Select appointment" title="Select appointment"><span aria-hidden="true">···</span></button>
                        </div>
                    </td>
                </tr>
            `)
        );
        appointmentViewport.scrollTop = savedTableScrollTop;
        appointmentViewport.scrollLeft = savedTableScrollLeft;
        bindAppointmentButtons(appointmentViewport);
        document.querySelectorAll("[data-select-appointment]").forEach((button) => button.addEventListener("click", () => {
            const item = data().appointments.find((appointment) => appointment.id === button.dataset.selectAppointment);
            drawSelectedAppointment(item);
        }));
        drawSelectedAppointment(records[0]);
    }

    function drawSelectedAppointment(item) {
        const panel = byId("selectedAppointment");
        const manageCard = document.querySelector(".manage-card");
        if (!panel) return;
        if (!item) {
            panel.innerHTML = `<h2>Selected appointment</h2><p>No appointment selected.</p>`;
            if (manageCard) {
                manageCard.innerHTML = `<h2>Manage this appointment</h2><p>Select a record to review its details and available actions.</p>`;
            }
            return;
        }
        panel.innerHTML = `
            <div class="selected-head"><h2>Selected appointment</h2>${badge(item.status)}</div>
            <div class="selected-body">
                ${appointmentPatientAvatar(item)}
                <div><strong>${escapeHtml(item.patient)} - ${escapeHtml(item.id)}</strong><span>${escapeHtml(item.service)}</span></div>
            </div>
            <dl class="detail-grid">
                <div><dt>Date & Time</dt><dd>${shortDate(item.date)} - ${formatTime(item.time)}</dd></div>
                <div><dt>Doctor & Room</dt><dd>${escapeHtml(item.doctor)} - ${escapeHtml(item.room)}</dd></div>
            </dl>
        `;
        if (manageCard) {
            const canCheckIn = ["Scheduled", "Rescheduled"].includes(item.status);
            const actions = [
                canCheckIn
                    ? `<button class="primary-btn" data-check-in="${item.id}"><span class="btn-icon icon-users"></span>Check-in</button>`
                    : item.status === "Checked In"
                        ? `<button class="primary-btn" data-start-consult="${item.id}">Start Consultation</button>`
                        : "",
                    `<button class="secondary-btn" data-view-appointment="${item.id}">View</button>`,
                    item.status === "Completed"
                        ? `<a class="secondary-btn" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">View Clinical Notes</a>`
                        : current().role === "doctor" ? `<a class="secondary-btn" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">Clinical Notes</a>` : ""
            ].filter(Boolean).join("");
            manageCard.innerHTML = `
                <h2>Manage this appointment</h2>
                <div class="row-actions">${actions}</div>
                ${canCheckIn ? `<hr><div class="link-row">${current().role === "staff" ? `<button class="text-link" data-reschedule="${item.id}">Reschedule</button>` : ""}<button class="text-link danger-text" data-cancel="${item.id}">Cancel appointment</button></div>` : ""}
                <p>${canCheckIn ? "Check in the patient when they arrive." : item.status === "Checked In" ? "Patient has arrived and is ready for consultation." : "No further actions are available."}</p>
            `;
            bindAppointmentButtons(manageCard);
        }
    }

    function renderCalendar() {
        const hours = Array.from({length: 26}, (_, index) => {
            const mins = 7 * 60 + index * 30;
            return `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}`;
        }).filter(time => time < '13:00' || time >= '15:00');
        const days = ["MON", "TUE", "WED", "THU", "FRI", "SAT"];
        const rows = [`<div class="calendar-head">Time</div>${days.map((day) => `<div class="calendar-head">${day}</div>`).join("")}`];
        hours.forEach((hour) => {
            rows.push(`<div>${formatTime(hour)}</div>`);
            days.forEach((day, index) => {
                const appt = filteredAppointments().find((item) => item.time === hour && new Date(item.date).getDay() === index + 1);
                rows.push(`<div>${appt ? `<button class="calendar-appt" data-view-appointment="${appt.id}">${appt.patient}<br>${appt.service}</button>` : ""}</div>`);
            });
        });
        byId("appointmentContent").classList.remove("appointment-table-scroll");
        byId("appointmentContent").innerHTML = `<div class="calendar-grid">${rows.join("")}</div>`;
        bindAppointmentButtons(byId("appointmentContent"));
    }

    function bindAppointmentButtons(root = document) {
        root.querySelectorAll("[data-view-appointment]").forEach((button) => button.addEventListener("click", () => openAppointmentDetails(button.dataset.viewAppointment)));
        root.querySelectorAll("[data-check-in]").forEach((button) => button.addEventListener("click", () => checkInAppointment(button.dataset.checkIn)));
        root.querySelectorAll("[data-start-consult]").forEach((button) => button.addEventListener("click", () => startConsultation(button.dataset.startConsult)));
        root.querySelectorAll("[data-reschedule]").forEach((button) => button.addEventListener("click", () => openReschedule(button.dataset.reschedule)));
        root.querySelectorAll("[data-cancel]").forEach((button) => button.addEventListener("click", () => openCancel(button.dataset.cancel)));
    }

    function openAppointmentDetails(id) {
        const state = data();
        const item = state.appointments.find((appointment) => appointment.id === id);
        if (!item) return;
        const action = ["Scheduled", "Rescheduled"].includes(item.status)
            ? `<button class="primary-btn" data-check-in="${item.id}">Check-in</button>`
            : item.status === "Checked In"
                ? `<button class="primary-btn" data-start-consult="${item.id}">Start Consultation</button>`
                : "";
        const notesAction = item.status === "Completed"
            ? `<a class="secondary-btn" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">View Clinical Notes</a>`
            : current().role === "doctor"
                ? `<a class="secondary-btn" href="admin-care-plan.html?appointment=${encodeURIComponent(item.id)}">Clinical Notes</a>`
                : "";
        openModal("Appointment Details", `
            <dl>
                <dt>Appointment ID</dt><dd>${item.id}</dd>
                <dt>Patient</dt><dd>${escapeHtml(item.patient)}</dd>
                <dt>Phone</dt><dd>${escapeHtml(item.contact)}</dd>
                <dt>Service</dt><dd>${escapeHtml(item.service)}</dd>
                <dt>Date</dt><dd>${formatDate(item.date)}</dd>
                <dt>Time</dt><dd>${formatTime(item.time)} - ${formatTime(item.endTime)}</dd>
                <dt>Doctor</dt><dd>${escapeHtml(item.doctor)}</dd>
                <dt>Room</dt><dd>${escapeHtml(item.room)}</dd>
                <dt>Status</dt><dd>${badge(item.status)}</dd>
            </dl>
        `, `${action}${notesAction}`);
        bindAppointmentButtons(document.querySelector(".admin-modal"));
    }

    async function clinicAppointmentRequest(path, options = {}) {
        const response = await fetch(`/api/admin/clinic-appointments${path}`, {
            credentials: 'same-origin', cache: 'no-store', ...options,
            headers: {'Content-Type': 'application/json', ...(options.headers || {})}
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload.detail || `Appointment update failed (${response.status}).`);
        return payload;
    }

    async function refreshClinicAppointments() {
        await window.TcmAdminData.initialize();
    }

    async function checkInAppointment(id) {
        const item = data().appointments.find(appointment => appointment.id === id);
        if (!item || !['Scheduled','Rescheduled'].includes(item.status)) return;
        await updateAppointment(id, 'Checked In', 'Patient checked in.');
    }

    async function startConsultation(id) {
        const item = data().appointments.find(appointment => appointment.id === id);
        if (!item || item.status !== 'Checked In') return;
        if (await updateAppointment(id, 'In Consultation', 'Consultation started.', false)) {
            window.location.href = `admin-care-plan.html?appointment=${encodeURIComponent(id)}`;
        }
    }

    async function updateAppointment(id, status, message, refresh = true) {
        const item = data().appointments.find(appointment => appointment.id === id);
        if (!item) return false;
        try {
            await clinicAppointmentRequest(`/${encodeURIComponent(id)}/status`, {
                method: 'PATCH', body: JSON.stringify({status})
            });
            await refreshClinicAppointments();
            showToast(message);
            closeModal();
            if (refresh && byId('appointmentContent')) {
                const user = current();
                const scopedAppointments = user.role === "doctor"
                    ? data().appointments.filter((record) => String(record.doctorId) === String(user.id))
                    : data().appointments;
                byId("allAppointmentCount").textContent = scopedAppointments.length;
                byId("checkedInAppointmentCount").textContent = scopedAppointments.filter((record) => record.status === "Checked In").length;
                byId("inConsultationAppointmentCount").textContent = scopedAppointments.filter((record) => record.status === "In Consultation").length;
                byId("completedAppointmentCount").textContent = scopedAppointments.filter((record) => record.status === "Completed").length;
                renderAppointmentTable();
            }
            return true;
        } catch (error) {
            showToast(error.message);
            return false;
        }
    }

    function openReschedule(id) {
        if (current()?.role !== "staff") return;
        const state = data();
        const item = state.appointments.find((appointment) => appointment.id === id);
        openModal("Reschedule Appointment", `
            <form class="form-grid" id="rescheduleForm">
                <label><span>New Date</span><input type="date" name="date" value="${item.date}" required></label>
                <label><span>New Time</span><input type="time" name="time" value="${item.time}" required></label>
                <label><span>New Doctor</span><select name="doctorId">${state.doctors.map((doctor) => `<option value="${doctor.id}" ${doctor.id === item.doctorId ? "selected" : ""}>${doctor.name}</option>`).join("")}</select></label>
                <label><span>Reason</span><input name="reason" required></label>
            </form>
        `, `<button class="primary-btn" id="saveReschedule">Save Changes</button>`);
        byId("saveReschedule").addEventListener("click", async () => {
            const form = byId("rescheduleForm");
            if (!form.reportValidity()) return;
            const values = new FormData(form);
            const button = byId('saveReschedule');
            button.disabled = true;
            try {
                await clinicAppointmentRequest(`/${encodeURIComponent(id)}/reschedule`, {
                    method: 'PATCH', body: JSON.stringify({
                        date: values.get('date'), time: values.get('time'), doctorId: values.get('doctorId')
                    })
                });
                await refreshClinicAppointments();
                showToast('Appointment rescheduled in SQL Server.');
                closeModal();
                renderAppointmentTable();
            } catch (error) { showToast(error.message); }
            finally { button.disabled = false; }
        });
    }

    function openCancel(id) {
        openModal("Cancel Appointment", `
            <form class="form-grid" id="cancelForm">
                <label class="full"><span>Cancellation reason</span><textarea name="reason" rows="4" required></textarea></label>
            </form>
        `, `<button class="danger-btn" id="saveCancel">Confirm Cancellation</button>`);
        byId("saveCancel").addEventListener("click", () => {
            if (!byId("cancelForm").reportValidity()) return;
            updateAppointment(id, "Cancelled", "Appointment cancelled.");
        });
    }

    function openAppointmentCreate() {
        const state = data();
        const today = (() => {
            const now = new Date();
            return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
        })();
        openModal("Create Appointment", `
            <form class="form-grid" id="appointmentCreateForm">
                <label><span>Patient</span><select name="patientId" required>${state.patients.map(patient => `<option value="${escapeHtml(patient.id)}">${escapeHtml(patient.name)}</option>`).join("")}</select></label>
                <label><span>Service</span><select name="service" id="appointmentCreateService" required><option value="">Loading services...</option></select></label>
                <label><span>Date</span><input type="date" name="date" id="appointmentCreateDate" min="${today}" value="${today}" required></label>
                <label><span>Doctor</span><select name="doctorId" id="appointmentCreateDoctor" required><option value="">Choose a doctor</option></select></label>
                <label class="full"><span>Available Time</span><select name="time" id="appointmentCreateTime" required><option value="">Choose a time</option></select></label>
                <p class="full" id="appointmentCreateAvailability" role="status" style="font-size:13px;color:#607e77;margin:0">Loading available appointments...</p>
            </form>
        `, `<button class="primary-btn" id="saveAppointment" disabled>Create Appointment</button>`);
        const form = byId("appointmentCreateForm");
        const serviceSelect = byId("appointmentCreateService");
        const dateInput = byId("appointmentCreateDate");
        const doctorSelect = byId("appointmentCreateDoctor");
        const timeSelect = byId("appointmentCreateTime");
        const message = byId("appointmentCreateAvailability");
        const saveButton = byId("saveAppointment");
        let availableDoctors = [];
        let version = 0;
        let loading = false;
        const resetTimes = () => {
            const doctor = availableDoctors.find(item => String(item.doctorId) === doctorSelect.value);
            timeSelect.replaceChildren(new Option(doctor?.slots?.length ? "Choose a time" : "No available times", ""));
            (doctor?.slots || []).forEach(slot => {
                const [hour, minute] = slot.time.split(":").map(Number);
                const label = `${hour % 12 || 12}:${String(minute).padStart(2, "0")} ${hour < 12 ? "AM" : "PM"} – ${slot.endTime}`;
                timeSelect.add(new Option(label, slot.time));
            });
            timeSelect.disabled = !doctor?.slots?.length;
            message.textContent = doctor
                ? (doctor.slots.length ? `${doctor.slots.length} available 30-minute slots for ${doctor.name}.` : "This doctor has no free appointment time on the selected date.")
                : (availableDoctors.length ? "Choose an available doctor." : "No doctors are working on this date for the selected service.");
            saveButton.disabled = loading || !timeSelect.value || !form.elements.patientId.value;
        };
        const loadAvailability = async () => {
            const requestVersion = ++version;
            const preferredDoctor = doctorSelect.value || (current()?.role === "doctor" ? current().id : "");
            const preferredService = serviceSelect.value;
            loading = true;
            saveButton.disabled = true;
            doctorSelect.disabled = true;
            timeSelect.disabled = true;
            message.textContent = "Checking doctor schedules in SQL Server...";
            try {
                const params = new URLSearchParams({date_value: dateInput.value});
                if (preferredService) params.set("service", preferredService);
                const result = await clinicAppointmentRequest(`/availability?${params.toString()}`);
                if (requestVersion !== version) return;
                const services = Array.isArray(result.services) ? result.services : [];
                const selectedService = services.includes(preferredService) ? preferredService : (services[0] || "");
                serviceSelect.replaceChildren(new Option("Choose a service", ""), ...services.map(item => new Option(item, item)));
                serviceSelect.value = selectedService;
                if (selectedService !== preferredService) {
                    loading = false;
                    await loadAvailability();
                    return;
                }
                availableDoctors = Array.isArray(result.doctors) ? result.doctors : [];
                doctorSelect.replaceChildren(new Option("Choose a doctor", ""), ...availableDoctors.map(item => new Option(item.name, item.doctorId)));
                if (availableDoctors.some(item => item.doctorId === preferredDoctor)) doctorSelect.value = preferredDoctor;
                else if (availableDoctors.length === 1) doctorSelect.value = availableDoctors[0].doctorId;
                else doctorSelect.value = "";
                doctorSelect.disabled = current()?.role === "doctor" || !availableDoctors.length;
                loading = false;
                resetTimes();
                if (result.message && !availableDoctors.length) message.textContent = result.message;
            } catch (error) {
                if (requestVersion !== version) return;
                loading = false;
                availableDoctors = [];
                doctorSelect.replaceChildren(new Option("No doctors available", ""));
                timeSelect.replaceChildren(new Option("No available times", ""));
                message.textContent = error.message;
                saveButton.disabled = true;
            }
        };
        dateInput.addEventListener("change", loadAvailability);
        serviceSelect.addEventListener("change", loadAvailability);
        doctorSelect.addEventListener("change", resetTimes);
        timeSelect.addEventListener("change", () => {
            saveButton.disabled = !timeSelect.value || loading || !form.elements.patientId.value;
        });
        form.elements.patientId.addEventListener("change", resetTimes);
        saveButton.addEventListener("click", async () => {
            if (!form.reportValidity() || !timeSelect.value || loading) return;
            const values = new FormData(form);
            saveButton.disabled = true;
            try {
                await clinicAppointmentRequest('', {method: 'POST', body: JSON.stringify({
                    patientId: values.get('patientId'), service: values.get('service'),
                    date: values.get('date'), time: timeSelect.value, doctorId: doctorSelect.value
                })});
                await refreshClinicAppointments();
                showToast('Appointment created in SQL Server. The patient can see it in My Appointments.');
                closeModal();
                if (document.body.dataset.page === "appointments") renderAppointments();
                else window.location.href = "admin-appointments.html";
            } catch (error) {
                showToast(error.message);
                await loadAvailability();
            } finally {
                if (document.getElementById("appointmentCreateForm") === form) {
                    saveButton.disabled = !timeSelect.value || loading;
                }
            }
        });
        void loadAvailability();
    }

    async function renderSchedule() {
        mountView("admin-schedule-view");

        const doctorSelect = byId("scheduleDoctor");
        const calendar = byId("scheduleCalendar");
        const form = byId("scheduleForm");
        const dayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        const earlyWindows = [["07:00", "13:00"]];
        const lateWindows = [["15:00", "20:00"]];
        let model = { doctors: [], weekly: [], dateOverrides: [], cancelledSlots: [], bookedSlots: [] };
        let monday = getMonday(new Date());
        let loading = false;
        let actionPending = false;
        let selectedCalendarCell = null;

        function feedback(message, kind = "info") {
            const el = byId("scheduleFeedback");
            if (!el) return;
            el.hidden = !message;
            el.textContent = message || "";
            el.dataset.kind = kind;
        }

        function getMonday(date) {
            const copy = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            copy.setDate(copy.getDate() - (copy.getDay() + 6) % 7);
            return copy;
        }

        function formatLocalDate(date) {
            return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
        }

        function plusDays(date, count) {
            const result = new Date(date);
            result.setDate(result.getDate() + count);
            return result;
        }

        function selectedDoctor() {
            return model.doctors.find(doctor => String(doctor.id) === doctorSelect.value);
        }

        function ownWeeklyRows(doctorId, day) {
            return model.weekly.filter(row => Number(row.doctorId) === Number(doctorId) && Number(row.dayOfWeek) === day)
                .sort((a, b) => String(a.startTime).localeCompare(String(b.startTime)))
                .map(row => [String(row.startTime).slice(0, 5), String(row.endTime).slice(0, 5)]);
        }

        function ownDateRows(doctorId, dayString) {
            const rows = model.dateOverrides.filter(row => Number(row.doctorId) === Number(doctorId) && row.date === dayString);
            return rows.length ? rows.filter(row => !row.isClosed)
                .map(row => [String(row.startTime).slice(0, 5), String(row.endTime).slice(0, 5)]) : null;
        }

        function actualWindows(doctorId, day, targetDate) {
            if (day === 7) return [];
            const exception = ownDateRows(doctorId, targetDate);
            return exception === null ? ownWeeklyRows(doctorId, day) : exception;
        }

        function matchShift(windows) {
            if (!windows.length) return "off";
            const same = preset => windows.length === preset.length && windows.every((item, index) => item[0] === preset[index][0] && item[1] === preset[index][1]);
            return same(earlyWindows) ? "early" : same(lateWindows) ? "late" : "custom";
        }

        function timeToMinutes(value) {
            const parts = String(value).split(":").map(Number);
            return parts[0] * 60 + parts[1];
        }

        function editorShift(windows) {
            const preset = matchShift(windows);
            if (preset !== "custom") return preset;
            const firstStart = timeToMinutes(windows[0][0]);
            return firstStart < 12 * 60 ? "early" : "late";
        }

        function editorMarkup(day, windows) {
            const shift = editorShift(windows);
            const start = windows[0]?.[0] || "";
            const end = windows[0]?.[1] || "";
            const extraPeriods = windows.length > 1 ? `<p class="schedule-extra-periods">${windows.length} existing time periods. Saving will replace them with this single period.</p>` : "";
            return `<div class="schedule-day-editor" data-day="${day}"><div class="day-edit-head"><strong>${dayNames[day - 1]}</strong><select aria-label="${dayNames[day - 1]} shift" data-day-shift><option value="off" ${shift === "off" ? "selected" : ""}>Off</option><option value="early" ${shift === "early" ? "selected" : ""}>Early</option><option value="late" ${shift === "late" ? "selected" : ""}>Late</option></select></div><div class="edit-time-row"><input type="time" min="07:00" max="20:00" step="1800" data-time-start="0" value="${escapeHtml(start)}" ${shift === "off" ? "disabled" : ""} aria-label="${dayNames[day - 1]} start time"><span>to</span><input type="time" min="07:00" max="20:00" step="1800" data-time-end="0" value="${escapeHtml(end)}" ${shift === "off" ? "disabled" : ""} aria-label="${dayNames[day - 1]} end time"></div>${extraPeriods}</div>`;
        }

        function setEditorTimes(container, windows) {
            container.querySelector('[data-time-start="0"]').value = windows[0]?.[0] || "";
            container.querySelector('[data-time-end="0"]').value = windows[0]?.[1] || "";
            const enabled = windows.length > 0;
            container.querySelectorAll('input[type="time"]').forEach(input => { input.disabled = !enabled; });
        }

        function readEditorWindows(container) {
            if (container.querySelector("[data-day-shift]").value === "off") return [];
            const start = container.querySelector('[data-time-start="0"]').value;
            const end = container.querySelector('[data-time-end="0"]').value;
            if (!start || !end) throw new Error("Fill in both Start and End times or choose Off.");
            if (start >= end) throw new Error("End time must be later than Start time.");
            return [{ startTime: start, endTime: end }];
        }

        function minutesToTime(value) {
            return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
        }

        function selectedDayOfWeek(dateString) {
            return ((new Date(`${dateString}T12:00:00`).getDay() + 6) % 7) + 1;
        }

        function matchingCancelled(doctorId, date, startMinute) {
            return (model.cancelledSlots || []).find(item =>
                Number(item.doctorId) === Number(doctorId) &&
                item.date === date &&
                timeToMinutes(item.startTime) <= startMinute &&
                timeToMinutes(item.endTime) > startMinute
            );
        }

        function otherDoctorWorking(doctorId, dateString, weekday, startMinute) {
            return model.doctors.find(other =>
                Number(other.id) !== Number(doctorId) &&
                actualWindows(other.id, weekday, dateString).some(([a, b]) =>
                    timeToMinutes(a) < startMinute + 30 && timeToMinutes(b) > startMinute
                )
            );
        }

        function slotInformation(doctor, dateString, weekday, startMinute) {
            const windows = actualWindows(doctor.id, weekday, dateString);
            const active = windows.some(([a, b]) =>
                timeToMinutes(a) <= startMinute && timeToMinutes(b) >= startMinute + 30
            );
            const cancelled = active ? matchingCancelled(doctor.id, dateString, startMinute) : null;
            const booked = active && isBookedOnDate(doctor.id, dateString, startMinute, startMinute + 30);
            const other = otherDoctorWorking(doctor.id, dateString, weekday, startMinute);
            const expired = new Date(`${dateString}T${minutesToTime(startMinute)}:00`) <= new Date();
            const status = weekday === 7 ? "closed" :
                cancelled ? "cancelled" : booked ? "booked" :
                active && other ? "conflict" : active ? "available" :
                other ? "assigned" : startMinute >= 13 * 60 && startMinute < 15 * 60 ? "break" : "off";
            return { status, active, cancelled, booked, other, expired };
        }

        function doctorDayCancelled(doctorId, dateString) {
            return model.dateOverrides.some(row => Number(row.doctorId) === Number(doctorId) &&
                row.date === dateString && row.isClosed === true);
        }

        function calendarDoctorEntries(dateString, weekday, startMinute) {
            if (weekday === 7) return [];
            return model.doctors.flatMap(item => {
                const active = actualWindows(item.id, weekday, dateString).some(([a, b]) =>
                    timeToMinutes(a) <= startMinute && timeToMinutes(b) >= startMinute + 30
                );
                const dayCancelled = doctorDayCancelled(item.id, dateString);
                const originalWindow = dayCancelled && ownWeeklyRows(item.id, weekday).some(([a, b]) =>
                    timeToMinutes(a) <= startMinute && timeToMinutes(b) >= startMinute + 30
                );
                if (!active && !originalWindow) return [];
                const slotCancelled = active && matchingCancelled(item.id, dateString, startMinute);
                const booked = active && isBookedOnDate(item.id, dateString, startMinute, startMinute + 30);
                const status = dayCancelled || slotCancelled ? "cancelled" : booked ? "booked" : "available";
                return [{ id: item.id, name: item.name, status, reason: slotCancelled?.reason || (dayCancelled ? "Whole day cancelled" : "") }];
            });
        }

        function selectCalendarDate(dateString, startTime = null) {
            selectedCalendarCell = { date: dateString, time: startTime };
            byId("exceptionDate").value = dateString;
            displaySelectedDateException();
            renderCalendar();
        }

        function updateCalendarActions() {
            const panel = byId("scheduleSelectionActions");
            if (!panel) return;
            const doctor = selectedDoctor();
            const selected = selectedCalendarCell;
            const title = byId("scheduleSelectionTitle");
            const description = byId("scheduleSelectionDescription");
            const actionAdd = byId("scheduleActionAdd");
            const actionCancel = byId("scheduleActionCancel");
            const actionRestore = byId("scheduleActionRestore");
            const actionDayOff = byId("scheduleActionDayOff");
            const actionRestoreDay = byId("scheduleActionRestoreDay");
            for (const button of [actionAdd, actionCancel, actionRestore, actionDayOff, actionRestoreDay]) button.hidden = true;
            const reasonWrap = byId("scheduleCancelReasonWrap");
            if (reasonWrap) reasonWrap.hidden = true;
            if (!doctor || !selected) {
                title.textContent = "Click a date or a 30-minute time slot";
                description.textContent = "Select a date to manage leave, or click a time slot to add, cancel or restore availability.";
                panel.dataset.selected = "false";
                return;
            }
            panel.dataset.selected = "true";
            const weekday = selectedDayOfWeek(selected.date);
            const isPastDay = selected.date < formatLocalDate(new Date());
            const datestring = new Date(`${selected.date}T12:00:00`).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short", year: "numeric" });
            title.textContent = `${doctor.name} · ${datestring}${selected.time ? ` · ${selected.time}–${minutesToTime(timeToMinutes(selected.time) + 30)}` : ""}`;
            if (weekday === 7) {
                description.textContent = "Sunday is closed for the whole clinic.";
                return;
            }
            if (isPastDay) {
                description.textContent = "Past dates are read-only. Choose today or a future date to make changes.";
                return;
            }
            if (!selected.time) {
                const windows = actualWindows(doctor.id, weekday, selected.date);
                const hasOverride = ownDateRows(doctor.id, selected.date) !== null;
                description.textContent = windows.length ? `Working hours: ${windows.map(w => w.join("–")).join(", ")}. You can mark this whole day off.` : "Doctor is off duty on this date. You can restore weekly hours or click a blank time to add a one-off appointment slot.";
                actionDayOff.hidden = !windows.length;
                actionRestoreDay.hidden = !hasOverride;
                return;
            }
            const startMinute = timeToMinutes(selected.time);
            const info = slotInformation(doctor, selected.date, weekday, startMinute);
            if (doctorDayCancelled(doctor.id, selected.date)) {
                description.textContent = `${doctor.name} — Cancel (whole day). Restore weekly hours to reopen this date.`;
                if (!info.expired) actionRestoreDay.hidden = false;
                return;
            }
            if (startMinute >= 13 * 60 && startMinute < 15 * 60) {
                description.textContent = "Clinic break: 1:00–3:00 PM. No appointment slots can be added during the rest period.";
                return;
            }
            if (info.expired) {
                description.textContent = "This time has already passed and cannot be changed.";
            } else if (info.status === "cancelled") {
                description.textContent = `Cancelled: ${info.cancelled.reason || "Doctor unavailable"}. Restore it to open this slot again.`;
                actionRestore.hidden = false;
            } else if (info.status === "booked") {
                description.textContent = "A patient is already booked here. Reschedule or cancel that appointment before removing this slot.";
            } else if (info.status === "conflict") {
                description.textContent = `Schedule overlaps ${info.other.name}. Cancel this doctor's conflicting slot or adjust the weekly hours.`;
                actionCancel.hidden = false;
                if (reasonWrap) reasonWrap.hidden = false;
            } else if (info.status === "available") {
                description.textContent = "Available for patients. Cancel this 30-minute time if the doctor is unexpectedly unavailable.";
                actionCancel.hidden = false;
                if (reasonWrap) reasonWrap.hidden = false;
            } else if (info.status === "assigned") {
                description.textContent = `Already allocated to ${info.other.name}. Change that doctor's schedule before adding this slot.`;
            } else {
                description.textContent = "No working hours here. Click Add 30-minute slot to open this date/time only.";
                actionAdd.hidden = false;
            }
        }

        function renderCalendar() {
            const doctor = selectedDoctor();
            if (!doctor) {
                calendar.textContent = "No active doctor accounts found. Add a doctor in Staff & Accounts.";
                byId("scheduleCalendarSummary").textContent = "";
                return;
            }
            const start = monday;
            const end = plusDays(start, 5);
            byId("scheduleWeekTitle").textContent = `${start.toLocaleDateString("en-GB", { day: "numeric", month: "short" })} – ${end.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}`;
            const today = formatLocalDate(new Date());
            const dates = dayNames.slice(0, 6).map((_, i) => plusDays(start, i));
            const labels = { available: "Available", cancelled: "Cancel", booked: "Booked", conflict: "Overlap", assigned: "Other doctor", off: "+ Add", closed: "Closed", break: "Break" };
            const counters = { available: 0, booked: 0, cancelled: 0, conflict: 0 };
            let html = '<div class="schedule-click-grid"><div class="schedule-grid-corner">Time</div>';
            html += dates.map((d, i) => {
                const date = formatLocalDate(d);
                const chosen = selectedCalendarCell?.date === date;
                const dayOff = !actualWindows(doctor.id, i + 1, date).length;
                const dayCancelled = doctorDayCancelled(doctor.id, date);
                const headerNote = dayCancelled ? "Cancel · whole day" : dayOff ? "Off duty" : "View / edit day";
                return `<div class="schedule-grid-heading ${date === today ? "today" : ""} ${chosen ? "selected" : ""}"><button type="button" class="schedule-date-pick" data-calendar-date="${date}" aria-label="Manage ${dayNames[i]} ${date}"><span>${dayNames[i].slice(0, 3)}</span><strong>${d.getDate()}</strong><small class="${dayCancelled ? "schedule-day-cancelled" : ""}">${escapeHtml(headerNote)}</small></button></div>`;
            }).join("");
            for (let startMinute = 7 * 60; startMinute < 20 * 60; startMinute += 30) {
                if (startMinute === 13 * 60) {
                    html += '<div class="schedule-break-time">13:00–15:00</div><div class="schedule-break-band">Clinic rest · No appointments</div>';
                }
                if (startMinute >= 13 * 60 && startMinute < 15 * 60) continue;
                const time = minutesToTime(startMinute);
                html += `<div class="schedule-time-label">${time}</div>`;
                for (let i = 0; i < 6; i++) {
                    const date = formatLocalDate(dates[i]);
                    const info = slotInformation(doctor, date, i + 1, startMinute);
                    const chosen = selectedCalendarCell?.date === date && selectedCalendarCell?.time === time;
                    const entries = calendarDoctorEntries(date, i + 1, startMinute)
                        .filter(item => Number(item.id) === Number(doctor.id));
                    const entry = entries[0];
                    const status = entry?.status === "cancelled" ? "cancelled" : info.status;
                    if (Object.hasOwn(counters, status)) counters[status]++;
                    const accessible = `${doctor.name} · ${date} ${time}–${minutesToTime(startMinute + 30)} · ${status === "cancelled" ? "Cancel" : labels[status] || status}`;
                    const emptyLabel = status === "assigned" && info.other ? `${info.other.name} on duty` : (labels[status] || status);
                    const name = entry ? `<span class="schedule-doctor-chip doctor-${entry.status}" title="${escapeHtml(accessible)}"><span class="schedule-chip-name">${escapeHtml(doctor.name)}</span>${entry.status === "cancelled" ? '<b class="schedule-chip-cancel">Cancel</b>' : entry.status === "booked" ? '<b class="schedule-chip-booked">Booked</b>' : info.status === "conflict" ? '<b class="schedule-chip-conflict">Overlap</b>' : ""}</span>` : `<span class="schedule-cell-label">${escapeHtml(emptyLabel)}</span>`;
                    const expired = info.expired ? " schedule-expired" : "";
                    html += `<button type="button" class="schedule-grid-cell state-${status}${expired}${chosen ? " is-selected" : ""}" data-calendar-slot="${date}" data-calendar-time="${time}" aria-label="${escapeHtml(accessible)}" title="${escapeHtml(accessible)}">${name}</button>`;
                }
            }
            const top = calendar.scrollTop;
            const left = calendar.scrollLeft;
            calendar.innerHTML = html + '</div>';
            calendar.scrollTop = top;
            calendar.scrollLeft = left;
            byId("scheduleCalendarSummary").textContent = `${doctor.name} · ${counters.available} available · ${counters.booked} booked · ${counters.cancelled} cancelled${counters.conflict ? ` · ${counters.conflict} overlapping (please edit working hours)` : ""} · 30-minute slots · Sunday closed`;
            updateCalendarActions();
        }

        async function performCalendarAction(action) {
            if (actionPending) return;
            const doctor = selectedDoctor();
            const selected = selectedCalendarCell;
            if (!doctor || !selected) return;
            const date = selected.date;
            const startTime = selected.time;
            const root = `/api/admin/schedule-editor/doctors/${encodeURIComponent(doctor.code)}`;
            let path, options;
            if (action === "cancel" && startTime) {
                const reason = byId("scheduleCancelReason")?.value.trim() || "Doctor unavailable";
                path = `${root}/cancel-slot`;
                options = { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scheduleDate: date, startTime, endTime: minutesToTime(timeToMinutes(startTime) + 30), reason }) };
            } else if (action === "restore" && startTime) {
                path = `${root}/cancel-slot/${date}/${encodeURIComponent(startTime)}`;
                options = { method: "DELETE" };
            } else if (action === "add" && startTime) {
                if (!confirm(`Add ${doctor.name} on ${date}, ${startTime}–${minutesToTime(timeToMinutes(startTime) + 30)}?\nThis is a one-time change, not a recurring weekly shift.`)) return;
                path = `${root}/add-slot`;
                options = { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scheduleDate: date, startTime }) };
            } else if (action === "dayoff") {
                if (!confirm(`Mark ${doctor.name} off for the WHOLE day on ${date}?\nAlready booked appointments must be rescheduled first.`)) return;
                path = `${root}/date`;
                options = { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scheduleDate: date, windows: [] }) };
            } else if (action === "restore-day") {
                if (!confirm(`Remove the exception on ${date} and follow ${doctor.name}'s weekly schedule again?`)) return;
                path = `${root}/date/${date}`;
                options = { method: "DELETE" };
            } else return;
            const allButtons = [...byId("scheduleSelectionActions").querySelectorAll("button")];
            actionPending = true;
            allButtons.forEach(button => { button.disabled = true; });
            feedback("Saving the change to SQL Server…", "info");
            try {
                const result = await readApi(path, options);
                await loadFromSql();
                feedback(result.message || "Saved to SQL Server.", "success");
                showToast(result.message || "Schedule saved to SQL Server.");
            } catch (error) {
                feedback(`Not saved: ${error.message}`, "error");
                await loadFromSql();
            } finally {
                actionPending = false;
                allButtons.forEach(button => { button.disabled = false; });
                updateCalendarActions();
            }
        }

        function renderExceptions() {
            const doctor = selectedDoctor();
            if (!doctor) return;
            const rows = model.dateOverrides.filter(row => Number(row.doctorId) === Number(doctor.id));
            const dates = [...new Set(rows.map(row => row.date))].sort();
            const list = byId("scheduleExceptionList");
            list.innerHTML = dates.length ? dates.map(date => {
                const own = ownDateRows(doctor.id, date);
                const summary = own?.length ? own.map(w => `${w[0]}–${w[1]}`).join(" & ") : "Closed";
                return `<div class="schedule-exception-line"><strong>${escapeHtml(date)}</strong><span>${escapeHtml(summary)}</span></div>`;
            }).join("") : '<p class="muted-text">No date exceptions saved.</p>';
        }

        function displaySelectedDateException() {
            const doctor = selectedDoctor();
            const date = byId("exceptionDate").value;
            const override = doctor && date ? ownDateRows(doctor.id, date) : null;
            const dayIndex = date ? ((new Date(`${date}T12:00:00`).getDay() + 6) % 7) + 1 : 7;
            const windows = override !== null ? override : doctor && date ? ownWeeklyRows(doctor.id, dayIndex) : [];
            const mode = byId("exceptionMode");
            mode.value = windows.length ? editorShift(windows) : "closed";
            const fields = byId("exceptionTimeFields");
            fields.hidden = mode.value === "closed";
            for (const index of [0, 1]) {
                fields.querySelector(`[data-ex-start="${index}"]`).value = windows?.[index]?.[0] || "";
                fields.querySelector(`[data-ex-end="${index}"]`).value = windows?.[index]?.[1] || "";
            }
            const note = byId("scheduleMultipleWindowsNote");
            if (note) {
                note.hidden = windows.length <= 2;
                note.textContent = windows.length > 2 ? `${windows.length} separate periods exist on this date. Manage individual times by clicking the calendar; saving the two-period form would replace the extra periods.` : "";
            }
        }

        function isBookedOnDate(doctorId, date, start, end) {
            return (model.bookedSlots || []).some(row =>
                Number(row.doctorId) === Number(doctorId) && row.date === date &&
                timeToMinutes(row.startTime) < end &&
                (row.endTime ? timeToMinutes(row.endTime) : timeToMinutes(row.startTime) + 30) > start
            );
        }

        function renderDoctor() {
            const doctor = selectedDoctor();
            if (!doctor) { renderCalendar(); return; }
            byId("scheduleDoctorName").textContent = doctor.name;
            byId("scheduleDoctorAvatar").textContent = initials(doctor.name);
            const weekdays = dayNames.slice(0, 6);
            form.innerHTML = `<div class="full schedule-edit-caption">Early 7:00 AM–1:00 PM · Rest 1:00–3:00 PM · Late 3:00–8:00 PM. Choose Off for non-working days. New doctors can be scheduled here after Admin creates their accounts.</div>${weekdays.map((_, i) => editorMarkup(i + 1, ownWeeklyRows(doctor.id, i + 1))).join("")}`;
            form.querySelectorAll("[data-day-shift]").forEach(select => {
                select.addEventListener("change", () => {
                    const panel = select.closest("[data-day]");
                    const options = select.value === "early" ? earlyWindows : select.value === "late" ? lateWindows : [];
                    setEditorTimes(panel, options);
                });
            });
            renderCalendar();
            renderExceptions();
            displaySelectedDateException();
        }

        async function readApi(path, options) {
            const response = await fetch(path, { credentials: "same-origin", cache: "no-store", ...options });
            const text = await response.text();
            let payload;
            try { payload = JSON.parse(text); } catch { throw new Error(`Schedule API error (HTTP ${response.status}). Check Port 8000 Terminal.`); }
            if (!response.ok) {
                const detail = Array.isArray(payload.detail)
                    ? payload.detail.map(item => item.msg || "Invalid schedule data").join("; ")
                    : typeof payload.detail === "string" ? payload.detail : `Request failed: HTTP ${response.status}`;
                throw new Error(detail);
            }
            return payload;
        }

        async function loadFromSql() {
            if (loading) return;
            loading = true;
            if (!model.doctors.length) calendar.textContent = "Loading doctor schedules from SQL Server...";
            try {
                model = await readApi("/api/admin/schedule-editor");
                const selected = doctorSelect.value;
                doctorSelect.innerHTML = model.doctors.map(doctor => `<option value="${doctor.id}">${escapeHtml(doctor.name)}</option>`).join("");
                if (model.doctors.some(doctor => String(doctor.id) === selected)) doctorSelect.value = selected;
                renderDoctor();
            } catch (error) {
                calendar.textContent = error.message;
                feedback(`Cannot load SQL Server schedule: ${error.message}`, "error");
            } finally { loading = false; }
        }

        function getExceptionWindows() {
            if (byId("exceptionMode").value === "closed") return [];
            const windows = [];
            const area = byId("exceptionTimeFields");
            for (const i of [0, 1]) {
                const a = area.querySelector(`[data-ex-start="${i}"]`).value;
                const b = area.querySelector(`[data-ex-end="${i}"]`).value;
                if (a || b) {
                    if (!a || !b) throw new Error("Please fill in both start and end times for the date exception.");
                    windows.push({ startTime: a, endTime: b });
                }
            }
            if (!windows.length) throw new Error("Select Closed or enter at least one working time.");
            return windows;
        }

        form.addEventListener("submit", async event => {
            event.preventDefault();
            const doctor = selectedDoctor();
            if (!doctor) return;
            const buttons = [byId("scheduleSaveWeeklyTop")].filter(Boolean);
            try {
                const days = [...form.querySelectorAll("[data-day]")].map(panel => ({ dayOfWeek: Number(panel.dataset.day), windows: readEditorWindows(panel) }));
                const multipleDays = days.filter(day => ownWeeklyRows(doctor.id, day.dayOfWeek).length > 1).map(day => dayNames[day.dayOfWeek - 1]);
                if (multipleDays.length && !confirm(`${multipleDays.join(", ")} currently have multiple saved time periods. Saving will replace those with one period each. Continue?`)) return;
                buttons.forEach(button => { button.disabled = true; });
                const result = await readApi(`/api/admin/schedule-editor/doctors/${encodeURIComponent(doctor.code)}/weekly`, {
                    method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ days })
                });
                showToast(result.message || "Schedule saved to SQL Server.");
                await loadFromSql();
            } catch (error) {
                feedback(`Unable to save weekly hours: ${error.message}`, "error");
            } finally { buttons.forEach(button => { button.disabled = false; }); }
        });

        doctorSelect.addEventListener("change", () => { selectedCalendarCell = null; feedback(""); renderDoctor(); });
        byId("scheduleToday").addEventListener("click", () => { selectedCalendarCell = null; monday = getMonday(new Date()); renderCalendar(); });
        byId("schedulePreviousWeek").addEventListener("click", () => { selectedCalendarCell = null; monday = plusDays(monday, -7); renderCalendar(); });
        byId("scheduleNextWeek").addEventListener("click", () => { selectedCalendarCell = null; monday = plusDays(monday, 7); renderCalendar(); });
        calendar.addEventListener("click", event => {
            const slot = event.target.closest("[data-calendar-slot]");
            if (slot) {
                selectCalendarDate(slot.dataset.calendarSlot, slot.dataset.calendarTime);
                return;
            }
            const day = event.target.closest("[data-calendar-date]");
            if (day) selectCalendarDate(day.dataset.calendarDate);
        });
        for (const [action, id] of [["add","scheduleActionAdd"], ["cancel","scheduleActionCancel"], ["restore","scheduleActionRestore"], ["dayoff","scheduleActionDayOff"], ["restore-day","scheduleActionRestoreDay"]]) {
            byId(id).addEventListener("click", () => performCalendarAction(action));
        }
        byId("scheduleRefreshSql").addEventListener("click", loadFromSql);
        byId("exceptionDate").min = formatLocalDate(new Date());
        byId("exceptionDate").value = formatLocalDate(new Date());
        byId("exceptionDate").addEventListener("change", () => {
            const dateString = byId("exceptionDate").value;
            if (dateString) {
                monday = getMonday(new Date(`${dateString}T12:00:00`));
                selectedCalendarCell = { date: dateString, time: null };
            }
            displaySelectedDateException();
            renderCalendar();
        });
        byId("exceptionMode").addEventListener("change", () => {
            const mode = byId("exceptionMode").value;
            const fields = byId("exceptionTimeFields");
            fields.hidden = mode === "closed";
            const preset = mode === "early" ? earlyWindows : mode === "late" ? lateWindows : [];
            for (const index of [0, 1]) {
                fields.querySelector(`[data-ex-start="${index}"]`).value = preset[index]?.[0] || "";
                fields.querySelector(`[data-ex-end="${index}"]`).value = preset[index]?.[1] || "";
            }
        });
        byId("saveScheduleException").addEventListener("click", async event => {
            const doctor = selectedDoctor();
            const targetDate = byId("exceptionDate").value;
            if (!doctor || !targetDate) { alert("Choose a date first."); return; }
            const button = event.currentTarget;
            try {
                const windows = getExceptionWindows();
                const existing = ownDateRows(doctor.id, targetDate);
                if (existing && existing.length > 2 && !confirm(`This date has ${existing.length} separate periods. Saving this form will replace them with the periods shown here. Continue?`)) return;
                button.disabled = true;
                const result = await readApi(`/api/admin/schedule-editor/doctors/${encodeURIComponent(doctor.code)}/date`, {
                    method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scheduleDate: targetDate, windows })
                });
                showToast(result.message);
                await loadFromSql();
            } catch (error) {
                feedback(`Unable to save this date: ${error.message}`, "error");
            } finally { button.disabled = false; }
        });
        byId("clearScheduleException").addEventListener("click", async event => {
            const doctor = selectedDoctor();
            const targetDate = byId("exceptionDate").value;
            if (!doctor || !targetDate) { alert("Choose a date first."); return; }
            const button = event.currentTarget;
            try {
                button.disabled = true;
                const result = await readApi(`/api/admin/schedule-editor/doctors/${encodeURIComponent(doctor.code)}/date/${targetDate}`, { method: "DELETE" });
                showToast(result.message);
                await loadFromSql();
            } catch (error) {
                feedback(`Unable to restore weekly hours: ${error.message}`, "error");
            } finally { button.disabled = false; }
        });
        await loadFromSql();
    }

    function renderPatients() {
        const user = current();
        const state = data();
        const submittedCount = state.patients.filter((patient) => patient.preConsultation.submitted).length;
        const rows = state.patients.map((patient, index) => {
            const appointments = state.appointments.filter((appointment) => appointment.patientId === patient.id && (user.role === "staff" || appointment.doctorId === user.id));
            return `<tr data-patient-index="${index}">
                <td>
                    <div class="directory-row">
                        ${patientAvatar(patient.name, patient.photo)}
                        <span><strong>${escapeHtml(patient.name)}</strong><small>${escapeHtml(patient.id)}</small><small>${escapeHtml(patient.email)}</small><small>${appointments.length} appointment${appointments.length === 1 ? "" : "s"}</small></span>
                        <span><small>${escapeHtml(patient.phone)}</small><small>${patient.lastVisit ? `Last visit - ${shortDate(patient.lastVisit)}` : "No previous visit"}</small></span>
                    </div>
                </td>
                <td>${badge(patient.preConsultation.submitted ? "Submitted" : "Not submitted")}</td>
                <td><button class="text-link" data-patient="${patient.id}">View</button></td>
            </tr>`;
        });
        mountView("admin-patient-view");
        byId("patientDirectoryCount").textContent = state.patients.length;
        byId("patientRecordCount").textContent = `${state.patients.length} records`;
        byId("submittedPreconsultCount").textContent = `${submittedCount} submitted`;
        byId("pendingPreconsultCount").textContent = `${state.patients.length - submittedCount} not submitted`;
        byId("patientTable").innerHTML = table(["Patient / Contact / Visits", "Pre-consultation", ""], rows);
        const patientRows = [...document.querySelectorAll("#patientTable tbody tr[data-patient-index]")];
        const patientSearch = byId("patientSearch");
        const patientTypeFilter = byId("patientTypeFilter");
        const patientPreconsultFilter = byId("patientPreconsultFilter");
        const patientFilterEmpty = byId("patientFilterEmpty");
        const availableAppointments = state.appointments.filter((appointment) => user.role === "staff" || appointment.doctorId === user.id);

        function applyPatientFilters() {
            const query = patientSearch.value.trim().toLowerCase();
            const patientType = patientTypeFilter.value;
            const preconsultStatus = patientPreconsultFilter.value;
            let visibleCount = 0;
            let firstVisibleId = "";
            let selectedStillVisible = false;

            patientRows.forEach((row) => {
                const patient = state.patients[Number(row.dataset.patientIndex)];
                if (!patient) return;
                const searchable = [patient.name, patient.id, patient.email, patient.phone].map((value) => String(value ?? "")).join(" ").toLowerCase();
                const appointmentCount = availableAppointments.filter((appointment) => appointment.patientId === patient.id).length;
                const hasVisited = Boolean(patient.lastVisit);
                const submitted = Boolean(patient.preConsultation?.submitted);
                const matchType = !patientType ||
                    (patientType === "with-appointments" && appointmentCount > 0) ||
                    (patientType === "previous-visit" && hasVisited) ||
                    (patientType === "no-previous-visit" && !hasVisited);
                const matchPreconsult = !preconsultStatus ||
                    (preconsultStatus === "submitted" && submitted) ||
                    (preconsultStatus === "not-submitted" && !submitted);
                const visible = (!query || searchable.includes(query)) && matchType && matchPreconsult;
                row.hidden = !visible;
                if (visible) {
                    visibleCount += 1;
                    if (!firstVisibleId) firstVisibleId = patient.id;
                    if (row.classList.contains("selected-row")) selectedStillVisible = true;
                }
            });

            byId("patientRecordCount").textContent = visibleCount === state.patients.length
                ? `${visibleCount} records`
                : `${visibleCount} of ${state.patients.length} records`;
            patientFilterEmpty.hidden = visibleCount !== 0;
            if (!visibleCount) {
                patientRows.forEach((row) => {
                    row.classList.remove("selected-row");
                    const button = row.querySelector("button[data-patient]");
                    if (button) {
                        button.textContent = "View";
                        button.setAttribute("aria-pressed", "false");
                    }
                });
                byId("patientProfile").textContent = "No matching patient selected.";
            } else if (!selectedStillVisible) {
                drawPatientProfile(firstVisibleId);
            }
        }

        patientSearch.addEventListener("input", applyPatientFilters);
        patientTypeFilter.addEventListener("change", applyPatientFilters);
        patientPreconsultFilter.addEventListener("change", applyPatientFilters);
        byId("patientCreateAppointment")?.addEventListener("click", openAppointmentCreate);
        document.querySelectorAll("#patientTable [data-patient]").forEach((button) => button.addEventListener("click", () => drawPatientProfile(button.dataset.patient)));

        // Only show real patients from the current SQL-backed state, never demo names.
        // Doctors see reminders only for patients assigned to their appointments.
        const pendingPatients = state.patients.filter((patient) =>
            !patient.preConsultation?.submitted &&
            (user.role === "staff" || state.appointments.some((appointment) =>
                appointment.patientId === patient.id && appointment.doctorId === user.id
            ))
        );
        const followupList = byId("patientFollowupList");
        if (followupList) {
            followupList.innerHTML = pendingPatients.map((patient) => `
                <section class="followup-card">
                    <div><span class="nav-icon icon-clipboard"></span>
                        <strong>Pre-consultation to follow up</strong>
                        <small>${escapeHtml(patient.name)} - ${escapeHtml(patient.id)} - Not submitted</small>
                    </div>
                    <button class="secondary-btn" data-followup-patient="${escapeHtml(patient.id)}" type="button">View patient</button>
                </section>
            `).join("");
            followupList.querySelectorAll("[data-followup-patient]").forEach((button) => {
                button.addEventListener("click", () => {
                    drawPatientProfile(button.dataset.followupPatient);
                    openPatient(button.dataset.followupPatient);
                });
            });
        }

        if (state.patients.length) {
            drawPatientProfile(state.patients[0].id);
            applyPatientFilters();
        } else byId('patientProfile').textContent = 'No patient records in SQL Server.';
    }

    function drawPatientProfile(id) {
        const state = data();
        const patient = state.patients.find((item) => item.id === id);
        const appointments = state.appointments.filter((item) => item.patientId === id);
        const panel = byId("patientProfile");
        if (!patient || !panel) return;

        // The highlighted row and its Selected/View label must follow the profile.
        document.querySelectorAll("#patientTable tbody tr").forEach((row) => {
            const button = row.querySelector("button[data-patient]");
            if (!button) return;
            const isSelected = button.dataset.patient === String(id);
            row.classList.toggle("selected-row", isSelected);
            button.textContent = isSelected ? "Selected" : "View";
            button.setAttribute("aria-pressed", String(isSelected));
        });

        panel.innerHTML = `
            <div class="patient-profile-head">${patientAvatar(patient.name, patient.photo)}<div><h2>${escapeHtml(patient.name)}</h2><span>${escapeHtml(patient.id)}</span></div></div>
            <section>
                <h3>Contact details</h3>
                <p><span class="nav-icon icon-message"></span><small>Email</small>${escapeHtml(patient.email)}</p>
                <p><span class="nav-icon icon-phone"></span><small>Phone</small>${escapeHtml(patient.phone)}</p>
                <p><small>Date of birth</small>${escapeHtml(patient.birthDate || "Not provided")}</p>
                <p><small>Preferred contact</small>${escapeHtml(patient.contactMethod === "email" ? "Email" : "Phone")}</p>
                <p><small>Address</small>${escapeHtml(patient.address || "Not provided")}</p>
            </section>
            <section>
                <h3>Visit information</h3>
                <dl class="detail-grid"><div><dt>Appointments</dt><dd>${appointments.length}</dd></div><div><dt>Last visit</dt><dd>${patient.lastVisit ? shortDate(patient.lastVisit) : 'No previous visit'}</dd></div></dl>
            </section>
            <section>
                <div class="selected-head"><h3>Pre-consultation</h3>${badge(patient.preConsultation.submitted ? "Submitted" : "Not submitted")}</div>
                <p>Review the submitted pre-consultation before the patient's appointment.</p>
                <button class="secondary-btn" data-open-patient-modal="${patient.id}">View pre-consultation</button>
            </section>
            <div class="row-actions"><button class="primary-btn" data-open-patient-modal="${patient.id}">View patient</button><a class="secondary-btn" href="admin-appointments.html">Appointments</a></div>
        `;
        document.querySelectorAll("[data-open-patient-modal]").forEach((button) => button.addEventListener("click", () => openPatient(button.dataset.openPatientModal)));
    }

    function openPatient(id) {
        const state = data();
        const user = current();
        const patient = state.patients.find((item) => item.id === id);
        const pre = patient.preConsultation;
        openModal("Patient Profile", `
            <dl>
                <dt>Name</dt><dd>${escapeHtml(patient.name)}</dd><dt>Email</dt><dd>${escapeHtml(patient.email)}</dd><dt>Phone</dt><dd>${escapeHtml(patient.phone)}</dd>
                <dt>Date of birth</dt><dd>${escapeHtml(patient.birthDate || "Not provided")}</dd>
                <dt>Preferred contact</dt><dd>${escapeHtml(patient.contactMethod === "email" ? "Email" : "Phone")}</dd>
                <dt>Address</dt><dd>${escapeHtml(patient.address || "Not provided")}</dd><dt>Date Joined</dt><dd>${shortDate(patient.joined)}</dd>
                <dt>Appointment History</dt><dd>${state.appointments.filter((item) => item.patientId === id).map((item) => `${item.id} ${item.service} ${badge(item.status)}`).join("<br>") || "No appointments"}</dd>
                <dt>Pre-Consultation</dt><dd>${pre.submitted ? "Submitted" : "Not submitted"}</dd>
                ${user.role === "doctor" && pre.submitted ? `<dt>Wellness Details</dt><dd>Energy: ${escapeHtml(pre.energy)}<br>Sleep: ${escapeHtml(pre.sleep)}<br>Digestion: ${escapeHtml(pre.digestion)}<br>Temperature: ${escapeHtml(pre.temperature)}<br>Mood: ${escapeHtml(pre.mood)}<br>Concerns: ${escapeHtml(pre.concerns)}<br>Notes: ${escapeHtml(pre.notes)}</dd>` : ""}
                ${user.role === "doctor" ? `<dt>Care Plans</dt><dd>${state.carePlans.filter((plan) => plan.patientId === id).length} saved care plan(s)</dd>` : ""}
            </dl>
        `);
    }

    function latestCarePlan(state, appointmentId) {
        return state.carePlans
            .filter((plan) => plan.appointmentId === appointmentId)
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    }

    function careCommandFormula(state, notes) {
        if (notes.formula) return notes.formula;
        if (notes.productId) {
            return state.products.find((product) => product.id === notes.productId)?.name || "";
        }
        return "";
    }

    function careFollowUpDays(notes) {
        const options = ["3 days", "7 days", "14 days"];
        if (options.includes(notes.followUpRecommendation)) {
            return notes.followUpRecommendation;
        }
        return options.includes(notes.followUp) ? notes.followUp : "";
    }

    function renderCarePlan() {
        const user = current();
        const state = data();
        const params = new URLSearchParams(location.search);
        const visibleAppointments = state.appointments.filter((item) => user.role !== "doctor" || item.doctorId === user.id);
        const selected = visibleAppointments.find((item) => item.id === params.get("appointment"));

        mountView("admin-care-plan-view");
        byId("carePlanDescription").textContent = user.role === "doctor"
            ? "Select a patient appointment to write or update clinical notes."
            : "Select a patient appointment to view the doctor's clinical notes.";
        byId("carePlanRecordCount").textContent = `${visibleAppointments.length} records`;
        byId("careDoctor").innerHTML = user.role === "doctor"
            ? `<option value="${escapeHtml(user.id)}">My Appointments</option>`
            : `<option value="">All Doctors</option>${state.doctors.map((doctor) => `<option value="${escapeHtml(doctor.id)}">${escapeHtml(doctor.name)}</option>`).join("")}`;
        byId("careDoctor").disabled = user.role === "doctor";

        if (user.role === "doctor") byId("careDoctor").value = user.id;
        ["careSearch", "careDate", "careDoctor", "careService", "careStatus"].forEach((id) => {
            byId(id).addEventListener(id === "careSearch" ? "input" : "change", () => drawCarePlanList());
        });
        if (user.role === "doctor") byId("careDoctor").closest("label").remove();
        drawCarePlanList(selected?.id);
    }

    function filteredCareAppointments() {
        const user = current();
        const state = data();
        const query = (byId("careSearch")?.value || "").toLowerCase();
        const dateFilter = byId("careDate")?.value || "";
        const doctorFilter = user.role === "doctor" ? user.id : byId("careDoctor")?.value;
        const serviceFilter = byId("careService")?.value;
        const statusFilter = byId("careStatus")?.value;
        return state.appointments.filter((item) => {
            const plan = latestCarePlan(state, item.id);
            const planStatus = plan?.status || "No care plan";
            return (user.role !== "doctor" || item.doctorId === user.id) &&
                (!query || `${item.id} ${item.patient} ${item.contact}`.toLowerCase().includes(query)) &&
                (!dateFilter || String(item.date).slice(0, 10) === dateFilter) &&
                (!doctorFilter || item.doctorId === doctorFilter) &&
                (!serviceFilter || item.service === serviceFilter) &&
                (!statusFilter || planStatus === statusFilter);
        }).sort(compareAppointmentsForDisplay);
    }

    function drawCarePlanList(selectedId) {
        const state = data();
        const records = filteredCareAppointments();
        const selected = records.find((item) => item.id === selectedId) || records[0];
        const careList = byId("carePlanList");
        const previousScrollTop = careList.scrollTop;
        const previousScrollLeft = careList.scrollLeft;
        careList.innerHTML = table(
            ["Patient / Contact", "Service", "Date / Time", "Doctor / Room", "Care Plan", "Actions"],
            records.map((item) => {
                const plan = latestCarePlan(state, item.id);
                return `
                    <tr class="${selected?.id === item.id ? "selected-row" : ""}">
                        <td><div class="person-cell">${appointmentPatientAvatar(item)}<span><strong>${escapeHtml(item.patient)}</strong><small>${escapeHtml(item.id)}<br>${escapeHtml(item.contact)}</small></span></div></td>
                        <td>${escapeHtml(item.service)}</td>
                        <td><strong>${shortDate(item.date)}</strong> ${appointmentDateBadge(item.date)}<br><small>${formatTime(item.time)}</small></td>
                        <td>${escapeHtml(item.doctor)}<br><small>${escapeHtml(item.room)}</small></td>
                        <td>${badge(plan?.status || "No care plan")}</td>
                        <td><button class="text-link" data-select-care="${item.id}">${selected?.id === item.id ? "Selected" : "View"}</button></td>
                    </tr>
                `;
            })
        );
        careList.scrollTop = previousScrollTop;
        careList.scrollLeft = previousScrollLeft;
        document.querySelectorAll("[data-select-care]").forEach((button) => button.addEventListener("click", () => {
            drawCarePlanList(button.dataset.selectCare);
        }));
        drawCarePlanDetail(selected);
    }

    function drawCarePlanDetail(appointment) {
        const state = data();
        const user = current();
        const panel = byId("carePlanDetail");
        if (!panel) return;
        if (!appointment) {
            panel.innerHTML = `<section class="panel"><h2>No appointment selected</h2><p>No matching appointment found for the current filters.</p></section>`;
            return;
        }
        const patient = state.patients.find((item) => item.id === appointment.patientId);
        const pre = patient?.preConsultation || {};
        const plan = latestCarePlan(state, appointment.id);
        const notes = plan?.notes || {};
        panel.innerHTML = `
            <div class="care-header">
                <div><strong>Patient</strong><br>${escapeHtml(patient?.name || appointment.patient)}</div><div><strong>Appointment</strong><br>${escapeHtml(appointment.id)}</div><div><strong>Service</strong><br>${escapeHtml(appointment.service)}</div><div><strong>Status</strong><br>${badge(appointment.status)}</div>
            </div>
            <section class="panel">
                <h2>Pre-consultation Summary</h2>
                <div class="kpi-grid" style="margin-top:14px">
                    ${["age", "duration", "energy", "sleep", "digestion", "temperature", "mood", "concerns", "notes"].map((key) => `<div class="pre-card"><strong>${escapeHtml(key)}</strong>${escapeHtml(pre[key] || "Not submitted")}</div>`).join("")}
                </div>
            </section>
            ${user.role === "doctor" ? carePlanForm(state, appointment, notes) : carePlanReadOnly(state, plan)}
        `;
        if (user.role === "doctor") bindCarePlanForm(appointment, patient);
        else bindMedicinePreparation(appointment);
    }

    function carePlanForm(state, appointment, notes) {
        const followUpDays = careFollowUpDays(notes);
        const canWrite = ["Checked In", "In Consultation", "Completed"].includes(appointment.status);
        const canComplete = ["Checked In", "In Consultation"].includes(appointment.status);
        return `
            <section class="panel" style="margin-top:18px">
                <h2>Doctor Consultation</h2>
                ${!canWrite ? '<p role="status" style="margin:12px 0;padding:12px 16px;border:1px solid #d5e5dc;border-radius:9px;background:#f0f7f3;color:#205a4b;font-weight:600">The patient must be Checked In before you can fill in Doctor Consultation or complete the appointment.</p>' : ''}
                <form id="carePlanForm">
                    <fieldset class="form-grid" ${canWrite ? '' : 'disabled'} style="border:0;padding:0;margin:0;min-width:0;width:100%">
                    <label class="full"><span>Doctor Notes — Patient Problem</span><textarea name="notes" rows="5" placeholder="Record the patient's main problem and relevant consultation notes.">${escapeHtml(notes.notes || "")}</textarea></label>
                    <div class="care-command-heading full"><h3>Care Command</h3><p>Instructions for staff to prepare and coordinate the patient's care.</p></div>
                    <label class="full"><span>Care Instructions for Staff</span><textarea name="careInstructions" rows="3" placeholder="Preparation and care coordination instructions">${escapeHtml(notes.careInstructions || "")}</textarea></label>
                    <label class="full"><span>Traditional Chinese Medicine / Medicine to Prepare</span><textarea name="formula" rows="3" placeholder="Enter the formula or medicine staff should prepare. This is separate from products sold in the shop.">${escapeHtml(careCommandFormula(state, notes))}</textarea></label>
                    <label><span>Medicine Supply (Days)</span><input name="daysSupply" placeholder="e.g. 7 days" value="${escapeHtml(notes.daysSupply || "")}"></label>
                    <label class="full"><span>Follow-up Recommendation</span><select name="followUpRecommendation"><option value="">Select follow-up timing</option>${["3 days", "7 days", "14 days"].map((days) => `<option value="${days}" ${followUpDays === days ? "selected" : ""}>${days}</option>`).join("")}</select></label>
                    <label class="full"><button class="secondary-btn" type="button" id="saveDraft">Save Draft</button> <button class="primary-btn" type="submit">Save Care Plan</button> <button class="secondary-btn" type="button" id="printCarePlan">Print Care Plan</button> <button class="danger-btn" type="button" id="completeConsultation" ${canComplete ? '' : 'disabled'}>Complete Consultation</button></label>
                    </fieldset>
                </form>
            </section>
        `;
    }

    function carePlanReadOnly(state, plan) {
        const notes = plan?.notes || {};
        if (!plan) {
            return `<section class="panel staff-care-command" style="margin-top:18px"><h2>Care Command for Staff</h2><p>The doctor has not saved care instructions for this appointment yet.</p></section>`;
        }
        const followUp = careFollowUpDays(notes) || "Not specified";
        return `
            <section class="panel staff-care-command" style="margin-top:18px">
                <div class="selected-head"><div><h2>Doctor Consultation</h2><p>Read-only notes from the assigned practitioner.</p></div>${badge(plan.status)}</div>
                <dl class="detail-grid care-command-details">
                    <div><dt>Doctor Notes — Patient Problem</dt><dd style="white-space:pre-wrap">${escapeHtml(notes.notes || "Not recorded")}</dd></div>
                    <div><dt>Care Instructions for Staff</dt><dd style="white-space:pre-wrap">${escapeHtml(notes.careInstructions || "Not specified")}</dd></div>
                    <div><dt>Medicine / Formula to Prepare</dt><dd style="white-space:pre-wrap">${escapeHtml(careCommandFormula(state, notes) || "Not specified")}</dd></div>
                    <div><dt>Medicine Supply</dt><dd>${escapeHtml(notes.daysSupply || "Not specified")}</dd></div>
                    <div><dt>Follow-up Recommendation</dt><dd>${escapeHtml(followUp)}</dd></div>
                </dl>
            </section>
            <section class="panel staff-care-command" style="margin-top:18px">
                <h2>Medicine Preparation &amp; Handover</h2>
                <p>Prepare only the medicine or formula authorized by the doctor. Verify patient identity, formulation, dose, allergies and stock before handover.</p>
                <p><strong>Current status:</strong> ${escapeHtml(plan.preparationStatus || "Pending")}</p>
                <form id="medicinePreparationForm" class="form-grid">
                    <label><span>Status</span><select name="status">
                        ${["Pending", "Prepared", "Dispensed"].map((value) => `<option value="${value}" ${value === (plan.preparationStatus || "Pending") ? "selected" : ""}>${value}</option>`).join("")}
                    </select></label>
                    <label class="full"><span>Staff Preparation / Handover Notes</span>
                        <textarea name="notes" rows="3" maxlength="2000" placeholder="What was checked, prepared or handed to the patient">${escapeHtml(plan.preparationNotes || "")}</textarea>
                    </label>
                    <label class="full"><button type="submit" class="primary-btn" ${plan.status === "Draft" ? "disabled" : ""}>Save preparation status</button></label>
                </form>
                <p id="medicinePreparationMessage" aria-live="polite"></p>
            </section>
        `;
    }

    async function clinicRecordRequest(path, payload) {
        const response = await fetch(path, {
            method: "PUT", credentials: "same-origin", cache: "no-store",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(typeof result.detail === "string" ? result.detail : `Request failed: ${response.status}`);
        return result;
    }

    function bindMedicinePreparation(appointment) {
        const form = byId("medicinePreparationForm");
        if (!form) return;
        form.addEventListener("submit", async (event) => {
            event.preventDefault();
            const button = form.querySelector('button[type="submit"]');
            const message = byId("medicinePreparationMessage");
            const values = new FormData(form);
            const status = String(values.get("status") || "Pending");
            if (status === "Dispensed" && !window.confirm("Confirm this medicine has been verified and physically handed to the correct patient?")) return;
            button.disabled = true;
            message.textContent = "Saving to SQL Server...";
            try {
                await clinicRecordRequest(`/api/admin/medicine-preparation/${encodeURIComponent(appointment.id)}`, {
                    status, notes: String(values.get("notes") || "")
                });
                await window.TcmAdminData.initialize();
                drawCarePlanList(appointment.id);
                showToast("Preparation record saved.");
            } catch (error) {
                message.textContent = `Not saved: ${error.message}`;
                button.disabled = false;
            }
        });
    }

    function bindCarePlanForm(appointment, patient) {
        async function savePlan(status) {
            if (!["Checked In", "In Consultation", "Completed"].includes(appointment.status)) {
                showToast("Patient must be Checked In before Doctor Consultation can be saved.");
                return false;
            }
            const form = byId("carePlanForm");
            if (!form) return false;
            const formData = new FormData(form);
            const payload = {
                status,
                notes: String(formData.get("notes") || ""),
                formula: String(formData.get("formula") || ""),
                careInstructions: String(formData.get("careInstructions") || ""),
                daysSupply: String(formData.get("daysSupply") || ""),
                followUpRecommendation: String(formData.get("followUpRecommendation") || "")
            };
            const buttons = Array.from(form.querySelectorAll("button"));
            buttons.forEach((item) => { item.disabled = true; });
            try {
                await clinicRecordRequest(`/api/admin/clinical-notes/${encodeURIComponent(appointment.id)}`, payload);
                await window.TcmAdminData.initialize();
                drawCarePlanList(appointment.id);
                showToast(status === "Draft" ? "Draft saved to SQL Server." : "Clinical notes saved to SQL Server.");
                return true;
            } catch (error) {
                showToast(`Not saved: ${error.message}`);
                buttons.forEach((item) => { item.disabled = false; });
                return false;
            }
        }
        byId("saveDraft").addEventListener("click", () => { void savePlan("Draft"); });
        byId("carePlanForm").addEventListener("submit", (event) => {
            event.preventDefault();
            void savePlan("Saved");
        });
        byId("printCarePlan").addEventListener("click", () => window.print());
        byId("completeConsultation").addEventListener("click", async () => {
            if (!["Checked In", "In Consultation"].includes(appointment.status)) {
                showToast("Patient must be Checked In before the appointment can be completed.");
                return;
            }
            if (await savePlan("Completed")) {
                await updateAppointment(appointment.id, "Completed", "Consultation completed.", false);
            }
        });
    }

    async function inventoryRequest(path, options = {}) {
        const response = await fetch(`/api/admin/products${path}`, {
            credentials: "same-origin",
            cache: "no-store",
            ...options,
            headers: {
                "Content-Type": "application/json",
                ...(options.headers || {})
            }
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) {
            throw new Error(typeof result.detail === "string" ? result.detail : "Inventory update failed.");
        }
        return result;
    }

    async function refreshInventory() {
        const result = await inventoryRequest("");
        window.TcmAdminData.restore({
            ...data(),
            products: result.products
        });
        if (byId("productTable")) drawProducts();
    }

    function renderProducts() {
        mountView("admin-product-view");
        ["productSearch", "productCategory", "productStatus"].forEach(id => {
            byId(id).addEventListener("input", drawProducts);
        });
        byId("addProduct").addEventListener("click", () => openProductForm());
        byId("productTable").textContent = "Loading products from SQL Server...";
        refreshInventory().catch(error => {
            byId("productTable").textContent = error.message;
            showToast(error.message);
        });
    }

    function accountDirectory(state) {
        return [
            ...(Array.isArray(state.staff) ? state.staff : []),
            ...(Array.isArray(state.doctors) ? state.doctors : [])
        ].sort((a, b) => a.name.localeCompare(b.name));
    }

    function renderAccounts() {
        const state = data();
        const staffCount = Array.isArray(state.staff) ? state.staff.length : 0;
        const doctorCount = Array.isArray(state.doctors) ? state.doctors.length : 0;
        mountView("admin-account-view");
        byId("staffAccountCount").textContent = staffCount;
        byId("doctorAccountCount").textContent = doctorCount;
        byId("totalAccountCount").textContent = staffCount + doctorCount;
        byId("generateAccount").addEventListener("click", openAccountForm);
        byId("accountSearch").addEventListener("input", drawAccounts);
        byId("accountTypeFilter").addEventListener("change", drawAccounts);
        drawAccounts();
    }

    function drawAccounts() {
        const state = data();
        const query = byId("accountSearch").value.trim().toLowerCase();
        const type = byId("accountTypeFilter").value;
        const rows = accountDirectory(state)
            .filter(account => (!type || account.role === type) &&
                (!query || `${account.name} ${account.email} ${account.staffId}`.toLowerCase().includes(query)))
            .map(account => `
                <tr>
                    <td><span class="account-person"><span class="avatar mini-avatar">${safeDoctorPhoto(account.profilePicture) ? `<img class="doctor-account-photo" src="${escapeHtml(account.profilePicture)}" alt="">` : escapeHtml(account.avatar || initials(account.name))}</span><strong>${escapeHtml(account.name)}</strong></span></td>
                    <td>${escapeHtml(account.staffId)}</td>
                    <td>${escapeHtml(account.email)}</td>
                    <td><span class="badge ${account.role === "doctor" ? "scheduled" : "active"}">${account.role === "doctor" ? "Doctor" : "Staff"}</span></td>
                    <td>${account.role === "doctor" ? escapeHtml((account.services || []).join(", ") || "No services assigned") : "—"}</td>
                    <td>${account.role === "doctor" ? `<button class="mini-btn" data-doctor-photo="${escapeHtml(account.id)}">${safeDoctorPhoto(account.profilePicture) ? "Change picture" : "Add picture"}</button> <button class="mini-btn" data-doctor-edit="${escapeHtml(account.id)}">Edit services</button> <button class="mini-btn" data-doctor-login="${escapeHtml(account.id)}">Change password</button>` : ""}${account.role === "doctor" || (account.role === "staff" && account.staffId !== "staff001" && account.id !== "staff-frontdesk" && account.name?.trim().toLowerCase() !== "front desk staff") ? ` <button class="mini-btn" data-delete-account="${escapeHtml(account.id)}">Delete</button>` : account.role === "doctor" ? "" : "—"}</td>
                </tr>
            `);
        byId("accountTable").innerHTML = table(
            ["Name", "Sign-in ID", "Email", "Account type", "Doctor services", "Action"], rows);
        byId("accountTable").querySelectorAll("[data-doctor-photo]").forEach(button => {
            button.addEventListener("click", () => openDoctorPictureEditor(button.dataset.doctorPhoto));
        });
        byId("accountTable").querySelectorAll("[data-doctor-edit]").forEach(button => {
            button.addEventListener("click", () => openDoctorServiceEditor(button.dataset.doctorEdit));
        });
        byId("accountTable").querySelectorAll("[data-doctor-login]").forEach(button => {
            button.addEventListener("click", () => openDoctorLoginEditor(button.dataset.doctorLogin));
        });
        byId("accountTable").querySelectorAll("[data-delete-account]").forEach(button => {
            button.addEventListener("click", () => deleteClinicAccount(button.dataset.deleteAccount));
        });
    }

    // Doctor photos are stored as small JPEG data URLs in the existing SQL Server
    // admin_state doctor record, just like staff/doctor profile pictures.
    function safeDoctorPhoto(value) {
        return typeof value === "string" && value.length < 350000 &&
            /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(value);
    }

    function resizeDoctorPicture(file) {
        return new Promise((resolve, reject) => {
            if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
                reject(new Error("Choose a JPG, PNG, or WEBP picture.")); return;
            }
            if (file.size > 5 * 1024 * 1024) {
                reject(new Error("Choose a picture smaller than 5 MB.")); return;
            }
            const reader = new FileReader();
            reader.onerror = () => reject(new Error("Could not read this picture."));
            reader.onload = () => {
                const image = new Image();
                image.onerror = () => reject(new Error("Could not open this picture."));
                image.onload = () => {
                    if (!image.width || !image.height || image.width * image.height > 60_000_000) {
                        reject(new Error("Picture dimensions are too large.")); return;
                    }
                    const ratio = Math.min(1, 320 / Math.max(image.width, image.height));
                    const canvas = document.createElement("canvas");
                    canvas.width = Math.max(1, Math.round(image.width * ratio));
                    canvas.height = Math.max(1, Math.round(image.height * ratio));
                    const ctx = canvas.getContext("2d");
                    if (!ctx) { reject(new Error("Picture processing is unavailable.")); return; }
                    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
                    const compressed = canvas.toDataURL("image/jpeg", 0.78);
                    if (!safeDoctorPhoto(compressed)) {
                        reject(new Error("Processed picture is too large. Choose a smaller image.")); return;
                    }
                    resolve(compressed);
                };
                image.src = String(reader.result);
            };
            reader.readAsDataURL(file);
        });
    }

    function openDoctorPictureEditor(doctorId) {
        const doctor = (data().doctors || []).find(item => item.id === doctorId);
        if (!doctor) return;
        let pendingPicture = safeDoctorPhoto(doctor.profilePicture) ? doctor.profilePicture : "";
        let pendingVersion = 0;
        let processing = false;
        openModal("Doctor profile picture", `
            <p class="account-form-intro">Update ${escapeHtml(doctor.name)}'s photo. It will appear on the User Booking page and is saved to SQL Server.</p>
            <div class="admin-profile-photo-editor">
                <div class="admin-profile-photo-preview" id="doctorPicturePreview"></div>
                <div>
                    <strong>${escapeHtml(doctor.name)}</strong>
                    <p>JPG, PNG or WEBP, up to 5 MB. Image is resized before saving.</p>
                    <label class="secondary-btn admin-photo-picker" for="doctorPictureFile">Choose picture</label>
                    <input id="doctorPictureFile" type="file" accept="image/jpeg,image/png,image/webp">
                    <button class="mini-btn" id="removeDoctorPicture" type="button">Remove picture</button>
                </div>
            </div>
            <p id="doctorPictureStatus" role="status" aria-live="polite" style="margin:14px 0 0;font-size:13px;color:#315d53;min-height:20px"></p>
        `, `<button class="primary-btn" type="button" id="saveDoctorPicture">Save picture</button>`, { closeOnBackdrop: false });

        const preview = byId("doctorPicturePreview");
        const picker = byId("doctorPictureFile");
        const saveButton = byId("saveDoctorPicture");
        const removeButton = byId("removeDoctorPicture");
        const status = byId("doctorPictureStatus");
        const setStatus = (message, isError = false) => {
            status.textContent = message;
            status.style.color = isError ? "#a82e30" : "#315d53";
        };
        const drawPreview = () => {
            preview.replaceChildren();
            if (pendingPicture) {
                const image = document.createElement("img");
                image.src = pendingPicture;
                image.alt = `${doctor.name} picture preview`;
                preview.appendChild(image);
            } else {
                const initialsNode = document.createElement("span");
                initialsNode.textContent = initials(doctor.name);
                preview.appendChild(initialsNode);
            }
        };
        drawPreview();
        picker.addEventListener("change", async () => {
            const file = picker.files?.[0];
            if (!file) return;
            const version = ++pendingVersion;
            processing = true;
            saveButton.disabled = true;
            setStatus("Preparing picture...");
            try {
                const prepared = await resizeDoctorPicture(file);
                if (version !== pendingVersion) return;
                pendingPicture = prepared;
                drawPreview();
                setStatus("Picture ready. Click Save picture.");
            } catch (error) {
                if (version !== pendingVersion) return;
                picker.value = "";
                setStatus(error.message || "Unable to use this image.", true);
            } finally {
                if (version === pendingVersion) {
                    processing = false;
                    saveButton.disabled = false;
                }
            }
        });
        removeButton.addEventListener("click", () => {
            ++pendingVersion;
            processing = false;
            pendingPicture = "";
            picker.value = "";
            saveButton.disabled = false;
            drawPreview();
            setStatus("Picture will be removed when you click Save picture.");
        });
        saveButton.addEventListener("click", async () => {
            if (processing) return;
            saveButton.disabled = true;
            picker.disabled = true;
            removeButton.disabled = true;
            setStatus("Saving picture to SQL Server...");
            let saved = false;
            try {
                const response = await fetch(`/api/admin/accounts/${encodeURIComponent(doctorId)}/picture`, {
                    method: "PUT",
                    credentials: "same-origin",
                    cache: "no-store",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ photo: pendingPicture })
                });
                const responseText = await response.text();
                let result = {};
                try { result = JSON.parse(responseText); } catch (error) {}
                if (!response.ok) {
                    const detail = typeof result.detail === "string" ? result.detail : `HTTP ${response.status}: ${responseText.slice(0, 180) || "Picture upload failed."}`;
                    throw new Error(detail);
                }
                saved = true;
                try {
                    await window.TcmAdminData.initialize();
                } catch (error) {
                    setStatus("Picture saved to SQL Server. Refresh the page to display the new photo.");
                    showToast("Picture saved. Refresh the page to see the update.");
                    return;
                }
                closeModal();
                renderAccounts();
                showToast("Doctor photo saved successfully.");
            } catch (error) {
                setStatus(error.message || "Could not save the doctor picture.", true);
            } finally {
                if (!saved) {
                    saveButton.disabled = false;
                    picker.disabled = false;
                    removeButton.disabled = false;
                }
            }
        });
    }

    async function deleteClinicAccount(accountId) {
        const account = accountDirectory(data()).find(item => item.id === accountId);
        if (!account || (account.role === "staff" && (
            account.staffId === "staff001" || account.id === "staff-frontdesk" ||
            account.name?.trim().toLowerCase() === "front desk staff"
        ))) return;
        const person = account.role === "doctor" ? "doctor" : "staff account";
        if (!window.confirm(`Delete ${person} ${account.name}?\n\nThis removes the login and account from the clinic directory. Doctor booking availability will be disabled; historical records remain. Doctors with outstanding future appointments must be reassigned first.`)) return;
        const button = [...document.querySelectorAll('[data-delete-account]')]
            .find(item => item.dataset.deleteAccount === accountId);
        if (button) button.disabled = true;
        try {
            const response = await fetch(`/api/admin/accounts/${encodeURIComponent(accountId)}`, {
                method: "DELETE", credentials: "same-origin"
            });
            const result = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(result.detail || "Unable to delete account.");
            await window.TcmAdminData.initialize();
            renderAccounts();
            showToast(`${account.name} deleted from active clinic accounts.`);
        } catch (error) {
            showToast(error.message || "Unable to delete account.");
            if (button) button.disabled = false;
        }
    }

    function openDoctorLoginEditor(doctorId) {
        const doctor = data().doctors.find(item => item.id === doctorId);
        if (!doctor) return;
        openModal("Change doctor password", `
            <p class="account-form-intro">Reset the password for this doctor only. Doctor services, appointments and schedules will stay unchanged.</p>
            <form class="form-grid" id="doctorLoginEditor" autocomplete="off">
                <label class="full"><span>Doctor</span><input value="${escapeHtml(doctor.name)}" readonly></label>
                <label class="full"><span>Sign-in ID</span><input value="${escapeHtml(doctor.staffId)}" readonly></label>
                <label class="full"><span>New doctor password</span><input id="editDoctorPassword" type="password" minlength="8" maxlength="1024" required autocomplete="new-password" placeholder="Enter a new password"></label>
                <label class="full"><span>Confirm new password</span><input id="editDoctorConfirm" type="password" minlength="8" maxlength="1024" required autocomplete="new-password" placeholder="Enter the password again"></label>
                <label class="full"><span>Your staff password (verification)</span><input id="editDoctorStaffPassword" type="password" maxlength="1024" required autocomplete="current-password" placeholder="Enter your own login password"></label>
                <p class="full account-storage-note">Only this doctor's password will change. The doctor will need to sign in again with the new password.</p>
            </form>
        `, `<button class="primary-btn" id="saveDoctorLogin" type="button">Save Password</button>`, { closeOnBackdrop: false });

        byId("saveDoctorLogin").addEventListener("click", async () => {
            const form = byId("doctorLoginEditor");
            if (!form.reportValidity()) return;
            const password = byId("editDoctorPassword").value;
            const confirm = byId("editDoctorConfirm").value;
            const staffPassword = byId("editDoctorStaffPassword").value;
            if (password !== confirm) {
                showToast("The two passwords do not match.");
                return;
            }
            if (password.length < 8) {
                showToast("Doctor password must contain at least 8 characters.");
                return;
            }
            const button = byId("saveDoctorLogin");
            button.disabled = true;
            try {
                const response = await fetch(`/api/admin/accounts/${encodeURIComponent(doctorId)}/credentials`, {
                    method: "PUT",
                    credentials: "same-origin",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        email: doctor.email,
                        new_password: password,
                        operator_password: staffPassword
                    })
                });
                const result = await response.json().catch(() => ({}));
                if (!response.ok) throw new Error(result.detail || "Unable to change doctor password.");
                closeModal();
                showToast("Doctor password changed. The doctor must sign in again.");
            } catch (error) {
                showToast(error.message || "Unable to change doctor password.");
                button.disabled = false;
            }
        });
    }

    async function loadDoctorServiceOptions() {
        const response = await fetch("/api/admin/doctor-directory/services", {
            credentials: "same-origin", cache: "no-store"
        });
        let result = {};
        try { result = await response.json(); } catch {}
        if (!response.ok || !Array.isArray(result.services)) {
            throw new Error(result.detail || "Unable to load doctor services from SQL Server.");
        }
        return result.services;
    }

    function doctorServiceCheckboxes(services, selected = []) {
        const names = new Set(selected.map(x => String(x).toLowerCase()));
        return `<div class="doctor-service-options">${services.map(service => `
            <label class="doctor-service-option"><input type="checkbox" name="doctorService" value="${escapeHtml(service.serviceName)}" ${names.has(service.serviceName.toLowerCase()) ? "checked" : ""}><span>${escapeHtml(service.serviceName)}</span></label>
        `).join("")}</div>`;
    }

    async function openDoctorServiceEditor(doctorId) {
        const state = data();
        const doctor = state.doctors.find(item => item.id === doctorId);
        if (!doctor) return;
        try {
            const services = await loadDoctorServiceOptions();
            openModal("Edit doctor services", `
                <form class="form-grid" id="doctorProfileForm">
                    <label class="full"><span>Doctor</span><input value="${escapeHtml(doctor.name)}" readonly></label>
                    <label class="full"><span>Specialization</span><input name="specialization" maxlength="150" value="${escapeHtml(doctor.specialization || "")}" placeholder="e.g. Acupuncture &amp; Consultation"></label>
                    <div class="full"><strong>Services this doctor provides</strong>${doctorServiceCheckboxes(services, doctor.services || [])}</div>
                </form>
            `, `<button class="primary-btn" id="saveDoctorProfile" type="button">Save doctor services</button>`);
            byId("saveDoctorProfile").addEventListener("click", async () => {
                const form = byId("doctorProfileForm");
                if (!form.reportValidity()) return;
                const selected = [...form.querySelectorAll('input[name="doctorService"]:checked')].map(input => input.value);
                if (!selected.length) { showToast("Select at least one service for the doctor."); return; }
                const previous = structuredClone(state);
                doctor.specialization = form.querySelector('[name="specialization"]').value.trim();
                doctor.services = selected;
                try {
                    if (!await save(state)) {
                        window.TcmAdminData.restore(previous);
                        showToast("Doctor services were not saved.");
                        return;
                    }
                    closeModal();
                    renderAccounts();
                    showToast("Doctor services saved to SQL Server.");
                } catch (error) {
                    window.TcmAdminData.restore(previous);
                    showToast(error.message || "Unable to save doctor services.");
                }
            });
        } catch (error) {
            showToast(error.message || "Unable to open doctor services.");
        }
    }

    function secureRandomBelow(limit) {
        if (!window.crypto?.getRandomValues) {
            throw new Error("Secure password generation is unavailable in this browser.");
        }
        const range = 0x100000000;
        const ceiling = range - range % limit;
        const value = new Uint32Array(1);
        do {
            window.crypto.getRandomValues(value);
        } while (value[0] >= ceiling);
        return value[0] % limit;
    }

    function temporaryPassword() {
        const lower = "abcdefghijkmnopqrstuvwxyz";
        const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
        const digits = "23456789";
        const symbols = "!@#$%*-_";
        const all = lower + upper + digits + symbols;
        const characters = [
            lower[secureRandomBelow(lower.length)],
            upper[secureRandomBelow(upper.length)],
            digits[secureRandomBelow(digits.length)],
            symbols[secureRandomBelow(symbols.length)]
        ];
        while (characters.length < 16) characters.push(all[secureRandomBelow(all.length)]);
        for (let index = characters.length - 1; index > 0; index -= 1) {
            const swapIndex = secureRandomBelow(index + 1);
            [characters[index], characters[swapIndex]] = [characters[swapIndex], characters[index]];
        }
        return characters.join("");
    }

    function uniqueAccountIdentifiers(role, state) {
        const users = accountDirectory(state);
        // Keep retired/deleted sign-in IDs reserved, so the next new account never
        // reuses an old doctor/staff ID with historical data attached.
        const reservedSignins = Array.isArray(state.retiredAccountIds) ? state.retiredAccountIds : [];
        const prefix = role === "doctor" ? "doctor" : "staff";
        const idPrefix = role === "doctor" ? "dr" : "staff";
        // Ignore legacy six-digit random IDs (e.g. doctor706631).
        // Existing demo accounts use doctor001 / staff001 style IDs.
        const sequence = new RegExp(`^${prefix}(\\d{3,5})$`, "i");
        const numbers = [...users.map(user => user.staffId), ...reservedSignins].map(signin => {
            const match = String(signin || "").match(sequence);
            return match ? Number(match[1]) : 0;
        });
        let next = Math.max(0, ...numbers) + 1;
        for (let attempt = 0; attempt < 10000; attempt += 1, next += 1) {
            const suffix = String(next).padStart(3, "0");
            const staffId = `${prefix}${suffix}`;
            const id = `${idPrefix}-${suffix}`;
            if (users.some(user => String(user.staffId).toLowerCase() === staffId.toLowerCase() || String(user.id) === id)) continue;
            return { id, staffId };
        }
        throw new Error("Could not allocate a unique sequential sign-in ID.");
    }

    async function openAccountForm() {
        let doctorServices;
        try {
            doctorServices = await loadDoctorServiceOptions();
        } catch (error) {
            showToast(error.message || "Unable to load doctor services.");
            return;
        }
        openModal("Generate clinic account", `
            <p class="account-form-intro">Local testing: the new account uses the shared password for its role. Use unique passwords before deployment.</p>
            <form class="form-grid" id="accountForm" autocomplete="off">
                <label class="full"><span>Full name</span><input name="name" maxlength="100" required autocomplete="name" placeholder="e.g. Dr. Alex Tan"></label>
                <label class="full"><span>Email address</span><input name="email" type="email" maxlength="254" required autocomplete="email" placeholder="name@example.com"></label>
                <label class="full"><span>Account type</span><select name="role" required><option value="staff">Clinic staff</option><option value="doctor">Doctor</option></select></label>
                <div class="full" id="newDoctorServiceFields" hidden>
                    <label class="full"><span>Specialization</span><input name="specialization" maxlength="150" placeholder="e.g. Acupuncture &amp; Consultation"></label>
                    <strong>Services this doctor provides</strong>
                    ${doctorServiceCheckboxes(doctorServices)}
                </div>
            </form>
        `, `<button class="primary-btn" id="saveGeneratedAccount" type="button">Generate account</button>`, { closeOnBackdrop: false });
        const roleSelect = byId("accountForm").querySelector('[name="role"]');
        const doctorFields = byId("newDoctorServiceFields");
        const toggleDoctorFields = () => { doctorFields.hidden = roleSelect.value !== "doctor"; };
        roleSelect.addEventListener("change", toggleDoctorFields);
        toggleDoctorFields();

        byId("saveGeneratedAccount").addEventListener("click", async () => {
            const form = byId("accountForm");
            if (!form.reportValidity()) return;
            const formData = new FormData(form);
            const name = String(formData.get("name") || "").trim();
            const email = String(formData.get("email") || "").trim().toLowerCase();
            const role = String(formData.get("role"));
            const chosenServices = [...form.querySelectorAll('input[name="doctorService"]:checked')].map(input => input.value);
            const specialization = String(formData.get("specialization") || "").trim();
            const state = data();
            const previousState = structuredClone(state);
            if (!name || !email || !["staff", "doctor"].includes(role)) return;
            if (role === "doctor" && !chosenServices.length) {
                showToast("Choose at least one treatment service for the doctor.");
                return;
            }
            if (accountDirectory(state).some(account => account.email.trim().toLowerCase() === email)) {
                showToast("An account already uses this email address.");
                return;
            }
            try {
                const identifiers = uniqueAccountIdentifiers(role, state);
                const password = role === "doctor" ? "Doctor123！" : "Staff123!";
                const account = { ...identifiers, name, email, password, role, avatar: initials(name) };
                if (role === "doctor") {
                    account.services = chosenServices;
                    account.specialization = specialization || "TCM Practitioner";
                    state.doctors.push(account);
                } else {
                    state.staff.push(account);
                }
                if (!await save(state)) {
                    window.TcmAdminData.restore(previousState);
                    showToast("Account was not saved to SQL Server.");
                    return;
                }
                closeModal();
                renderAccounts();
                openGeneratedAccount(account);
            } catch (error) {
                window.TcmAdminData.restore(previousState);
                showToast(error.message || "Could not generate the account. Please try again.");
            }
        });
    }

    function openGeneratedAccount(account) {
        openModal("Account generated", `
            <div class="account-created-notice">Local test credentials. This role password is shared across accounts; change to unique passwords before deploying.</div>
            <div class="account-credentials">
                <label><span>Account type</span><input value="${account.role === "doctor" ? "Doctor" : "Clinic staff"}" readonly></label>
                <label><span>Sign-in ID</span><input id="generatedAccountId" value="${escapeHtml(account.staffId)}" readonly></label>
                <label><span>Email</span><input id="generatedAccountEmail" value="${escapeHtml(account.email)}" readonly></label>
                <label><span>Test password</span><input id="generatedAccountPassword" value="${escapeHtml(account.password)}" readonly></label>
            </div>
        `, `<button class="secondary-btn" id="copyAccountCredentials" type="button">Copy sign-in details</button><button class="primary-btn" id="closeAccountCredentials" type="button">Done</button>`, { closeOnBackdrop: false });
        byId("copyAccountCredentials").addEventListener("click", async () => {
            const details = `Sign-in ID: ${account.staffId}\nEmail: ${account.email}\nTest password: ${account.password}`;
            try {
                await navigator.clipboard.writeText(details);
                showToast("Sign-in details copied.");
            } catch {
                showToast("Copy is unavailable here. Select and copy the sign-in details.");
            }
        });
        byId("closeAccountCredentials").addEventListener("click", closeModal);
    }

    function drawProducts() {
        const state = data();
        const query = byId("productSearch").value.trim().toLowerCase();
        const categorySelect = byId("productCategory");
        const selectedCategory = categorySelect.value;
        categorySelect.innerHTML = `<option value="">All</option>${productCategories(state.products).map(item => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}`;
        categorySelect.value = selectedCategory;
        const category = categorySelect.value;
        const status = byId("productStatus").value;
        const rows = state.products.filter(item => {
            const actualStatus = item.stock <= 0 ? "Out of Stock" : item.stock <= item.lowStockThreshold ? "Low Stock" : item.status;
            return (!query || item.name.toLowerCase().includes(query)) &&
                (!category || item.category === category) &&
                (!status || actualStatus === status || item.status === status);
        }).map(item => {
            const actualStatus = item.stock <= 0 ? "Out of Stock" : item.stock <= item.lowStockThreshold ? "Low Stock" : item.status;
            return `<tr>
                <td><div class="avatar">${escapeHtml(item.name.slice(0,2).toUpperCase())}</div></td>
                <td>${escapeHtml(item.name)}</td>
                <td>${escapeHtml(item.category)}</td>
                <td>${money(item.price)}</td>
                <td>${Number(item.stock)}</td>
                <td>${badge(actualStatus)}</td>
                <td>${shortDate(item.updatedAt)}</td>
                <td class="row-actions">
                    <button class="mini-btn" data-edit-product="${escapeHtml(item.id)}">Edit</button>
                    <button class="mini-btn" data-stock-product="${escapeHtml(item.id)}">Stock</button>
                    <button class="mini-btn" data-toggle-product="${escapeHtml(item.id)}">${item.status === "Active" ? "Deactivate" : "Activate"}</button>
                    <button class="mini-btn" data-delete-product="${escapeHtml(item.id)}">Delete</button>
                </td>
            </tr>`;
        });
        byId("productTable").innerHTML = table(["Image", "Product Name", "Category", "Price", "Stock", "Status", "Last Updated", "Actions"], rows);
        bindProductButtons();
    }

    function bindProductButtons() {
        document.querySelectorAll("[data-edit-product]").forEach(button => {
            button.addEventListener("click", () => openProductForm(button.dataset.editProduct));
        });
        document.querySelectorAll("[data-stock-product]").forEach(button => {
            button.addEventListener("click", () => openStockAdjust(button.dataset.stockProduct));
        });
        document.querySelectorAll("[data-toggle-product]").forEach(button => {
            button.addEventListener("click", async () => {
                const item = data().products.find(p => p.id === button.dataset.toggleProduct);
                if (!item) return;
                button.disabled = true;
                try {
                    await inventoryRequest(`/${encodeURIComponent(item.id)}/status`, {
                        method: "POST",
                        body: JSON.stringify({status: item.status === "Active" ? "Inactive" : "Active"})
                    });
                    await refreshInventory();
                    showToast("Product status updated.");
                } catch (error) {
                    button.disabled = false;
                    showToast(error.message);
                }
            });
        });
        document.querySelectorAll("[data-delete-product]").forEach(button => {
            button.addEventListener("click", async () => {
                if (!confirm("Delete this product from SQL Server?")) return;
                button.disabled = true;
                try {
                    await inventoryRequest(`/${encodeURIComponent(button.dataset.deleteProduct)}`, {method: "DELETE"});
                    await refreshInventory();
                    showToast("Product deleted.");
                } catch (error) {
                    button.disabled = false;
                    showToast(error.message);
                }
            });
        });
    }

    function openProductForm(id) {
        const state = data();
        const item = state.products.find((product) => product.id === id) || { id: "", name: "", category: "Bird's Nest", description: "", ingredients: "", instructions: "", precautions: "", price: "", stock: "", lowStockThreshold: 5, image: "", status: "Active" };
        const categorySuggestions = productCategories(state.products)
            .map((category) => `<option value="${escapeHtml(category)}"></option>`)
            .join("");
        const imagePreview = item.image
            ? `<img class="product-photo-preview" id="productPhotoPreview" src="${escapeHtml(item.image)}" alt="Current product photo">`
            : `<p class="product-photo-empty" id="productPhotoEmpty">No photo selected.</p>`;
        openModal(id ? "Edit Product" : "Add Product", `
            <form class="form-grid" id="productForm">
                <label><span>Product Name</span><input name="name" value="${escapeHtml(item.name)}" required></label>
                <label><span>Category</span><input name="category" value="${escapeHtml(item.category)}" list="productCategorySuggestions" required><datalist id="productCategorySuggestions">${categorySuggestions}</datalist></label>
                <label class="full"><span>Description</span><textarea name="description" rows="3">${escapeHtml(item.description)}</textarea></label>
                <label class="full"><span>Ingredients (Gram Measurements)</span><textarea name="ingredients" rows="3" placeholder="List each ingredient and its amount in grams">${escapeHtml(item.ingredients)}</textarea></label>
                <label class="full"><span>Instructions</span><textarea name="instructions" rows="3" placeholder="How to prepare or use this product">${escapeHtml(item.instructions)}</textarea></label>
                <label class="full"><span>Precautions</span><textarea name="precautions" rows="3" placeholder="Warnings, allergies, or who should avoid this product">${escapeHtml(item.precautions)}</textarea></label>
                <label><span>Price</span><input type="number" name="price" min="0" step="0.01" value="${item.price}" required></label>
                <label><span>Stock Quantity</span><input type="number" name="stock" min="0" value="${item.stock}" required></label>
                <label><span>Low Stock Threshold</span><input type="number" name="lowStockThreshold" min="0" value="${item.lowStockThreshold}" required></label>
                <label class="full"><span>Product Photo</span><input id="productPhoto" type="file" accept="image/png,image/jpeg,image/webp,image/gif"><small>Choose PNG, JPEG, WebP or GIF, up to 1 MB.</small>${imagePreview}</label>
                ${item.image ? `<label class="full product-photo-remove"><input name="removeImage" type="checkbox"><span>Remove current photo when saving</span></label>` : ""}
                <label><span>Status</span><select name="status"><option>Active</option><option>Inactive</option></select></label>
            </form>
        `, `<button class="primary-btn" id="saveProduct">Save Product</button>`, { closeOnBackdrop: false });
        byId("productForm").status.value = item.status;
        let selectedImage = item.image || "";
        const photoInput = byId("productPhoto");
        const saveButton = byId("saveProduct");

        photoInput.addEventListener("change", () => {
            const file = photoInput.files[0];
            if (!file) return;

            const supportedTypes = ["image/png", "image/jpeg", "image/webp", "image/gif"];
            if (!supportedTypes.includes(file.type)) {
                photoInput.value = "";
                showToast("Choose a PNG, JPEG, WebP or GIF image.");
                return;
            }

            if (file.size > 1024 * 1024) {
                photoInput.value = "";
                showToast("Choose an image smaller than 1 MB.");
                return;
            }

            saveButton.disabled = true;
            const reader = new FileReader();
            reader.addEventListener("load", () => {
                if (typeof reader.result !== "string") {
                    showToast("Could not read this image. Please choose another file.");
                    saveButton.disabled = false;
                    return;
                }

                selectedImage = reader.result;
                let preview = byId("productPhotoPreview");
                if (!preview) {
                    preview = document.createElement("img");
                    preview.className = "product-photo-preview";
                    preview.id = "productPhotoPreview";
                    preview.alt = "Selected product photo";
                    byId("productPhotoEmpty")?.replaceWith(preview);
                }
                preview.src = selectedImage;
                byId("productForm").elements.removeImage && (byId("productForm").elements.removeImage.checked = false);
                saveButton.disabled = false;
            });
            reader.addEventListener("error", () => {
                console.error("Could not read selected product photo.", reader.error);
                photoInput.value = "";
                saveButton.disabled = false;
                showToast("Could not read this image. Please choose another file.");
            });
            reader.readAsDataURL(file);
        });

        saveButton.addEventListener("click", async () => {
            const form = byId("productForm");
            if (!form.reportValidity()) return;
            const formData = Object.fromEntries(new FormData(form).entries());
            const payload = {
                name: String(formData.name).trim(),
                category: String(formData.category).trim(),
                description: String(formData.description || ""),
                ingredients: String(formData.ingredients || ""),
                instructions: String(formData.instructions || ""),
                precautions: String(formData.precautions || ""),
                price: Number(formData.price),
                stock: Number(formData.stock),
                lowStockThreshold: Number(formData.lowStockThreshold),
                image: form.elements.removeImage?.checked ? "" : selectedImage,
                status: String(formData.status),
                expectedStock: id ? Number(item.stock) : null
            };
            saveButton.disabled = true;
            try {
                await inventoryRequest(id ? `/${encodeURIComponent(id)}` : "", {
                    method: id ? "PUT" : "POST",
                    body: JSON.stringify(payload)
                });
                closeModal();
                await refreshInventory();
                showToast("Product saved to SQL Server.");
            } catch (error) {
                saveButton.disabled = false;
                showToast(error.message);
            }
        });
    }

    function openStockAdjust(id) {
        const item = data().products.find(product => product.id === id);
        if (!item) return;
        openModal("Stock Adjustment", `
            <form class="form-grid" id="stockForm">
                <label><span>Current Stock</span><input value="${Number(item.stock)}" disabled></label>
                <label><span>Adjustment</span><select name="direction"><option value="+">+</option><option value="-">-</option></select></label>
                <label><span>Quantity</span><input type="number" name="quantity" min="1" step="1" required value="1"></label>
                <label><span>Reason</span><input name="reason" value="Stock received"></label>
            </form>
        `, `<button class="primary-btn" id="saveStock">Save Adjustment</button>`);
        byId("saveStock").addEventListener("click", async () => {
            if (!byId("stockForm").reportValidity()) return;
            const formData = new FormData(byId("stockForm"));
            const amount = Number(formData.get("quantity"));
            if (!Number.isSafeInteger(amount) || amount < 1) return;
            const change = formData.get("direction") === "+" ? amount : -amount;
            const button = byId("saveStock");
            button.disabled = true;
            try {
                await inventoryRequest(`/${encodeURIComponent(id)}/stock`, {
                    method: "POST",
                    body: JSON.stringify({change})
                });
                closeModal();
                await refreshInventory();
                showToast("Stock updated in SQL Server.");
            } catch (error) {
                button.disabled = false;
                showToast(error.message);
            }
        });
    }

    setInterval(() => {
        if (byId("productTable") && !document.hidden) {
            refreshInventory().catch(error => console.error(error));
        }
    }, 12000);

    let serverOrders = [];

    async function fetchServerOrders() {
        const result = await fetch("/api/admin/orders", {credentials: "same-origin", cache: "no-store"});
        const payload = await result.json();
        if (!result.ok) throw new Error(typeof payload.detail === "string" ? payload.detail : "Cannot load orders.");
        serverOrders = payload.orders || [];
    }

    async function renderOrders() {
        mountView("admin-order-view");
        byId("orderStatus").value = new URLSearchParams(location.search).get("status") || "";
        for (const id of ["orderIdSearch", "orderDateFilter", "orderStatus", "orderPayment"]) {
            byId(id).addEventListener(id === "orderIdSearch" ? "input" : "change", drawOrders);
        }
        byId("orderTable").textContent = "Loading orders from SQL Server...";
        try {
            await fetchServerOrders();
            drawOrders();
        } catch (error) {
            byId("orderTable").textContent = error.message;
        }
    }

    function drawOrders() {
        const idQuery = byId("orderIdSearch").value.trim().toLowerCase();
        const dateQuery = byId("orderDateFilter").value;
        const statusQuery = byId("orderStatus").value;
        const paymentQuery = byId("orderPayment").value;
        const rows = serverOrders.filter(order =>
            (!idQuery || [order.orderNumber, order.trackingId].some(value => String(value || "").toLowerCase().includes(idQuery))) &&
            (!dateQuery || String(order.purchasedAt).slice(0, 10) === dateQuery) &&
            (!statusQuery || order.status === statusQuery) &&
            (!paymentQuery || order.paymentMethod === paymentQuery)
        ).map(order => `<tr>
            <td>${escapeHtml(order.trackingId)}</td>
            <td>${escapeHtml(order.buyer?.name || "Patient")}</td>
            <td>${escapeHtml(String(order.purchasedAt).slice(0, 10))}</td>
            <td>${escapeHtml(order.fulfillmentMethod === "pickup" ? "Pickup" : "Delivery")}</td>
            <td>${money(order.total)}</td>
            <td>${escapeHtml(order.paymentMethod || "")}</td>
            <td>${badge(order.status)}</td>
            <td><button class="mini-btn" data-order-id="${order.orderId}">Manage</button></td>
        </tr>`);
        byId("orderTable").innerHTML = table(["Tracking ID", "Customer", "Date", "Collection", "Total", "Payment", "Status", "Action"], rows);
        byId("orderTable").querySelectorAll("[data-order-id]").forEach(button => {
            button.addEventListener("click", () => openOrder(Number(button.dataset.orderId)));
        });
    }

    function openOrder(id) {
        const order = serverOrders.find(item => item.orderId === id);
        if (!order) return;
        const pickup = order.fulfillmentMethod === "pickup";
        const fulfillment = pickup
            ? `Pickup: ${escapeHtml(order.pickupInfo?.date || "-")} at ${escapeHtml(String(order.pickupInfo?.time || "").slice(0, 5))}`
            : `Recipient: ${escapeHtml(order.deliveryInfo?.recipientName || "-")}<br>Phone: ${escapeHtml(order.deliveryInfo?.phoneNumber || "-")}<br>Address: ${escapeHtml([order.deliveryInfo?.address, order.deliveryInfo?.city, order.deliveryInfo?.state, order.deliveryInfo?.postcode].filter(Boolean).join(", "))}`;
        const detail = `<dl>
            <dt>Tracking ID</dt><dd>${escapeHtml(order.trackingId)}</dd>
            <dt>Customer</dt><dd>${escapeHtml(order.buyer?.name || "")}</dd>
            <dt>Email</dt><dd>${escapeHtml(order.buyer?.email || "")}</dd>
            <dt>Collection</dt><dd>${fulfillment}</dd>
            <dt>Payment</dt><dd>${escapeHtml(order.paymentMethod || "")} (${escapeHtml(order.paymentStatus || "Demo")})</dd>
            <dt>Products</dt><dd>${order.items.map(item => `${escapeHtml(item.name)} × ${Number(item.quantity)} — ${money(Number(item.quantity) * Number(item.price))}`).join("<br>")}</dd>
            <dt>Subtotal</dt><dd>${money(order.subtotal)}</dd>
            <dt>Delivery Fee</dt><dd>${money(order.deliveryFee)}</dd>
            <dt>Total</dt><dd><strong>${money(order.total)}</strong></dd>
            <dt>Status</dt><dd>${escapeHtml(order.status)}</dd>
        </dl>
        <form id="manageOrderForm" class="form-grid">
            <label><span>Courier (optional)</span><input name="courier" maxlength="100" value="${escapeHtml(order.courier || "")}" ${pickup ? "disabled" : ""}></label>
        </form>`;
        const buttons = order.status === "Completed" || order.status === "Cancelled" ? "" : `
            <button class="secondary-btn" data-sql-order-status="Packed">Mark Packed</button>
            ${pickup ? "" : '<button class="secondary-btn" data-sql-order-status="Shipped">Mark Shipped</button>'}
            <button class="primary-btn" data-sql-order-status="Completed">Complete Order</button>
            ${["Pending Packing", "Packed"].includes(order.status) ? '<button class="secondary-btn" data-sql-order-status="Cancelled" style="border-color:#c35d51;color:#9f3632">Cancel Order</button>' : ""}`;
        openModal("Manage Order", detail, buttons);
        document.querySelectorAll("[data-sql-order-status]").forEach(button => button.addEventListener("click", async () => {
            const nextStatus = button.dataset.sqlOrderStatus;
            if (nextStatus === "Cancelled" && !window.confirm("Cancel this order? Reserved stock will be restored and the customer will no longer be able to download its receipt.")) return;
            button.disabled = true;
            try {
                const courier = document.querySelector("#manageOrderForm [name=courier]")?.value || "";
                const response = await fetch(`/api/admin/orders/${id}/status`, {
                    method: "PUT",
                    credentials: "same-origin",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({status: nextStatus, courier})
                });
                const payload = await response.json();
                if (!response.ok) throw new Error(typeof payload.detail === "string" ? payload.detail : "Could not update order.");
                await fetchServerOrders();
                closeModal();
                drawOrders();
                showToast(nextStatus === "Cancelled" ? "Order cancelled. Stock restored and customer notified." : nextStatus === "Completed" ? "Order completed. Customer notified." : "Order updated. Customer status refreshed.");
            } catch (error) {
                showToast(error.message);
                button.disabled = false;
            }
        }));
    }


    let shopReviewRecords = [];

    async function fetchShopReviews() {
        const response = await fetch("/api/admin/shop-reviews", {
            credentials: "same-origin",
            cache: "no-store"
        });
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(typeof payload.detail === "string" ? payload.detail : "Unable to load shop reviews.");
        }
        shopReviewRecords = payload.reviews || [];
        const productFilter = byId("shopReviewProduct");
        if (productFilter) {
            const previous = productFilter.value;
            const products = [...new Set(shopReviewRecords.map(r => String(r.productName || "").trim()).filter(Boolean))]
                .sort((a,b) => a.localeCompare(b));
            productFilter.replaceChildren(new Option("All products", ""));
            products.forEach(name => productFilter.add(new Option(name, name)));
            if (products.includes(previous)) productFilter.value = previous;
        }
    }

    async function reloadShopReviews() {
        const target = byId("shopReviewTable");
        if (target) target.textContent = "Loading reviews from SQL Server...";
        try {
            await fetchShopReviews();
            drawShopReviews();
        } catch (error) {
            if (target) target.textContent = error.message;
            showToast(error.message);
        }
    }

    function renderShopReviews() {
        mountView("admin-shop-review-view");
        for (const id of ["shopReviewSearch", "shopReviewRating", "shopReviewVisibility", "shopReviewProduct"]) {
            byId(id).addEventListener(id === "shopReviewSearch" ? "input" : "change", drawShopReviews);
        }
        byId("refreshShopReviews").addEventListener("click", reloadShopReviews);
        byId("shopReviewTable").addEventListener("click", async event => {
            const edit = event.target.closest("[data-review-edit]");
            const hide = event.target.closest("[data-review-hide]");
            const restore = event.target.closest("[data-review-restore]");
            const reply = event.target.closest("[data-shop-review-reply]");
            const feature = event.target.closest("[data-shop-review-feature]");
            if (reply) {
                openShopReviewReply(Number(reply.dataset.shopReviewReply));
            } else if (feature) {
                await changeShopReviewFeatured(Number(feature.dataset.shopReviewFeature));
            } else if (edit) {
                openShopReviewEditor(Number(edit.dataset.reviewEdit));
            } else if (hide) {
                await changeShopReviewVisibility(Number(hide.dataset.reviewHide), false);
            } else if (restore) {
                await changeShopReviewVisibility(Number(restore.dataset.reviewRestore), true);
            }
        });
        reloadShopReviews();
    }

    function drawShopReviews() {
        const query = String(byId("shopReviewSearch")?.value || "").trim().toLowerCase();
        const rating = Number(byId("shopReviewRating")?.value || 0);
        const visibility = byId("shopReviewVisibility")?.value || "";
        const product = byId("shopReviewProduct")?.value || "";
        const visible = shopReviewRecords.filter(review => !review.hidden);
        const count = byId("shopReviewStats");
        if (count) {
            count.textContent = `${shopReviewRecords.length} total · ${visible.length} visible · ${shopReviewRecords.length - visible.length} hidden`;
        }
        const matching = shopReviewRecords.filter(review => {
            const text = [review.productName, review.customerName, review.customerEmail, review.comment, review.orderId].join(" ").toLowerCase();
            return (!query || text.includes(query)) &&
                (!rating || Number(review.rating) === rating) &&
                (!product || review.productName === product) &&
                (!visibility || (visibility === "hidden") === Boolean(review.hidden));
        }).sort((a, b) => {
            const featuredA = !a.hidden && a.featured ? 1 : 0;
            const featuredB = !b.hidden && b.featured ? 1 : 0;
            return featuredB - featuredA || String(b.createdAt || "").localeCompare(String(a.createdAt || "")) || Number(b.reviewId) - Number(a.reviewId);
        });
        const rows = matching.map(review => {
            const action = review.hidden
                ? `<button type="button" class="mini-btn" data-review-restore="${review.reviewId}">Restore</button>`
                : `<button type="button" class="mini-btn" data-review-edit="${review.reviewId}">Edit</button>
                   <button type="button" class="mini-btn" data-shop-review-reply="${review.reviewId}">${review.staffReply ? "Edit reply" : "Reply"}</button>
                   <button type="button" class="mini-btn" data-shop-review-feature="${review.reviewId}">${review.featured ? "Unfeature" : "Mark as Featured"}</button>
                   <button type="button" class="mini-btn admin-review-delete" data-review-hide="${review.reviewId}">Delete</button>`;
            return `<tr>
                <td><strong>${escapeHtml(review.productName)}</strong><small class="admin-review-secondary">Order #${Number(review.orderId)}</small>${review.featured && !review.hidden ? '<span class="shop-feature-flag">★ Featured</span>' : ''}</td>
                <td>${escapeHtml(review.customerName)}<small class="admin-review-secondary">${escapeHtml(review.customerEmail)}</small></td>
                <td><span class="admin-review-stars">${"★".repeat(Math.max(0, Math.min(5, Number(review.rating))))}${"☆".repeat(5 - Math.max(0, Math.min(5, Number(review.rating))))}</span><small class="admin-review-secondary">${Number(review.rating)} / 5</small></td>
                <td><div class="admin-review-comment">${escapeHtml(review.comment)}</div>${review.editedByStaff ? '<small class="admin-review-secondary">Edited by staff</small>' : ""}${review.staffReply ? `<div class="shop-reply-preview"><strong>Clinic reply:</strong> ${escapeHtml(review.staffReply)}</div>` : ""}</td>
                <td>${escapeHtml(String(review.createdAt || "").slice(0, 10))}</td>
                <td><span class="badge ${review.hidden ? "cancelled" : "active"}">${review.hidden ? "Hidden" : "Visible"}</span></td>
                <td><div class="admin-review-actions">${action}</div></td>
            </tr>`;
        });
        byId("shopReviewTable").innerHTML = table(["Product", "Customer", "Rating", "Review", "Date", "Visibility", "Actions"], rows);
    }

    function openShopReviewReply(id) {
        const review = shopReviewRecords.find(item => item.reviewId === id);
        if (!review || review.hidden) return;
        openModal("Reply to Product Review", `
            <form id="shopReviewReplyForm" class="admin-review-editor">
                <p><strong>${escapeHtml(review.productName)}</strong> · ${escapeHtml(review.customerName)}</p>
                <p class="admin-review-secondary">Customer review: ${escapeHtml(review.comment)}</p>
                <label><span>Clinic reply</span><textarea name="reply" rows="5" maxlength="2000" required placeholder="Write a helpful reply to the customer..."></textarea></label>
                <p class="admin-review-secondary">This reply will appear publicly under the product review.</p>
                <div class="admin-review-editor-buttons">
                    <button type="submit" class="primary-btn">Save Reply</button>
                    <button type="button" class="secondary-btn" id="cancelShopReviewReply">Cancel</button>
                </div>
            </form>`);
        const form = byId("shopReviewReplyForm");
        form.elements.reply.value = review.staffReply || "";
        byId("cancelShopReviewReply").addEventListener("click", closeModal);
        form.addEventListener("submit", async event => {
            event.preventDefault();
            const button = form.querySelector('[type="submit"]');
            const reply = form.elements.reply.value.trim();
            if (!reply) return;
            button.disabled = true;
            try {
                const result = await sendShopReviewRequest(`/api/admin/shop-reviews/${id}/reply`, {
                    method: "PUT", headers: {"Content-Type": "application/json"}, body: JSON.stringify({reply})
                });
                closeModal();
                await fetchShopReviews();
                drawShopReviews();
                showToast(result.message);
            } catch(error) { showToast(error.message); button.disabled = false; }
        });
    }

    async function changeShopReviewFeatured(id) {
        const review = shopReviewRecords.find(item => item.reviewId === id);
        if (!review || review.hidden) return;
        try {
            const result = await sendShopReviewRequest(`/api/admin/shop-reviews/${id}/featured`, {
                method: "PUT", headers: {"Content-Type": "application/json"},
                body: JSON.stringify({featured: !review.featured})
            });
            await fetchShopReviews();
            drawShopReviews();
            showToast(result.message);
        } catch(error) { showToast(error.message); }
    }

    async function sendShopReviewRequest(url, options) {
        const response = await fetch(url, {
            credentials: "same-origin",
            ...options
        });
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(typeof payload.detail === "string" ? payload.detail : "Unable to update shop review.");
        }
        return payload;
    }

    function openShopReviewEditor(id) {
        const review = shopReviewRecords.find(item => item.reviewId === id);
        if (!review || review.hidden) return;
        openModal("Edit Shop Review", `
            <form id="shopReviewEditForm" class="admin-review-editor">
                <p><strong>${escapeHtml(review.productName)}</strong></p>
                <p class="admin-review-secondary">From ${escapeHtml(review.customerName)} · Order #${Number(review.orderId)}</p>
                <label><span>Rating</span>
                    <select name="rating" required>
                        ${[1, 2, 3, 4, 5].map(number => `<option value="${number}" ${number === review.rating ? "selected" : ""}>${"★".repeat(number)} (${number}/5)</option>`).join("")}
                    </select>
                </label>
                <label><span>Review</span><textarea name="comment" rows="6" required></textarea></label>
                <p class="admin-review-secondary">Changes are recorded in SQL Server and marked as edited by staff on the customer page.</p>
                <div class="admin-review-editor-buttons">
                    <button type="submit" class="primary-btn">Save Changes</button>
                    <button type="button" id="shopReviewEditCancel" class="secondary-btn">Cancel</button>
                </div>
            </form>
        `);
        const form = byId("shopReviewEditForm");
        form.elements.comment.value = review.comment;
        byId("shopReviewEditCancel").addEventListener("click", closeModal);
        form.addEventListener("submit", async event => {
            event.preventDefault();
            const button = form.querySelector('[type="submit"]');
            const comment = String(form.elements.comment.value || "").trim();
            if (!comment) return;
            button.disabled = true;
            try {
                const result = await sendShopReviewRequest(`/api/admin/shop-reviews/${id}`, {
                    method: "PUT",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({rating: Number(form.elements.rating.value), comment})
                });
                closeModal();
                await fetchShopReviews();
                drawShopReviews();
                showToast(result.message);
            } catch (error) {
                showToast(error.message);
                button.disabled = false;
            }
        });
    }

    async function changeShopReviewVisibility(id, restore) {
        const review = shopReviewRecords.find(item => item.reviewId === id);
        if (!review) return;
        if (!restore && !window.confirm(`Hide the review for ${review.productName}? It will no longer appear in the shop or average rating.`)) return;
        try {
            const result = await sendShopReviewRequest(
                `/api/admin/shop-reviews/${id}${restore ? "/restore" : ""}`,
                {method: restore ? "POST" : "DELETE"}
            );
            await fetchShopReviews();
            drawShopReviews();
            showToast(result.message);
        } catch (error) {
            showToast(error.message);
        }
    }

    function renderMessages() {
        const state = data();
        const user = current();
        const messages = state.messages.filter((item) => user.role === "staff" || item.doctorId === user.id);
        if (!messages.some((item) => item.id === activeMessageId)) {
            activeMessageId = messages[0]?.id || "";
        }

        mountView("admin-message-view");

        byId("messageSearch").addEventListener("input", drawMessageList);
        drawMessageList();
        if (activeMessageId) openMessage(activeMessageId);
        else renderEmptyMessage();
    }

    function drawMessageList() {
        const state = data();
        const user = current();
        const query = byId("messageSearch").value.trim().toLowerCase();
        const messages = state.messages
            .filter((item) => user.role === "staff" || item.doctorId === user.id)
            .filter((item) =>
                `${item.patient} ${item.patientEmail || ""} ${item.messages.at(-1)?.text || ""}`
                    .toLowerCase()
                    .includes(query)
            );
        const list = byId("messageConversationList");

        if (messages.length === 0) {
            list.innerHTML = `<p class="admin-message-empty-list">${query ? "No conversations found." : "No conversations yet."}</p>`;
            return;
        }

        list.innerHTML = messages.map((thread) => {
            const initials = String(thread.patient || "P")
                .split(/\s+/)
                .filter(Boolean)
                .slice(0, 2)
                .map((part) => part[0])
                .join("")
                .toUpperCase();
            const preview = thread.messages.at(-1)?.text || "No messages yet";

            return `
                <button type="button" class="admin-conversation-item${thread.id === activeMessageId ? " active" : ""}" data-message="${escapeHtml(thread.id)}">
                    <span class="admin-conversation-avatar">${escapeHtml(initials)}</span>
                    <span class="admin-conversation-summary">
                        <strong>${escapeHtml(thread.patient)}</strong>
                        <span>${escapeHtml(preview)}</span>
                    </span>
                    <span class="admin-conversation-meta">
                        <span>${escapeHtml(thread.lastTime || "")}</span>
                        ${thread.unread ? `<span class="admin-unread-count">${thread.unread}</span>` : ""}
                    </span>
                </button>`;
        }).join("");

        list.querySelectorAll("[data-message]").forEach((button) => {
            button.addEventListener("click", () => openMessage(button.dataset.message));
        });
    }

    function renderEmptyMessage() {
        byId("chatWindow").innerHTML = `
            <div class="admin-chat-empty">
                <span class="admin-chat-empty-icon">✉</span>
                <h3>Select a conversation</h3>
                <p>Patient messages will appear here.</p>
            </div>`;
    }

    function openMessage(id) {
        const state = data();
        const thread = state.messages.find((item) => item.id === id);
        if (!thread) return;
        activeMessageId = id;
        const replies = current().role === "staff"
            ? ["Your appointment has been confirmed.", "Please arrive 10 minutes early.", "Your appointment has been rescheduled.", "Your order has been shipped."]
            : ["Thank you for your message.", "Please follow the care instructions provided.", "We recommend discussing this during your next consultation."];
        thread.unread = 0;
        save(state);
        drawMessageList();
        const initials = String(thread.patient || "P")
            .split(/\s+/)
            .filter(Boolean)
            .slice(0, 2)
            .map((part) => part[0])
            .join("")
            .toUpperCase();
        byId("chatWindow").innerHTML = `
            <header class="admin-chat-heading">
                <span class="admin-conversation-avatar">${escapeHtml(initials)}</span>
                <div>
                    <h3>${escapeHtml(thread.patient)}</h3>
                    <p>${escapeHtml(thread.patientEmail || "Patient conversation")}</p>
                </div>
            </header>
            <div class="admin-chat-messages" id="adminChatMessages" aria-live="polite">
                <div class="admin-message-date">Recent messages</div>
                ${thread.messages.map((message) => `
                    <article class="admin-chat-bubble ${message.from === "patient" ? "incoming" : "outgoing"}">
                        <div>${escapeHtml(message.text)}</div>
                        <time>${escapeHtml(message.time)}</time>
                    </article>`).join("")}
            </div>
            <form class="admin-message-form" id="messageReply">
                <div class="admin-message-composer">
                    <textarea name="text" rows="1" maxlength="1000" placeholder="Write a message..." aria-label="Write a message"></textarea>
                    <button class="primary-btn" type="submit">Send</button>
                </div>
                <label class="admin-quick-reply"><span>Quick reply</span><select id="quickReply"><option value="">Choose a reply (optional)</option>${replies.map((reply) => `<option>${escapeHtml(reply)}</option>`).join("")}</select></label>
            </form>`;
        const chatMessages = byId("adminChatMessages");
        chatMessages.scrollTop = chatMessages.scrollHeight;
        byId("quickReply").addEventListener("change", (event) => {
            byId("messageReply").elements.text.value = event.target.value;
        });
        byId("messageReply").addEventListener("submit", (event) => {
            event.preventDefault();
            const text = event.target.elements.text.value.trim();
            if (!text) return;
            thread.messages.push({ from: current().role, text, time: new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) });
            thread.lastTime = thread.messages.at(-1).time;
            save(state);
            openMessage(id);
        });
    }

    function renderFeedback() { renderAppointmentFeedback(false); }
    function renderDoctorReviews() { renderAppointmentFeedback(true); }

    async function renderAppointmentFeedback(doctorOnly) {
        const view = doctorOnly ? 'admin-doctor-reviews-view' : 'admin-feedback-view';
        mountView(view);
        const root = doctorOnly ? byId('doctorReviewsTable') : byId('feedbackTable');
        root.textContent = 'Loading appointment reviews from SQL Server...';
        try {
            const response = await fetch('/api/admin/appointment-reviews', {credentials:'same-origin', cache:'no-store'});
            const payload = await response.json().catch(()=>({}));
            if (!response.ok) throw new Error(payload.detail || `Could not load reviews (${response.status}).`);
            const reviews = payload.reviews || [];
            const featuredEnabled = Boolean(payload.featuredEnabled);
            const rows = reviews.map(review => {
                const actions = doctorOnly ? '<span class="feedback-muted">Read only</span>' : `
                    <button class="mini-btn" data-review-action="view" data-review-id="${review.reviewId}">View</button>
                    <button class="mini-btn" data-review-action="reply" data-review-id="${review.reviewId}">Reply</button>
                    <button class="mini-btn" data-review-action="feature" data-review-id="${review.reviewId}" ${featuredEnabled ? '' : 'disabled title="Run optional SQL migration to enable featured reviews"'}>${review.featured ? 'Unfeature' : 'Mark as Featured'}</button>
                    <button class="mini-btn" data-review-action="visibility" data-review-id="${review.reviewId}">${review.status === 'Hidden' ? 'Show' : 'Hide'}</button>`;
                return `<tr>
                    <td><strong class="review-stars">${'★'.repeat(Math.min(5,Math.max(0,Number(review.rating))))}</strong><br><small>${review.rating}/5</small></td>
                    <td>${escapeHtml(review.patient)}<br><small>${escapeHtml(review.appointmentId)}</small></td>
                    <td>${escapeHtml(review.service)}</td><td>${escapeHtml(review.doctor)}</td>
                    <td class="review-text-cell">${escapeHtml(review.comment)}</td>
                    <td>${escapeHtml(String(review.createdAt).slice(0,10))}</td>
                    <td>${escapeHtml(review.status)}${review.featured ? ' ★ Featured' : ''}${review.adminReply ? '<br><small>Replied</small>' : ''}</td>
                    <td class="row-actions review-actions">${actions}</td>
                </tr>`;
            });
            root.innerHTML = `<p class="feedback-muted">${reviews.length} reviews from SQL Server · ${doctorOnly ? 'Only reviews about your consultations' : 'View, reply or moderate patient reviews'}</p>`+
                table(['Rating','Patient / Booking','Service','Doctor','Comment','Date','Status','Actions'],rows);
            root.querySelectorAll('[data-review-action]').forEach(button => button.addEventListener('click',async () => {
                const review = reviews.find(r=>String(r.reviewId)===button.dataset.reviewId);
                if (!review) return;
                const action = button.dataset.reviewAction;
                if (action === 'view') { window.alert(`${review.patient} · ${review.appointmentId}\n${review.rating}/5 stars\n${review.comment}\n\nClinic reply: ${review.adminReply || '(none)'}`); return; }
                let next = {status:review.status,adminReply:review.adminReply || '',featured:Boolean(review.featured)};
                if (action === 'reply') {
                    const typed = window.prompt('Reply to this patient review (up to 2000 characters):',next.adminReply);
                    if (typed===null) return;
                    next.adminReply=typed.trim().slice(0,2000);
                } else if(action === 'visibility') {
                    next.status = review.status==='Hidden' ? 'Published' : 'Hidden';
                    if (next.status === 'Hidden') next.featured = false;
                } else if(action==='feature') {
                    next.featured = !next.featured;
                    if (next.featured) next.status='Published';
                }
                button.disabled = true;
                try {
                    const response = await fetch(`/api/admin/appointment-reviews/${review.reviewId}`, {method:'PATCH',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(next)});
                    const result = await response.json().catch(()=>({}));
                    if (!response.ok) throw Error(result.detail || 'Could not save review change.');
                    await renderAppointmentFeedback(false);
                } catch (e) { window.alert(e.message);button.disabled=false; }
            }));
        } catch (error) { root.textContent = error.message || 'Unable to load appointment reviews.'; }
    }

    function renderAnnouncements() {
        const state = data();
        mountView("admin-announcement-view");
        byId("newAnnouncement").addEventListener("click", () => openAnnouncementForm());
        drawAnnouncements();
    }

    function drawAnnouncements() {
        const state = data();
        const rows = state.announcements.map((item) => `<tr><td>${item.title}</td><td>${item.type}</td><td>${shortDate(item.publishDate)}</td><td>${badge(item.status)}</td><td class="row-actions"><button class="mini-btn" data-announcement="${item.id}">Edit</button><button class="mini-btn" data-publish="${item.id}">${item.status === "Published" ? "Unpublish" : "Publish"}</button><button class="mini-btn" data-delete-ann="${item.id}">Delete</button></td></tr>`);
        byId("announcementTable").innerHTML = table(["Title", "Type", "Published Date", "Status", "Actions"], rows);
        document.querySelectorAll("[data-announcement]").forEach((button) => button.addEventListener("click", () => openAnnouncementForm(button.dataset.announcement)));
        document.querySelectorAll("[data-publish]").forEach((button) => button.addEventListener("click", () => {
            const state = data();
            const item = state.announcements.find((ann) => ann.id === button.dataset.publish);
            item.status = item.status === "Published" ? "Draft" : "Published";
            save(state);
            drawAnnouncements();
        }));
        document.querySelectorAll("[data-delete-ann]").forEach((button) => button.addEventListener("click", () => {
            const state = data();
            state.announcements = state.announcements.filter((ann) => ann.id !== button.dataset.deleteAnn);
            save(state);
            drawAnnouncements();
        }));
    }

    function openAnnouncementForm(id) {
        const state = data();
        const item = state.announcements.find((ann) => ann.id === id) || { title: "", type: "Clinic Notice", content: "", publishDate: "2026-10-06", status: "Draft" };
        openModal(id ? "Edit Announcement" : "Create Announcement", `<form class="form-grid" id="announcementForm"><label><span>Title</span><input name="title" value="${item.title}" required></label><label><span>Type</span><select name="type"><option>Clinic Notice</option><option>Health Education</option><option>New Product</option><option>Promotion</option></select></label><label class="full"><span>Content</span><textarea name="content" rows="4">${item.content}</textarea></label><label><span>Publish Date</span><input type="date" name="publishDate" value="${item.publishDate}"></label><label><span>Status</span><select name="status"><option>Draft</option><option>Published</option></select></label></form>`, `<button class="primary-btn" id="saveAnnouncement">Save</button>`);
        byId("announcementForm").type.value = item.type;
        byId("announcementForm").status.value = item.status;
        byId("saveAnnouncement").addEventListener("click", () => {
            const form = byId("announcementForm");
            if (!form.reportValidity()) return;
            const payload = Object.fromEntries(new FormData(form).entries());
            if (id) Object.assign(state.announcements.find((ann) => ann.id === id), payload);
            else state.announcements.push({ id: generateID("ANN"), ...payload });
            save(state);
            closeModal();
            drawAnnouncements();
        });
    }

    function analyticsDateMatches(value, dateRange) {
        if (dateRange.period === "all") return true;
        const dateText = String(value || "").slice(0, 10);
        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateText);
        if (!match) return false;
        return (!dateRange.start || dateText >= dateRange.start) &&
            (!dateRange.end || dateText <= dateRange.end);
    }

    function analyticsDateRange(period, selectedMonth, selectedYear, startDate, endDate) {
        const today = new Date();
        const todayText = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
        if (period === "all") return { period, label: "All records" };
        if (period === "month") {
            const [year, month] = selectedMonth.split("-").map(Number);
            if (!year || !month) return { period, label: "Choose a month", invalid: true };
            const date = new Date(year, month - 1, 1);
            return {
                period,
                start: `${selectedMonth}-01`,
                end: `${selectedMonth}-${String(new Date(year, month, 0).getDate()).padStart(2, "0")}`,
                label: date.toLocaleDateString("en-MY", { month: "long", year: "numeric" })
            };
        }
        if (period === "6months") {
            const firstMonth = new Date(today.getFullYear(), today.getMonth() - 5, 1);
            return {
                period,
                start: `${firstMonth.getFullYear()}-${String(firstMonth.getMonth() + 1).padStart(2, "0")}-01`,
                end: todayText,
                label: `Last 6 months (to ${today.toLocaleDateString("en-MY", { day: "numeric", month: "short", year: "numeric" })})`
            };
        }
        if (period === "year") {
            const year = Number(selectedYear);
            if (!year) return { period, label: "Choose a year", invalid: true };
            return { period, start: `${year}-01-01`, end: `${year}-12-31`, label: `Year ${year}` };
        }
        if (period === "custom") {
            if (!startDate || !endDate || startDate > endDate) {
                return { period, start: startDate, end: endDate, label: "Choose a valid date range", invalid: true };
            }
            return { period, start: startDate, end: endDate, label: `${startDate} to ${endDate}` };
        }
        return { period: "all", label: "All records" };
    }

    function analyticsSummary(state, dateRange, doctorId) {
        if (dateRange.invalid) {
            return {
                appointments: [],
                completed: 0,
                cancelled: 0,
                scheduled: 0,
                orders: [],
                salesOrders: [],
                sales: 0,
                units: 0,
                productRows: [],
                doctorRows: state.doctors.map((doctor) => ({
                    name: doctor.name,
                    appointments: 0,
                    completed: 0,
                    cancelled: 0
                }))
            };
        }
        const appointments = state.appointments.filter((item) =>
            analyticsDateMatches(item.date, dateRange) && (!doctorId || item.doctorId === doctorId)
        );
        const orders = state.orders.filter((order) => analyticsDateMatches(order.date, dateRange));
        const salesOrders = orders.filter((order) => {
            const status = String(order.status || "").trim().toLowerCase();
            const paymentStatus = String(order.paymentStatus || "").trim().toLowerCase();
            return !["cancelled", "pending payment", "failed"].includes(status) &&
                !["voided", "failed", "pending", "unpaid"].includes(paymentStatus);
        });
        const products = new Map();
        salesOrders.forEach((order) => {
            (Array.isArray(order.items) ? order.items : []).forEach((item) => {
                const quantity = Number(item.quantity);
                const price = Number(item.price);
                const name = String(item.name || "Product");
                if (!Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(price) || price < 0) return;
                const product = products.get(name) || { name, units: 0, sales: 0 };
                product.units += quantity;
                product.sales += quantity * price;
                products.set(name, product);
            });
        });
        const productRows = [...products.values()].sort((a, b) => b.sales - a.sales || a.name.localeCompare(b.name));
        const doctorRows = state.doctors.map((doctor) => {
            const doctorAppointments = appointments.filter((item) => item.doctorId === doctor.id);
            return {
                name: doctor.name,
                appointments: doctorAppointments.length,
                completed: doctorAppointments.filter((item) => item.status === "Completed").length,
                cancelled: doctorAppointments.filter((item) => item.status === "Cancelled").length
            };
        });
        return {
            appointments,
            completed: appointments.filter((item) => item.status === "Completed").length,
            cancelled: appointments.filter((item) => item.status === "Cancelled").length,
            scheduled: appointments.filter((item) => ["Scheduled", "Rescheduled"].includes(item.status)).length,
            orders,
            salesOrders,
            sales: productRows.reduce((sum, product) => sum + product.sales, 0),
            units: productRows.reduce((sum, product) => sum + product.units, 0),
            productRows,
            doctorRows
        };
    }

    function analyticsXml(value) {
        return String(value ?? "").replace(/[<>&'"]/g, (character) => ({
            "<": "&lt;",
            ">": "&gt;",
            "&": "&amp;",
            "'": "&apos;",
            "\"": "&quot;"
        })[character]);
    }

    function analyticsCell(value, style = "Text", type = "String", mergeAcross = 0) {
        return { value, style, type, mergeAcross };
    }

    function analyticsRow(cells, height = 22) {
        return { cells, height };
    }

    function analyticsSectionRow(title, columns = 2) {
        return analyticsRow([analyticsCell(title, "Section", "String", columns - 1)], 25);
    }

    function analyticsColumnName(number) {
        let name = "";
        while (number > 0) {
            const remainder = (number - 1) % 26;
            name = String.fromCharCode(65 + remainder) + name;
            number = Math.floor((number - 1) / 26);
        }
        return name;
    }

    function analyticsWorksheet(columns, rows, frozenRows) {
        const mergeRanges = [];
        const worksheetRows = rows.map((row, rowIndex) => {
            const cells = row.cells.map((cell, columnIndex) => {
                const reference = `${analyticsColumnName(columnIndex + 1)}${rowIndex + 1}`;
                const styleId = analyticsStyleIds[cell.style] ?? 6;
                const contents = cell.type === "Number"
                    ? `<v>${Number.isFinite(Number(cell.value)) ? Number(cell.value) : 0}</v>`
                    : `<is><t xml:space="preserve">${analyticsXml(cell.value)}</t></is>`;
                const cellType = cell.type === "Number" ? "" : ` t="inlineStr"`;
                if (cell.mergeAcross) {
                    mergeRanges.push(`${reference}:${analyticsColumnName(columnIndex + 1 + cell.mergeAcross)}${rowIndex + 1}`);
                }
                return `<c r="${reference}" s="${styleId}"${cellType}>${contents}</c>`;
            }).join("");
            return `<row r="${rowIndex + 1}" ht="${row.height}" customHeight="1">${cells}</row>`;
        }).join("");
        const pane = frozenRows
            ? `<sheetViews><sheetView workbookViewId="0"><pane ySplit="${frozenRows}" topLeftCell="A${frozenRows + 1}" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>`
            : `<sheetViews><sheetView workbookViewId="0"/></sheetViews>`;
        const merges = mergeRanges.length
            ? `<mergeCells count="${mergeRanges.length}">${mergeRanges.map((range) => `<mergeCell ref="${range}"/>`).join("")}</mergeCells>`
            : "";
        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>${pane}<sheetFormatPr defaultRowHeight="18"/><cols>${columns.map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`).join("")}</cols><sheetData>${worksheetRows}</sheetData>${merges}<pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/><pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>`;
    }

    const analyticsStyleIds = {
        Title: 1,
        Subtitle: 2,
        Meta: 3,
        Section: 4,
        TableHeader: 5,
        Text: 6,
        Label: 7,
        Number: 8,
        Currency: 9,
        Percent: 10,
        Total: 11,
        TotalNumber: 12,
        TotalCurrency: 13,
        TotalPercent: 14,
        Empty: 15,
        Average: 16
    };

    function analyticsStyles() {
        const fonts = [
            '<font><sz val="10"/><name val="Aptos"/><color rgb="FF18392E"/></font>',
            '<font><b/><sz val="18"/><name val="Aptos Display"/><color rgb="FFFFFFFF"/></font>',
            '<font><b/><sz val="12"/><name val="Aptos"/><color rgb="FF184936"/></font>',
            '<font><sz val="10"/><name val="Aptos"/><color rgb="FF526A5D"/></font>',
            '<font><b/><sz val="11"/><name val="Aptos"/><color rgb="FFFFFFFF"/></font>',
            '<font><b/><sz val="10"/><name val="Aptos"/><color rgb="FFFFFFFF"/></font>',
            '<font><sz val="10"/><name val="Aptos"/><color rgb="FF18392E"/></font>',
            '<font><b/><sz val="10"/><name val="Aptos"/><color rgb="FF526A5D"/></font>',
            '<font><b/><sz val="10"/><name val="Aptos"/><color rgb="FF184936"/></font>',
            '<font><i/><sz val="10"/><name val="Aptos"/><color rgb="FF75857B"/></font>'
        ];
        const fills = [
            '<fill><patternFill patternType="none"/></fill>',
            '<fill><patternFill patternType="gray125"/></fill>',
            '<fill><patternFill patternType="solid"><fgColor rgb="FF184936"/></patternFill></fill>',
            '<fill><patternFill patternType="solid"><fgColor rgb="FFE8F3E9"/></patternFill></fill>',
            '<fill><patternFill patternType="solid"><fgColor rgb="FFF2F6F0"/></patternFill></fill>',
            '<fill><patternFill patternType="solid"><fgColor rgb="FF2F7859"/></patternFill></fill>',
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFFFFF"/></patternFill></fill>'
        ];
        const borders = [
            '<border><left/><right/><top/><bottom/><diagonal/></border>',
            '<border><left/><right/><top/><bottom style="thin"><color rgb="FFE4EBE3"/></bottom><diagonal/></border>',
            '<border><left/><right/><top style="thin"><color rgb="FF2F7859"/></top><bottom/><diagonal/></border>'
        ];
        const alignments = {
            center: '<alignment vertical="center"/>',
            wrap: '<alignment vertical="center" wrapText="1"/>',
            right: '<alignment horizontal="right" vertical="center"/>'
        };
        const style = (font, fill, border = 1, alignment = "center", numFmt = "") =>
            `<xf numFmtId="${numFmt || 0}" fontId="${font}" fillId="${fill}" borderId="${border}" xfId="0" applyAlignment="1"${numFmt ? ' applyNumberFormat="1"' : ""}>${alignments[alignment]}</xf>`;
        const cellFormats = [
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
            style(1, 2, 0, "center"),
            style(2, 3, 0, "center"),
            style(3, 4, 0, "center"),
            style(4, 5, 0, "center"),
            style(5, 5, 0, "wrap"),
            style(6, 6, 1, "wrap"),
            style(7, 4, 1, "wrap"),
            style(6, 6, 1, "right", 3),
            style(8, 6, 1, "right", 164),
            style(6, 6, 1, "right", 165),
            style(8, 3, 2, "wrap"),
            style(8, 3, 2, "right", 3),
            style(8, 3, 2, "right", 164),
            style(8, 3, 2, "right", 165),
            style(9, 6, 0, "wrap"),
            style(8, 6, 1, "right", 166)
        ];
        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="3"><numFmt numFmtId="164" formatCode="&quot;RM&quot; #,##0.00"/><numFmt numFmtId="165" formatCode="0.0%"/><numFmt numFmtId="166" formatCode="0.00"/></numFmts><fonts count="${fonts.length}">${fonts.join("")}</fonts><fills count="${fills.length}">${fills.join("")}</fills><borders count="${borders.length}">${borders.join("")}</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${cellFormats.length}">${cellFormats.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    }

    function analyticsZip(files) {
        const encoder = new TextEncoder();
        const crcTable = new Uint32Array(256);
        for (let index = 0; index < 256; index += 1) {
            let value = index;
            for (let bit = 0; bit < 8; bit += 1) {
                value = value & 1 ? 0xEDB88320 ^ (value >>> 1) : value >>> 1;
            }
            crcTable[index] = value >>> 0;
        }
        const crc32 = (bytes) => {
            let crc = 0xFFFFFFFF;
            bytes.forEach((byte) => { crc = crcTable[(crc ^ byte) & 0xFF] ^ (crc >>> 8); });
            return (crc ^ 0xFFFFFFFF) >>> 0;
        };
        const write16 = (view, offset, value) => view.setUint16(offset, value, true);
        const write32 = (view, offset, value) => view.setUint32(offset, value >>> 0, true);
        const now = new Date();
        const dosTime = (now.getHours() << 11) | (now.getMinutes() << 5) | Math.floor(now.getSeconds() / 2);
        const dosDate = ((Math.max(1980, now.getFullYear()) - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
        const localParts = [];
        const directoryParts = [];
        let offset = 0;
        files.forEach(([name, contents]) => {
            const filename = encoder.encode(name);
            const bytes = encoder.encode(contents);
            const checksum = crc32(bytes);
            const localHeader = new Uint8Array(30 + filename.length);
            const localView = new DataView(localHeader.buffer);
            write32(localView, 0, 0x04034B50);
            write16(localView, 4, 20);
            write16(localView, 6, 0x0800);
            write16(localView, 8, 0);
            write16(localView, 10, dosTime);
            write16(localView, 12, dosDate);
            write32(localView, 14, checksum);
            write32(localView, 18, bytes.length);
            write32(localView, 22, bytes.length);
            write16(localView, 26, filename.length);
            write16(localView, 28, 0);
            localHeader.set(filename, 30);
            localParts.push(localHeader, bytes);

            const centralHeader = new Uint8Array(46 + filename.length);
            const centralView = new DataView(centralHeader.buffer);
            write32(centralView, 0, 0x02014B50);
            write16(centralView, 4, 20);
            write16(centralView, 6, 20);
            write16(centralView, 8, 0x0800);
            write16(centralView, 10, 0);
            write16(centralView, 12, dosTime);
            write16(centralView, 14, dosDate);
            write32(centralView, 16, checksum);
            write32(centralView, 20, bytes.length);
            write32(centralView, 24, bytes.length);
            write16(centralView, 28, filename.length);
            write16(centralView, 30, 0);
            write16(centralView, 32, 0);
            write16(centralView, 34, 0);
            write16(centralView, 36, 0);
            write32(centralView, 38, 0);
            write32(centralView, 42, offset);
            centralHeader.set(filename, 46);
            directoryParts.push(centralHeader);
            offset += localHeader.length + bytes.length;
        });

        const directorySize = directoryParts.reduce((sum, part) => sum + part.length, 0);
        const endRecord = new Uint8Array(22);
        const endView = new DataView(endRecord.buffer);
        write32(endView, 0, 0x06054B50);
        write16(endView, 4, 0);
        write16(endView, 6, 0);
        write16(endView, 8, files.length);
        write16(endView, 10, files.length);
        write32(endView, 12, directorySize);
        write32(endView, 16, offset);
        write16(endView, 20, 0);
        return new Blob([...localParts, ...directoryParts, endRecord], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        });
    }

    // Match the UI's "Average appointments by doctor" Bar Chart exactly:
    // count non-cancelled bookings and divide by distinct days with bookings.
    function analyticsDoctorAverages(appointments, doctors, selectedDoctorId = "") {
        const selectedDoctors = doctors.filter(doctor => !selectedDoctorId || String(doctor.id) === String(selectedDoctorId));
        const totals = new Map(selectedDoctors.map(doctor => [String(doctor.id), {
            name: String(doctor.name || "Doctor"), count: 0, days: new Set()
        }]));
        for (const appointment of appointments) {
            const doctor = totals.get(String(appointment.doctorId));
            const day = String(appointment.date || "").slice(0, 10);
            if (!doctor || !/^\d{4}-\d{2}-\d{2}$/.test(day)) continue;
            if (["cancelled", "canceled"].includes(String(appointment.status || "").trim().toLowerCase())) continue;
            doctor.count += 1;
            doctor.days.add(day);
        }
        return [...totals.values()].map(doctor => ({
            name: doctor.name, appointments: doctor.count, days: doctor.days.size,
            average: doctor.days.size ? doctor.count / doctor.days.size : 0
        })).sort((a,b) => b.average - a.average || a.name.localeCompare(b.name));
    }

    // Native Office Open XML horizontal bar chart attached to the doctor averages worksheet.
    function analyticsAverageChartXml(doctorAverages) {
        const last = doctorAverages.length + 3;
        const chartRef = `&apos;Doctor Averages&apos;!$D$4:$D$${last}`;
        const categoryRef = `&apos;Doctor Averages&apos;!$A$4:$A$${last}`;
        const categories = doctorAverages.map((d,i) => `<c:pt idx="${i}"><c:v>${analyticsXml(d.name)}</c:v></c:pt>`).join("");
        const values = doctorAverages.map((d,i) => `<c:pt idx="${i}"><c:v>${d.average}</c:v></c:pt>`).join("");
        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
            `<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">` +
            `<c:chart><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr/></a:pPr><a:r><a:rPr lang="en-MY"/><a:t>Average daily appointments by doctor</a:t></a:r><a:endParaRPr lang="en-MY"/></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>` +
            `<c:autoTitleDeleted val="0"/><c:plotArea><c:layout/>` +
            `<c:barChart><c:barDir val="bar"/><c:grouping val="clustered"/><c:varyColors val="0"/>` +
            `<c:ser><c:idx val="0"/><c:order val="0"/><c:tx><c:v>Appointments per active booking day</c:v></c:tx>` +
            `<c:spPr><a:solidFill><a:srgbClr val="2F7859"/></a:solidFill></c:spPr>` +
            `<c:cat><c:strRef><c:f>${categoryRef}</c:f><c:strCache><c:ptCount val="${doctorAverages.length}"/>${categories}</c:strCache></c:strRef></c:cat>` +
            `<c:val><c:numRef><c:f>${chartRef}</c:f><c:numCache><c:formatCode>0.00</c:formatCode><c:ptCount val="${doctorAverages.length}"/>${values}</c:numCache></c:numRef></c:val></c:ser>` +
            `<c:dLbls><c:showVal val="1"/><c:showLegendKey val="0"/><c:showCatName val="0"/><c:showSerName val="0"/></c:dLbls>` +
            `<c:gapWidth val="65"/><c:axId val="486501"/><c:axId val="486727"/></c:barChart>` +
            `<c:catAx><c:axId val="486501"/><c:scaling><c:orientation val="maxMin"/></c:scaling><c:axPos val="l"/><c:tickLblPos val="nextTo"/><c:crossAx val="486727"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblOffset val="100"/></c:catAx>` +
            `<c:valAx><c:axId val="486727"/><c:scaling><c:orientation val="minMax"/><c:min val="0"/></c:scaling><c:axPos val="b"/><c:numFmt formatCode="0.0" sourceLinked="0"/><c:majorGridlines/><c:tickLblPos val="nextTo"/><c:crossAx val="486501"/><c:crosses val="autoZero"/></c:valAx>` +
            `</c:plotArea><c:legend><c:legendPos val="b"/><c:overlay val="0"/></c:legend><c:plotVisOnly val="1"/></c:chart></c:chartSpace>`;
    }

    function analyticsAverageDrawingXml(doctorCount) {
        // Place the chart to the right of the data table, not covering any cells.
        const chartEnd = Math.max(18, Math.min(35, doctorCount + 10));
        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
            `<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">` +
            `<xdr:twoCellAnchor><xdr:from><xdr:col>5</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>3</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>` +
            `<xdr:to><xdr:col>14</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${chartEnd}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>` +
            `<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="2" name="Doctor average bar chart"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr>` +
            `<xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic>` +
            `<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart">` +
            `<c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rId1"/>` +
            `</a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor></xdr:wsDr>`;
    }

    function exportAnalytics(summary, periodLabel, doctorFilter, inventoryProducts = [], allDoctors = [], selectedDoctorId = "") {
        const generatedAt = new Date();
        const dateLabel = generatedAt.toLocaleDateString("en-MY", {
            day: "numeric",
            month: "long",
            year: "numeric"
        });
        const timeLabel = generatedAt.toLocaleTimeString("en-MY", {
            hour: "numeric",
            minute: "2-digit"
        });
        const summaryRows = [
            analyticsRow([analyticsCell("TCM SMARTCARE+  |  CLINIC INSIGHTS", "Title", "String", 1)], 38),
            analyticsRow([analyticsCell("Clinic analytics report", "Subtitle", "String", 1)], 26),
            analyticsRow([analyticsCell(`Reporting period: ${periodLabel}     |     Generated: ${dateLabel} at ${timeLabel}`, "Meta", "String", 1)], 24),
            analyticsRow([analyticsCell("Report details", "Section", "String", 1)], 25),
            analyticsRow([analyticsCell("Appointment filter", "Label"), analyticsCell(doctorFilter || "All doctors", "Text")]),
            analyticsRow([analyticsCell("Product sales", "Label"), analyticsCell("SQL checkout orders; cancelled and voided orders excluded; delivery fees excluded", "Text")]),
            analyticsRow([analyticsCell("Scope", "Label"), analyticsCell("Doctor filter applies to appointments only; product sales use the selected period.", "Text")], 30),
            analyticsRow([]),
            analyticsSectionRow("Performance summary"),
            analyticsRow([analyticsCell("Metric", "TableHeader"), analyticsCell("Value", "TableHeader")], 24),
            analyticsRow([analyticsCell("Total appointments", "Text"), analyticsCell(summary.appointments.length, "Number", "Number")]),
            analyticsRow([analyticsCell("Completed appointments", "Text"), analyticsCell(summary.completed, "Number", "Number")]),
            analyticsRow([analyticsCell("Cancelled appointments", "Text"), analyticsCell(summary.cancelled, "Number", "Number")]),
            analyticsRow([analyticsCell("Scheduled appointments", "Text"), analyticsCell(summary.scheduled, "Number", "Number")]),
            analyticsRow([analyticsCell("Product sales", "Text"), analyticsCell(summary.sales, "Currency", "Number")]),
            analyticsRow([analyticsCell("Included orders", "Text"), analyticsCell(summary.salesOrders.length, "Number", "Number")]),
            analyticsRow([analyticsCell("Units sold", "Text"), analyticsCell(summary.units, "Number", "Number")]),
            analyticsRow([analyticsCell("Products sold", "Text"), analyticsCell(summary.productRows.length, "Number", "Number")]),
            analyticsRow([analyticsCell("Current products in inventory", "Text"), analyticsCell(inventoryProducts.length, "Number", "Number")]),
            analyticsRow([analyticsCell("Current units in stock", "Text"), analyticsCell(inventoryProducts.reduce((sum, product) => sum + Number(product.stock || 0), 0), "Number", "Number")])
        ];

        const productRows = [
            analyticsRow([analyticsCell("PRODUCT SALES", "Title", "String", 3)], 38),
            analyticsRow([analyticsCell(`Revenue by product  |  ${periodLabel}`, "Subtitle", "String", 3)], 26),
            analyticsRow([analyticsCell("Product", "TableHeader"), analyticsCell("Units sold", "TableHeader"), analyticsCell("Sales revenue", "TableHeader"), analyticsCell("Revenue share", "TableHeader")], 25),
            ...summary.productRows.map((product) => analyticsRow([
                analyticsCell(product.name, "Text"),
                analyticsCell(product.units, "Number", "Number"),
                analyticsCell(product.sales, "Currency", "Number"),
                analyticsCell(summary.sales ? product.sales / summary.sales : 0, "Percent", "Number")
            ])),
            analyticsRow([
                analyticsCell("Total product sales", "Total"),
                analyticsCell(summary.units, "TotalNumber", "Number"),
                analyticsCell(summary.sales, "TotalCurrency", "Number"),
                analyticsCell(summary.sales ? 1 : 0, "TotalPercent", "Number")
            ], 25)
        ];
        if (!summary.productRows.length) {
            productRows.splice(3, 0, analyticsRow([analyticsCell("No product sales for the selected period.", "Empty", "String", 3)], 28));
        }

        const doctorRows = [
            analyticsRow([analyticsCell("DOCTOR PERFORMANCE", "Title", "String", 4)], 38),
            analyticsRow([analyticsCell(`Appointment breakdown  |  ${periodLabel}`, "Subtitle", "String", 4)], 26),
            analyticsRow([analyticsCell("Doctor", "TableHeader"), analyticsCell("Appointments", "TableHeader"), analyticsCell("Completed", "TableHeader"), analyticsCell("Cancelled", "TableHeader"), analyticsCell("Completion rate", "TableHeader")], 25),
            ...summary.doctorRows.map((doctor) => analyticsRow([
                analyticsCell(doctor.name, "Text"),
                analyticsCell(doctor.appointments, "Number", "Number"),
                analyticsCell(doctor.completed, "Number", "Number"),
                analyticsCell(doctor.cancelled, "Number", "Number"),
                analyticsCell(doctor.appointments ? doctor.completed / doctor.appointments : 0, "Percent", "Number")
            ])),
            analyticsRow([
                analyticsCell("All doctors", "Total"),
                analyticsCell(summary.appointments.length, "TotalNumber", "Number"),
                analyticsCell(summary.completed, "TotalNumber", "Number"),
                analyticsCell(summary.cancelled, "TotalNumber", "Number"),
                analyticsCell(summary.appointments.length ? summary.completed / summary.appointments.length : 0, "TotalPercent", "Number")
            ], 25)
        ];

        const doctorAverages = analyticsDoctorAverages(summary.appointments, allDoctors, selectedDoctorId);
        const doctorAverageRows = [
            analyticsRow([analyticsCell("DOCTOR AVERAGE APPOINTMENTS", "Title", "String", 3)], 38),
            analyticsRow([analyticsCell(`Non-cancelled appointments per active booking day  |  ${periodLabel}  |  ${doctorFilter}`, "Subtitle", "String", 3)], 28),
            analyticsRow([
                analyticsCell("Doctor", "TableHeader"),
                analyticsCell("Non-cancelled appointments", "TableHeader"),
                analyticsCell("Active booking days", "TableHeader"),
                analyticsCell("Avg. appointments / active day", "TableHeader")
            ], 31),
            ...doctorAverages.map(doctor => analyticsRow([
                analyticsCell(doctor.name, "Text"),
                analyticsCell(doctor.appointments, "Number", "Number"),
                analyticsCell(doctor.days, "Number", "Number"),
                analyticsCell(doctor.average, "Average", "Number")
            ], 27)),
            analyticsRow([]),
            analyticsRow([analyticsCell("Average = non-cancelled appointments / distinct days with at least one valid booking for the doctor. Days with no appointments are excluded.", "Meta", "String", 3)], 40)
        ];
        if (!doctorAverages.length) doctorAverageRows.splice(3,0,analyticsRow([analyticsCell("No doctors match the current filter.","Empty","String",3)],28));

        const inventoryRows = [
            analyticsRow([analyticsCell("CURRENT INVENTORY", "Title", "String", 5)], 38),
            analyticsRow([analyticsCell("Live SQL stock snapshot - not filtered by reporting period", "Subtitle", "String", 5)], 26),
            analyticsRow([
                analyticsCell("Product", "TableHeader"),
                analyticsCell("Category", "TableHeader"),
                analyticsCell("Price", "TableHeader"),
                analyticsCell("Stock", "TableHeader"),
                analyticsCell("Low Stock Threshold", "TableHeader"),
                analyticsCell("Status", "TableHeader")
            ], 25),
            ...inventoryProducts.map((product) => analyticsRow([
                analyticsCell(product.name, "Text"),
                analyticsCell(product.category || "", "Text"),
                analyticsCell(Number(product.price || 0), "Currency", "Number"),
                analyticsCell(Number(product.stock || 0), "Number", "Number"),
                analyticsCell(Number(product.lowStockThreshold || 0), "Number", "Number"),
                analyticsCell(product.status || "", "Text")
            ]))
        ];
        const workbook = analyticsZip([
            ["[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet5.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/><Override PartName="/xl/charts/chart1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/></Types>`],
            ["_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
            ["xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Product Sales" sheetId="2" r:id="rId2"/><sheet name="Doctor Performance" sheetId="3" r:id="rId4"/><sheet name="Inventory Stock" sheetId="4" r:id="rId5"/><sheet name="Doctor Averages" sheetId="5" r:id="rId6"/></sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`],
            ["xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/><Relationship Id="rId6" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet5.xml"/></Relationships>`],
            ["xl/styles.xml", analyticsStyles()],
            ["xl/worksheets/sheet1.xml", analyticsWorksheet([36, 58], summaryRows, 10)],
            ["xl/worksheets/sheet2.xml", analyticsWorksheet([46, 14, 20, 17], productRows, 3)],
            ["xl/worksheets/sheet3.xml", analyticsWorksheet([30, 16, 14, 14, 19], doctorRows, 3)],
            ["xl/worksheets/sheet4.xml", analyticsWorksheet([46, 28, 19, 16, 22, 18], inventoryRows, 3)],
            ["xl/worksheets/sheet5.xml", analyticsWorksheet([38, 28, 22, 32, 3, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12], doctorAverageRows, 3)
                .replace('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">', '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">')
                .replace('</worksheet>', '<drawing r:id="rId1"/></worksheet>')],
            ["xl/worksheets/_rels/sheet5.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>'],
            ["xl/drawings/drawing1.xml", analyticsAverageDrawingXml(doctorAverages.length)],
            ["xl/drawings/_rels/drawing1.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart1.xml"/></Relationships>'],
            ["xl/charts/chart1.xml", analyticsAverageChartXml(doctorAverages)]
        ]);
        const url = URL.createObjectURL(workbook);
        const link = document.createElement("a");
        link.href = url;
        link.download = `tcm-clinic-analytics-${generatedAt.toISOString().slice(0, 10)}.xlsx`;
        document.body.append(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function renderAnalytics() {
        const haveSqlOrders = Array.isArray(analyticsLive.orders);
        const haveSqlProducts = Array.isArray(analyticsLive.products);
        const state = { ...data(), orders: haveSqlOrders ? analyticsLive.orders : [] };
        const inventoryProducts = haveSqlProducts ? analyticsLive.products : [];
        const previousPeriod = byId("analyticsPeriod")?.value || "all";
        const previousDoctor = byId("analyticsDoctor")?.value || "";
        const today = new Date();
        const currentMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}`;
        const previousMonth = byId("analyticsMonth")?.value || currentMonth;
        const previousYear = byId("analyticsYear")?.value || String(today.getFullYear());
        const previousStartDate = byId("analyticsStartDate")?.value || "";
        const previousEndDate = byId("analyticsEndDate")?.value || "";
        const dateRange = analyticsDateRange(previousPeriod, previousMonth, previousYear, previousStartDate, previousEndDate);
        const summary = analyticsSummary(state, dateRange, previousDoctor);
        const productColors = ["#2f7859", "#8da98d", "#bf9b4b", "#527c9a", "#b57052", "#7e6f98", "#4f9291"];
        const totalProductSales = summary.sales;
        let chartCursor = 0;
        const gradientStops = summary.productRows.map((product, index) => {
            const start = chartCursor;
            chartCursor += totalProductSales ? product.sales / totalProductSales * 100 : 0;
            return `${productColors[index % productColors.length]} ${start}% ${chartCursor}%`;
        }).join(", ");
        const maxUnits = Math.max(1, ...summary.productRows.map((product) => product.units));
        const periodLabel = dateRange.label;
        const years = new Set([today.getFullYear()]);
        [...state.appointments, ...state.orders].forEach((item) => {
            const year = Number(String(item.date || "").slice(0, 4));
            if (Number.isInteger(year) && year >= 1900 && year <= 2100) years.add(year);
        });
        years.add(Number(previousYear));
        const yearOptions = [...years].sort((a, b) => b - a);
        const appointmentRows = summary.doctorRows.map((doctor, index) => `
            <tr>
                <td><span class="analytics-doctor-name"><i style="--doctor-color:${productColors[index % productColors.length]}"></i>${escapeHtml(doctor.name)}</span></td>
                <td>${doctor.appointments}</td><td>${doctor.completed}</td><td>${doctor.cancelled}</td>
            </tr>`);

        mountView("admin-analytics-view");
        byId("analyticsYear").innerHTML = yearOptions.map((year) => `<option value="${year}">${year}</option>`).join("");
        byId("analyticsDoctor").innerHTML = `<option value="">All doctors</option>${state.doctors.map((doctor) => `<option value="${escapeHtml(doctor.id)}">${escapeHtml(doctor.name)}</option>`).join("")}`;
        byId("analyticsPeriod").value = previousPeriod;
        byId("analyticsDoctor").value = previousDoctor;
        byId("analyticsMonth").value = previousMonth;
        byId("analyticsYear").value = previousYear;
        byId("analyticsStartDate").value = previousStartDate;
        byId("analyticsEndDate").value = previousEndDate;
        byId("analyticsMonthFilter").hidden = previousPeriod !== "month";
        byId("analyticsYearFilter").hidden = previousPeriod !== "year";
        byId("analyticsStartFilter").hidden = previousPeriod !== "custom";
        byId("analyticsEndFilter").hidden = previousPeriod !== "custom";
        byId("analyticsFilterHint").hidden = !dateRange.invalid;
        byId("analyticsFilterHint").textContent = previousPeriod === "custom"
            ? "Select a valid start and end date. The start date must be on or before the end date."
            : "Choose a valid reporting period.";
        const statusText = analyticsLive.ordersError || analyticsLive.productsError
            ? `SQL sync warning: ${analyticsLive.ordersError || analyticsLive.productsError}`
            : haveSqlOrders && haveSqlProducts
                ? `Live SQL data · ${analyticsLive.syncedAt?.toLocaleTimeString("en-MY", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) || ""}`
                : "Loading store data from SQL Server...";
        byId("analyticsSyncStatus").textContent = statusText;
        byId("analyticsSyncStatus").classList.toggle("analytics-sync-error", Boolean(analyticsLive.ordersError || analyticsLive.productsError));
        byId("exportAnalytics").disabled = !haveSqlOrders;
        byId("analyticsKpis").innerHTML = `
            <article class="analytics-kpi featured"><span class="analytics-kpi-icon">▦</span><strong>${summary.appointments.length}</strong><b>Total appointments</b><small>${escapeHtml(periodLabel)}${previousDoctor ? ` · ${escapeHtml(doctorName(previousDoctor, state))}` : ""}</small></article>
            <article class="analytics-kpi"><span class="analytics-kpi-icon">✓</span><strong>${summary.completed}</strong><b>Completed appointments</b><small>${summary.appointments.length ? `${(summary.completed / summary.appointments.length * 100).toFixed(1)}% of appointments` : "No appointments in this period"}</small></article>
            <article class="analytics-kpi"><span class="analytics-kpi-icon">▤</span><strong>${haveSqlOrders ? money(summary.sales) : "—"}</strong><b>Product sales</b><small>${haveSqlOrders ? `${summary.salesOrders.length} included orders · ${escapeHtml(periodLabel)}` : "Waiting for SQL orders"}</small></article>
            <article class="analytics-kpi"><span class="analytics-kpi-icon">▱</span><strong>${haveSqlOrders ? summary.orders.length : "—"}</strong><b>Total orders</b><small>${haveSqlOrders ? `${summary.units} units sold across ${summary.productRows.length} products` : "Waiting for SQL orders"}</small></article>`;
        byId("analyticsSalesSubtitle").textContent = `Revenue share · ${periodLabel}`;
        byId("analyticsSalesDonut").innerHTML = summary.sales > 0
            ? `<div class="analytics-donut" role="img" aria-label="Product sales distribution by product" style="--sales-chart:conic-gradient(${gradientStops})"><div><strong>${money(summary.sales)}</strong><span>product sales</span></div></div>`
            : `<div class="analytics-donut analytics-donut-empty"><div><strong>${money(0)}</strong><span>product sales</span></div></div>`;
        byId("analyticsSalesLegend").innerHTML = summary.productRows.length
            ? summary.productRows.map((product, index) => `
                <div class="analytics-legend-row"><i style="--product-color:${productColors[index % productColors.length]}"></i><span><strong>${escapeHtml(product.name)}</strong><small>${product.units} ${product.units === 1 ? "unit" : "units"} sold</small></span><b>${summary.sales ? (product.sales / summary.sales * 100).toFixed(1) : "0.0"}%</b></div>
            `).join("")
            : `<p class="analytics-empty">${haveSqlOrders ? "No product sales in this period." : escapeHtml(analyticsLive.ordersError || "Loading SQL orders...")}</p>`;
        byId("analyticsUnitsSubtitle").textContent = `${summary.units} units sold · ${periodLabel}`;
        byId("analyticsProductRanking").innerHTML = summary.productRows.length
            ? [...summary.productRows].sort((a, b) => b.units - a.units || a.name.localeCompare(b.name)).map((product) => `
                <div class="analytics-product-row"><span>${escapeHtml(product.name)}</span><span class="analytics-unit-track"><i style="width:${product.units / maxUnits * 100}%"></i></span><strong>${product.units}</strong></div>
            `).join("")
            : `<p class="analytics-empty">${haveSqlOrders ? "No product sales in this period." : escapeHtml(analyticsLive.ordersError || "Loading SQL orders...")}</p>`;
        byId("analyticsInventoryCount").textContent = haveSqlProducts
            ? `${inventoryProducts.length} products`
            : "Loading stock";
        const inStock = inventoryProducts.filter((product) => product.status === "Active" && Number(product.stock) > 0);
        const outOfStock = inventoryProducts.filter((product) => product.status === "Active" && Number(product.stock) === 0);
        const lowStock = inventoryProducts.filter((product) =>
            product.status === "Active" && Number(product.stock) > 0 && Number(product.stock) <= Number(product.lowStockThreshold || 0)
        );
        byId("analyticsInventorySummary").innerHTML = haveSqlProducts
            ? `<span><strong>${inventoryProducts.length}</strong> total products</span><span><strong>${inStock.length}</strong> available</span><span><strong>${lowStock.length}</strong> low stock</span><span><strong>${outOfStock.length}</strong> out of stock</span>`
            : `<p class="analytics-empty">${escapeHtml(analyticsLive.productsError || "Loading inventory from SQL Server...")}</p>`;
        byId("analyticsInventoryTable").innerHTML = haveSqlProducts
            ? table(["Product", "Price", "Stock", "Status"], inventoryProducts.map((product) => {
                const stock = Number(product.stock || 0);
                const isLow = product.status === "Active" && stock > 0 && stock <= Number(product.lowStockThreshold || 0);
                const label = product.status !== "Active" ? product.status : stock === 0 ? "Out of stock" : isLow ? "Low stock" : "Active";
                return `<tr><td>${escapeHtml(product.name)}</td><td>${money(product.price)}</td><td>${stock}</td><td>${escapeHtml(label)}</td></tr>`;
            }))
            : "";
        byId("analyticsDoctorSubtitle").textContent = `Appointment counts by doctor · ${periodLabel}`;
        byId("analyticsDoctorCount").textContent = `${summary.doctorRows.length} doctors`;
        byId("analyticsDoctorTable").innerHTML = table(["Doctor", "Total appointments", "Completed", "Cancelled"], appointmentRows);
        byId("analyticsFooterNote").textContent = `${periodLabel} · Product sales and order counts use SQL checkout records. Cancelled and voided orders are excluded from sales. Delivery fees are excluded from product revenue. Inventory shows current stock.`;
        byId("analyticsPeriod").addEventListener("change", renderAnalytics);
        byId("analyticsDoctor").addEventListener("change", renderAnalytics);
        ["analyticsMonth", "analyticsYear", "analyticsStartDate", "analyticsEndDate"].forEach((id) => {
            byId(id).addEventListener("change", renderAnalytics);
        });
        byId("exportAnalytics").addEventListener("click", () => {
            if (!haveSqlOrders) return;
            const selectedDoctor = state.doctors.find((doctor) => doctor.id === previousDoctor);
            exportAnalytics(summary, periodLabel, selectedDoctor ? selectedDoctor.name : "All doctors", inventoryProducts, state.doctors, previousDoctor);
        });
        startAnalyticsPolling();
    }

    function showServerError(error) {
        document.body.replaceChildren();
        const main = document.createElement("main");
        main.className = "access-denied";
        const heading = document.createElement("h1");
        heading.textContent = "Admin server unavailable";
        const message = document.createElement("p");
        message.textContent = error?.message || "Could not connect to the Python admin server.";
        const help = document.createElement("p");
        help.textContent = "Start the backend with the setup instructions in README.md, then reload this page.";
        main.append(heading, message, help);
        document.body.append(main);
    }

    document.addEventListener("DOMContentLoaded", async () => {
        try {
            const page = document.body.dataset.page;
            if (page === "login") {
                initLogin();
                return;
            }
            if (!await window.TcmAdminAuth.initialize()) {
                window.location.href = "admin-login.html";
                return;
            }
            await window.TcmAdminData.initialize();
            if (!protect(page)) return;
            renderShell(page, document.body.dataset.title || "Admin Portal");
            pages[page]?.();
        } catch (error) {
            showServerError(error);
        }
    });

    // Refresh doctor photos after staff changes them in another window/tab.
    // Continue refreshing the original clinic lists, without changing their logic.
    window.addEventListener('focus', async () => {
        const page = document.body.dataset.page;
        const refreshClinicList = ['appointments', 'patients', 'carePlan', 'dashboard'].includes(page);
        const signedIn = current();
        const isDoctor = signedIn?.role === 'doctor';
        if (!refreshClinicList && !isDoctor) return;
        if (document.querySelector('.admin-modal') || document.activeElement?.closest('form')) return;
        try {
            await window.TcmAdminData.initialize();
            if (isDoctor) {
                const doctor = accountDirectory(data()).find((item) => item.id === signedIn.id);
                if (doctor) renderAdminAvatar(profilePictureForViewer(doctor, signedIn), doctor.name);
            }
            if (page === 'appointments') renderAppointments();
            else if (page === 'patients') renderPatients();
            else if (page === 'carePlan') renderCarePlan();
            else if (page === 'dashboard') renderDashboard();
        } catch (error) { console.error('Clinic SQL refresh failed:', error); }
    });

    window.addEventListener("tcm-admin-api-error", (event) => {
        showToast(event.detail || "Could not save admin data to the database.");
    });

    window.addEventListener("storage", (event) => {
        if (event.key === "tcmAdminData" && document.body.dataset.page === "appointments") {
            renderAppointments();
        }

        if (event.key === "tcmPurchaseHistory" && document.body.dataset.page === "orders") {
            renderOrders();
        }

        if (event.key === "tcmMessages" && document.body.dataset.page === "messages") {
            renderMessages();
        }
    });
})();


/* Avatar lightbox: preview only. No changes to any uploaded or saved photos. */
(() => {
    if (window.__tcmAvatarZoomInstalled) return;
    window.__tcmAvatarZoomInstalled = true;
    const isAdminPortal = document.body?.classList.contains("admin-shell") ||
        document.querySelector(".admin-shell") !== null;
    const selector = isAdminPortal
        ? ["#adminAvatar", ".account-person .avatar", ".person-cell .avatar",
           ".patient-profile-head .avatar", ".admin-profile-photo-preview",
           "#doctorPicturePreview", "#scheduleDoctorAvatar", ".admin-conversation-avatar"].join(", ")
        : [".patient-avatar", ".practitioner-photo", ".doctor-modal-avatar",
           "#profilePreview", ".conversation-avatar"].join(", ");
    let overlay = null;
    let previousFocus = null;

    function findName(el) {
        const img = el.matches("img") ? el : el.querySelector("img");
        const card = el.closest(".practitioner-card, .account-person, .person-cell, .patient-profile-head, .chat-heading");
        const nearby = card?.querySelector("h3, h2, strong")?.textContent?.trim();
        if (nearby) return nearby;
        if (el.id === "doctorModalAvatar") return document.getElementById("doctorModalName")?.textContent?.trim() || "Practitioner";
        if (el.id === "adminAvatar") return document.getElementById("adminName")?.textContent?.trim() || "Profile picture";
        if (el.classList.contains("patient-avatar") || el.id === "profilePreview") {
            return document.querySelector(".topbar .profile-top-link strong")?.textContent?.trim() ||
                document.getElementById("fullName")?.value?.trim() || "Profile picture";
        }
        return img?.alt?.trim() || el.getAttribute("aria-label") || "Profile picture";
    }

    function photoSource(el) {
        const image = el.matches("img") ? el : el.querySelector("img");
        if (image?.getAttribute("src") && getComputedStyle(image).visibility !== "hidden") {
            return image.currentSrc || image.src;
        }
        const style = getComputedStyle(el).backgroundImage;
        if (style && style !== "none") {
            const match = /^url\(["']?(.*?)["']?\)$/.exec(style);
            if (match) return match[1];
        }
        return "";
    }

    function dismiss() {
        if (!overlay) return;
        overlay.remove();
        overlay = null;
        previousFocus?.isConnected && previousFocus.focus({preventScroll: true});
        previousFocus = null;
    }

    function show(el) {
        dismiss();
        previousFocus = document.activeElement;
        const name = findName(el);
        const src = photoSource(el);
        overlay = document.createElement("div");
        overlay.id = "tcm-avatar-zoom";
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-modal", "true");
        overlay.setAttribute("aria-label", `${name} enlarged profile picture`);
        const panel = document.createElement("div");
        panel.className = "tcm-avatar-zoom-panel";
        const close = document.createElement("button");
        close.type = "button";
        close.className = "tcm-avatar-zoom-close";
        close.setAttribute("aria-label", "Close enlarged picture");
        close.textContent = "×";
        const circle = document.createElement("div");
        circle.className = "tcm-avatar-zoom-circle";
        if (src) {
            const image = document.createElement("img");
            image.src = src;
            image.alt = `${name} profile picture`;
            image.onerror = () => { circle.replaceChildren(); circle.textContent = el.textContent.trim() || "?"; };
            circle.appendChild(image);
        } else {
            circle.textContent = el.textContent.trim() || "?";
        }
        const caption = document.createElement("p");
        caption.className = "tcm-avatar-zoom-name";
        caption.textContent = name;
        panel.append(close, circle, caption);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);
        close.addEventListener("click", dismiss);
        overlay.addEventListener("click", e => { if (e.target === overlay) dismiss(); });
        close.focus({preventScroll: true});
    }

    const css = document.createElement("style");
    css.id = "tcm-avatar-zoom-style";
    css.textContent = `
        ${selector} { cursor: zoom-in !important; }
        ${selector}:focus-visible { outline: 3px solid #328d83 !important; outline-offset: 3px; }
        #tcm-avatar-zoom { position: fixed; inset: 0; z-index: 2147483000;
            background: rgba(12,38,39,.78); display: flex; align-items: center;
            justify-content: center; padding: 20px; box-sizing: border-box; }
        #tcm-avatar-zoom .tcm-avatar-zoom-panel { box-sizing: border-box;
            position: relative; display: flex; align-items: center; flex-direction: column;
            gap: 16px; width: min(440px, 100%); max-height: 95vh;
            padding: 50px 20px 26px; border-radius: 18px; background: #fff;
            box-shadow: 0 18px 60px rgba(0,0,0,.35); }
        #tcm-avatar-zoom .tcm-avatar-zoom-close { position: absolute; top: 12px; right: 14px;
            border: 0; border-radius: 50%; width: 38px; height: 38px;
            display: grid; place-items: center; background: #edf5f2; color: #184f4b;
            font: normal 28px/1 system-ui,sans-serif; cursor: pointer; }
        #tcm-avatar-zoom .tcm-avatar-zoom-close:hover { background: #d9ebe6; }
        #tcm-avatar-zoom .tcm-avatar-zoom-circle { width: min(320px, 70vw, 52vh);
            height: min(320px, 70vw, 52vh); border-radius: 50%; overflow: hidden;
            display: flex; align-items: center; justify-content: center;
            background: #dcece7; color: #205d5a;
            font: 700 clamp(48px, 12vw, 100px)/1 system-ui,sans-serif; }
        #tcm-avatar-zoom .tcm-avatar-zoom-circle img { width: 100%; height: 100%;
            object-fit: cover; display: block; }
        #tcm-avatar-zoom .tcm-avatar-zoom-name { margin: 0;
            font: 700 17px/1.4 system-ui,sans-serif; text-align: center; color: #153c39; }
    `;
    document.head.appendChild(css);

    // Capture clicks before the photo's enclosing profile or doctor-card handler.
    document.addEventListener("click", event => {
        if (overlay && event.target.closest("#tcm-avatar-zoom")) return;
        const el = event.target instanceof Element ? event.target.closest(selector) : null;
        if (!el) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        show(el);
    }, true);
    document.addEventListener("keydown", event => {
        if (overlay && event.key === "Escape") {
            event.preventDefault(); event.stopImmediatePropagation(); dismiss(); return;
        }
        if (event.key !== "Enter" && event.key !== " ") return;
        const el = document.activeElement;
        if (!(el instanceof Element) || !el.matches(selector)) return;
        event.preventDefault(); event.stopImmediatePropagation(); show(el);
    }, true);

    const enhance = () => document.querySelectorAll(selector).forEach(el => {
        if (el.tabIndex < 0) el.tabIndex = 0;
        if (!el.hasAttribute("role")) el.setAttribute("role", "button");
        if (!el.getAttribute("title")) el.setAttribute("title", "Click to enlarge picture");
    });
    const initialize = () => {
        enhance();
        let scheduled = false;
        const observer = new MutationObserver(() => {
            if (scheduled) return;
            scheduled = true;
            requestAnimationFrame(() => { scheduled = false; enhance(); });
        });
        observer.observe(document.body, {childList: true, subtree: true});
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialize);
    else initialize();
})();
