(() => {
    if (document.body.dataset.page !== 'appointments') return;
    const getToday = () => {
        const date = new Date();
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    };
    const getTime = () => {
        const date = new Date();
        return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    };
    const rules = appointment => {
        if (!appointment) return 'Appointment information is unavailable.';
        if (!['Scheduled', 'Rescheduled'].includes(appointment.status)) return 'This appointment cannot be checked in.';
        if (appointment.date !== getToday()) return 'Check-in is only available on the appointment date.';
        const finish = String(appointment.endTime || '').slice(0, 5);
        if (finish && finish <= getTime()) return 'The appointment time has passed.';
        return '';
    };
    const update = () => {
        const appointments = window.TcmAdminData?.load()?.appointments || [];
        for (const button of document.querySelectorAll('[data-check-in]')) {
            const appointment = appointments.find(row => row.id === button.dataset.checkIn);
            const message = rules(appointment);
            button.disabled = Boolean(message);
            button.title = message;
            button.setAttribute('aria-label', message || 'Check in the patient');
            if (message) button.style.opacity = '0.48';
            else button.style.removeProperty('opacity');
        }
    };
    document.addEventListener('click', event => {
        const button = event.target.closest?.('[data-check-in]');
        if (!button) return;
        const appointment = (window.TcmAdminData?.load()?.appointments || []).find(row => row.id === button.dataset.checkIn);
        const message = rules(appointment);
        if (!message) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        window.alert(message);
    }, true);
    const watch = () => {
        const app = document.getElementById('adminPage');
        if (!app) return;
        const observer = new MutationObserver(update);
        observer.observe(app, {subtree: true, childList: true});
        update();
        window.setInterval(update, 15000);
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch);
    else watch();
})();
