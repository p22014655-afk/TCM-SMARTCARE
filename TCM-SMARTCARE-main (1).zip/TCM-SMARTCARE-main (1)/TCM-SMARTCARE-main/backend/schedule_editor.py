from datetime import date, datetime, time, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from .app import connect, require_account


router = APIRouter(prefix="/api/admin/schedule-editor", tags=["Doctor Schedule Editor"])
MALAYSIA = timezone(timedelta(hours=8))


class TimeWindow(BaseModel):
    startTime: str = Field(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    endTime: str = Field(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")


class WeekdaySchedule(BaseModel):
    dayOfWeek: int = Field(ge=1, le=6)
    windows: list[TimeWindow] = Field(max_length=2)


class WeeklyUpdate(BaseModel):
    days: list[WeekdaySchedule] = Field(min_length=6, max_length=6)


class DateUpdate(BaseModel):
    scheduleDate: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    windows: list[TimeWindow] = Field(max_length=2)


class CancelSlotPayload(BaseModel):
    scheduleDate: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    startTime: str = Field(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    endTime: str | None = Field(default=None, pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    reason: str = Field(default="Doctor unavailable", max_length=300)


def future_working_date(raw: str) -> date:
    try:
        selected = date.fromisoformat(raw)
    except ValueError:
        raise HTTPException(422, "Invalid schedule date.")
    if selected < datetime.now(MALAYSIA).date():
        raise HTTPException(422, "Choose today or a future date.")
    if selected.isoweekday() == 7:
        raise HTTPException(422, "Sunday is closed for the whole clinic.")
    return selected


def cancelled_slot_rows(connection, doctor_id, target_date):
    return connection.execute("""
        SELECT StartTime, EndTime, Reason
        FROM dbo.TCMDoctorCancelledSlots
        WHERE DoctorID = ? AND ScheduleDate = ?
        ORDER BY StartTime
    """, (doctor_id, target_date)).fetchall()


def ensure_no_booking_in_slot(connection, doctor_id, target_date, start_time, end_time):
    booking = connection.execute("""
        SELECT TOP 1 AppointmentID
        FROM dbo.Appointments WITH (UPDLOCK, HOLDLOCK)
        WHERE DoctorID = ? AND AppointmentDate = ?
          AND StartTime < ? AND (EndTime IS NULL OR EndTime > ?)
          AND (Status IS NULL OR Status NOT IN
            (N'Cancelled', N'Rejected', N'Completed', N'No Show'))
        ORDER BY AppointmentID
    """, (doctor_id, target_date, end_time, start_time)).fetchone()
    if booking:
        raise HTTPException(
            409,
            f"Appointment #{booking['AppointmentID']} is already booked at this time. "
            "Please reschedule or cancel the patient's appointment first. Nothing was changed."
        )


def minutes(t: time) -> int:
    return t.hour * 60 + t.minute


def display_time(t) -> str:
    return t.strftime("%H:%M") if hasattr(t, "strftime") else str(t)[:5]


def validate_windows(windows: list[TimeWindow]) -> list[tuple[time, time]]:
    parsed = []
    for window in windows:
        start = datetime.strptime(window.startTime, "%H:%M").time()
        end = datetime.strptime(window.endTime, "%H:%M").time()
        if not (420 <= minutes(start) < minutes(end) <= 1200):
            raise HTTPException(422, "Working hours must stay between 07:00 and 20:00.")
        if minutes(start) % 30 or minutes(end) % 30:
            raise HTTPException(422, "Working hours must use 30-minute intervals.")
        if minutes(start) < 15 * 60 and minutes(end) > 13 * 60:
            raise HTTPException(422, "Clinic rest is 13:00–15:00. Schedule early or late shifts outside the break.")
        parsed.append((start, end))
    parsed.sort(key=lambda item: item[0])
    if any(parsed[i][0] < parsed[i - 1][1] for i in range(1, len(parsed))):
        raise HTTPException(422, "A doctor's working time cannot overlap itself.")
    return parsed


def overlaps(a, b):
    return a[0] < b[1] and b[0] < a[1]


def assert_staff(request, connection):
    account = require_account(request, connection)
    if account.get("role") != "staff":
        raise HTTPException(403, "Staff access required.")


def get_doctor(connection, code):
    doctor = connection.execute("""
        SELECT DoctorID, DoctorCode, FullName
        FROM dbo.Doctors
        WHERE DoctorCode = ? AND IsActive = 1
    """, (code,)).fetchone()
    if not doctor:
        raise HTTPException(404, "Active doctor not found.")
    return doctor


def lock_editor(connection):
    cursor = connection.connection.cursor()
    cursor.execute("""
        SET NOCOUNT ON;
        DECLARE @result INT;
        EXEC @result = sys.sp_getapplock
            @Resource = N'TCMDoctorScheduleChanges',
            @LockMode = N'Exclusive',
            @LockOwner = N'Transaction',
            @LockTimeout = 7000;
        SELECT @result;
    """)
    value = cursor.fetchone()
    if not value or int(value[0]) < 0:
        raise HTTPException(409, "Another schedule update is in progress. Try again.")


def weekly_windows(connection, doctor_id, weekday):
    rows = connection.execute("""
        SELECT StartTime, EndTime
        FROM dbo.DoctorSchedules
        WHERE DoctorID = ? AND DayOfWeek = ? AND IsAvailable = 1
        ORDER BY StartTime
    """, (doctor_id, weekday)).fetchall()
    return [(row["StartTime"], row["EndTime"]) for row in rows]


def date_override(connection, doctor_id, target_date):
    rows = connection.execute("""
        SELECT StartTime, EndTime, IsClosed
        FROM dbo.TCMDoctorDateOverrides
        WHERE DoctorID = ? AND ScheduleDate = ?
        ORDER BY StartTime
    """, (doctor_id, target_date)).fetchall()
    if not rows:
        return None
    return [(row["StartTime"], row["EndTime"]) for row in rows if not row["IsClosed"]]


def effective_windows(connection, doctor_id, target_date):
    if target_date.isoweekday() == 7:
        return []
    override = date_override(connection, doctor_id, target_date)
    if override is not None:
        return override
    return weekly_windows(connection, doctor_id, target_date.isoweekday())


def future_appointments(connection, doctor_id, single_date=None):
    if single_date is None:
        rows = connection.execute("""
            SELECT AppointmentID, AppointmentDate, StartTime, EndTime
            FROM dbo.Appointments WITH (HOLDLOCK)
            WHERE DoctorID = ?
              AND AppointmentDate >= CONVERT(DATE, SYSDATETIME())
              AND (Status IS NULL OR Status NOT IN
                    (N'Cancelled', N'Rejected', N'Completed', N'No Show'))
        """, (doctor_id,)).fetchall()
    else:
        rows = connection.execute("""
            SELECT AppointmentID, AppointmentDate, StartTime, EndTime
            FROM dbo.Appointments WITH (HOLDLOCK)
            WHERE DoctorID = ? AND AppointmentDate = ?
              AND (Status IS NULL OR Status NOT IN
                    (N'Cancelled', N'Rejected', N'Completed', N'No Show'))
        """, (doctor_id, single_date)).fetchall()
    return rows


def validate_appointments(connection, doctor_id, proposed_week=None, specific_date=None, override_windows=None):
    for booking in future_appointments(connection, doctor_id, specific_date):
        target_date = booking["AppointmentDate"]
        if isinstance(target_date, datetime):
            target_date = target_date.date()
        if specific_date is not None:
            new_windows = override_windows
        else:
            custom = date_override(connection, doctor_id, target_date)
            new_windows = custom if custom is not None else proposed_week.get(target_date.isoweekday(), [])
        start = booking["StartTime"]
        end = booking["EndTime"]
        if end is None:
            end_minutes = minutes(start) + 30
        else:
            end_minutes = minutes(end)
        if not any(
            minutes(start) >= minutes(a) and end_minutes <= minutes(b)
            and end_minutes - minutes(start) == 30
            and (minutes(start) - minutes(a)) % 30 == 0
            for a, b in new_windows
        ):
            raise HTTPException(
                409,
                f"Appointment #{booking['AppointmentID']} on {target_date} at {display_time(start)} "
                "conflicts with these changes. Reschedule the patient first. Nothing was saved."
            )


def other_doctors(connection, doctor_id):
    return connection.execute("""
        SELECT DoctorID, FullName
        FROM dbo.Doctors
        WHERE IsActive = 1 AND DoctorID <> ?
    """, (doctor_id,)).fetchall()


def ensure_weekly_no_overlap(connection, doctor_id, proposed):
    others = other_doctors(connection, doctor_id)
    for day, windows in proposed.items():
        active_doctors = sum(1 for doctor in others if weekly_windows(connection, doctor["DoctorID"], day))
        if windows and active_doctors >= 2:
            raise HTTPException(409, f"{day}: Two other doctors already work on this weekday.")
        for other in others:
            other_windows = weekly_windows(connection, other["DoctorID"], day)
            if any(overlaps(a, b) for a in windows for b in other_windows):
                raise HTTPException(
                    409,
                    f"Your time overlaps with {other['FullName']} on weekday {day}. "
                    "Adjust one doctor's hours before saving the other."
                )
    future_dates = connection.execute("""
        SELECT DISTINCT ScheduleDate
        FROM dbo.TCMDoctorDateOverrides
        WHERE ScheduleDate >= CONVERT(DATE, SYSDATETIME())
          AND DoctorID <> ?
    """, (doctor_id,)).fetchall()
    for row in future_dates:
        day = row["ScheduleDate"]
        if isinstance(day, datetime):
            day = day.date()
        own_override = date_override(connection, doctor_id, day)
        if own_override is not None:
            continue
        windows = proposed.get(day.isoweekday(), [])
        if not windows:
            continue
        for other in others:
            for other_window in effective_windows(connection, other["DoctorID"], day):
                if any(overlaps(our, other_window) for our in windows):
                    raise HTTPException(409, f"Schedule overlaps with {other['FullName']} on {day}.")


def ensure_date_no_overlap(connection, doctor_id, target_date, windows):
    others = other_doctors(connection, doctor_id)
    working_others = 0
    for other in others:
        other_windows = effective_windows(connection, other["DoctorID"], target_date)
        if other_windows:
            working_others += 1
        if any(overlaps(a, b) for a in windows for b in other_windows):
            raise HTTPException(409, f"Schedule overlaps with {other['FullName']} on {target_date}.")
    if windows and working_others >= 2:
        raise HTTPException(409, f"Two other doctors already work on {target_date}.")


@router.get("")
def read_schedule_editor(request: Request):
    with connect() as connection:
        assert_staff(request, connection)
        doctors = connection.execute("""
            SELECT DoctorID, DoctorCode, FullName
            FROM dbo.Doctors
            WHERE IsActive = 1
            ORDER BY DoctorID
        """).fetchall()
        rows = connection.execute("""
            SELECT ds.DoctorID, ds.DayOfWeek, ds.StartTime, ds.EndTime
            FROM dbo.DoctorSchedules ds
            INNER JOIN dbo.Doctors d ON d.DoctorID = ds.DoctorID
            WHERE ds.IsAvailable = 1 AND d.IsActive = 1
            ORDER BY ds.DoctorID, ds.DayOfWeek, ds.StartTime
        """).fetchall()
        exceptions = connection.execute("""
            SELECT DoctorID, ScheduleDate, StartTime, EndTime, IsClosed
            FROM dbo.TCMDoctorDateOverrides
            WHERE ScheduleDate >= DATEADD(DAY, -7, CONVERT(DATE, SYSDATETIME()))
            ORDER BY DoctorID, ScheduleDate, StartTime
        """).fetchall()
        cancellations = connection.execute("""
            SELECT DoctorID, ScheduleDate, StartTime, EndTime, Reason
            FROM dbo.TCMDoctorCancelledSlots
            WHERE ScheduleDate BETWEEN DATEADD(DAY, -7, CONVERT(DATE, SYSDATETIME()))
                AND DATEADD(DAY, 180, CONVERT(DATE, SYSDATETIME()))
            ORDER BY DoctorID, ScheduleDate, StartTime
        """).fetchall()
        booked = connection.execute("""
            SELECT DoctorID, AppointmentDate, StartTime, EndTime
            FROM dbo.Appointments
            WHERE AppointmentDate BETWEEN CONVERT(DATE, SYSDATETIME())
                AND DATEADD(DAY, 180, CONVERT(DATE, SYSDATETIME()))
              AND (Status IS NULL OR Status NOT IN
                (N'Cancelled', N'Rejected', N'Completed', N'No Show'))
            ORDER BY DoctorID, AppointmentDate, StartTime
        """).fetchall()
        return {
            "cancelledSlots": [{
                "doctorId": r["DoctorID"],
                "date": str(r["ScheduleDate"])[:10],
                "startTime": display_time(r["StartTime"]),
                "endTime": display_time(r["EndTime"]),
                "reason": r["Reason"]
            } for r in cancellations],
            "bookedSlots": [{
                "doctorId": r["DoctorID"],
                "date": str(r["AppointmentDate"])[:10],
                "startTime": display_time(r["StartTime"]),
                "endTime": display_time(r["EndTime"]) if r["EndTime"] else None
            } for r in booked],
            "doctors": [{"id": d["DoctorID"], "code": d["DoctorCode"], "name": d["FullName"]} for d in doctors],
            "weekly": [{
                "doctorId": x["DoctorID"], "dayOfWeek": x["DayOfWeek"],
                "startTime": display_time(x["StartTime"]), "endTime": display_time(x["EndTime"])
            } for x in rows],
            "dateOverrides": [{
                "doctorId": x["DoctorID"], "date": str(x["ScheduleDate"])[:10],
                "startTime": display_time(x["StartTime"]) if x["StartTime"] else None,
                "endTime": display_time(x["EndTime"]) if x["EndTime"] else None,
                "isClosed": bool(x["IsClosed"])
            } for x in exceptions]
        }


@router.put("/doctors/{doctor_code}/weekly")
def save_weekly(doctor_code: str, payload: WeeklyUpdate, request: Request):
    weekdays = [day.dayOfWeek for day in payload.days]
    if sorted(weekdays) != [1, 2, 3, 4, 5, 6]:
        raise HTTPException(422, "Please submit one schedule for each day Monday through Saturday.")
    proposed = {day.dayOfWeek: validate_windows(day.windows) for day in payload.days}
    with connect() as connection:
        assert_staff(request, connection)
        lock_editor(connection)
        doctor = get_doctor(connection, doctor_code)
        ensure_weekly_no_overlap(connection, doctor["DoctorID"], proposed)
        validate_appointments(connection, doctor["DoctorID"], proposed_week=proposed)
        connection.execute("DELETE FROM dbo.DoctorSchedules WHERE DoctorID = ?", (doctor["DoctorID"],))
        count = 0
        for day, windows in proposed.items():
            for start, end in windows:
                connection.execute("""
                    INSERT INTO dbo.DoctorSchedules
                    (DoctorID, DayOfWeek, StartTime, EndTime, SlotDurationMinutes, Capacity, IsAvailable)
                    VALUES (?, ?, ?, ?, 30, 1, 1)
                """, (doctor["DoctorID"], day, display_time(start), display_time(end)))
                count += 1
        return {"message": "Weekly schedule saved to SQL Server.", "savedWindows": count}


@router.put("/doctors/{doctor_code}/date")
def save_date(doctor_code: str, payload: DateUpdate, request: Request):
    try:
        target_date = date.fromisoformat(payload.scheduleDate)
    except ValueError:
        raise HTTPException(422, "Invalid date.")
    if target_date < datetime.now(MALAYSIA).date():
        raise HTTPException(422, "Please select today or a future date.")
    if target_date.isoweekday() == 7:
        raise HTTPException(422, "Sunday is closed for all doctors.")
    windows = validate_windows(payload.windows)
    with connect() as connection:
        assert_staff(request, connection)
        lock_editor(connection)
        doctor = get_doctor(connection, doctor_code)
        ensure_date_no_overlap(connection, doctor["DoctorID"], target_date, windows)
        validate_appointments(connection, doctor["DoctorID"], specific_date=target_date, override_windows=windows)
        connection.execute("""
            DELETE FROM dbo.TCMDoctorDateOverrides
            WHERE DoctorID = ? AND ScheduleDate = ?
        """, (doctor["DoctorID"], target_date))
        if not windows:
            connection.execute("""
                INSERT INTO dbo.TCMDoctorDateOverrides
                (DoctorID, ScheduleDate, IsClosed)
                VALUES (?, ?, 1)
            """, (doctor["DoctorID"], target_date))
        else:
            for start, end in windows:
                connection.execute("""
                    INSERT INTO dbo.TCMDoctorDateOverrides
                    (DoctorID, ScheduleDate, StartTime, EndTime, IsClosed)
                    VALUES (?, ?, ?, ?, 0)
                """, (doctor["DoctorID"], target_date, display_time(start), display_time(end)))
        return {"message": f"Schedule for {target_date} saved to SQL Server."}


@router.delete("/doctors/{doctor_code}/date/{schedule_date}")
def clear_date(doctor_code: str, schedule_date: str, request: Request):
    try:
        target_date = date.fromisoformat(schedule_date)
    except ValueError:
        raise HTTPException(422, "Invalid date.")
    if target_date < datetime.now(MALAYSIA).date():
        raise HTTPException(422, "Past date exceptions cannot be changed.")
    with connect() as connection:
        assert_staff(request, connection)
        lock_editor(connection)
        doctor = get_doctor(connection, doctor_code)
        normal_windows = weekly_windows(connection, doctor["DoctorID"], target_date.isoweekday()) if target_date.isoweekday() != 7 else []
        ensure_date_no_overlap(connection, doctor["DoctorID"], target_date, normal_windows)
        validate_appointments(connection, doctor["DoctorID"], specific_date=target_date, override_windows=normal_windows)
        connection.execute("""
            DELETE FROM dbo.TCMDoctorDateOverrides
            WHERE DoctorID = ? AND ScheduleDate = ?
        """, (doctor["DoctorID"], target_date))
        return {"message": f"Date exception removed. {target_date} now follows the weekly schedule."}



class AddCalendarSlot(BaseModel):
    scheduleDate: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    startTime: str = Field(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")


@router.post("/doctors/{doctor_code}/add-slot", status_code=201)
def add_calendar_slot(doctor_code: str, payload: AddCalendarSlot, request: Request):
    target_date = future_working_date(payload.scheduleDate)
    selected_start = datetime.strptime(payload.startTime, "%H:%M").time()
    start_minutes = minutes(selected_start)
    if start_minutes % 30 or not 420 <= start_minutes < 1200:
        raise HTTPException(422, "Choose a 30-minute slot between 07:00 and 20:00.")
    if 13 * 60 <= start_minutes < 15 * 60:
        raise HTTPException(422, "Clinic rest is 13:00–15:00. No appointment slots during the break.")
    if datetime.combine(target_date, selected_start, tzinfo=MALAYSIA) <= datetime.now(MALAYSIA):
        raise HTTPException(422, "You cannot add an appointment time that has passed.")
    selected_end = time((start_minutes + 30) // 60, (start_minutes + 30) % 60)

    with connect() as connection:
        assert_staff(request, connection)
        lock_editor(connection)
        doctor = get_doctor(connection, doctor_code)
        doctor_id = doctor["DoctorID"]
        original = effective_windows(connection, doctor_id, target_date)
        if any(minutes(a) < start_minutes + 30 and start_minutes < minutes(b) for a, b in original):
            raise HTTPException(409, "This time is already in the doctor's working hours. Select it to cancel or restore.")
        if any(minutes(r["StartTime"]) == start_minutes for r in cancelled_slot_rows(connection, doctor_id, target_date)):
            raise HTTPException(409, "This slot was previously cancelled. Restore it instead.")

        all_windows = sorted(original + [(selected_start, selected_end)], key=lambda pair: pair[0])
        merged = []
        for start, end in all_windows:
            if merged and minutes(start) <= minutes(merged[-1][1]):
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        ensure_date_no_overlap(connection, doctor_id, target_date, merged)
        validate_appointments(connection, doctor_id, specific_date=target_date, override_windows=merged)
        connection.execute("DELETE FROM dbo.TCMDoctorDateOverrides WHERE DoctorID = ? AND ScheduleDate = ?", (doctor_id, target_date))
        for start, end in merged:
            connection.execute("""
                INSERT INTO dbo.TCMDoctorDateOverrides
                    (DoctorID, ScheduleDate, StartTime, EndTime, IsClosed)
                VALUES (?, ?, ?, ?, 0)
            """, (doctor_id, target_date, display_time(start), display_time(end)))
        return {
            "message": f"Added {doctor['FullName']} on {target_date} at {payload.startTime}–{display_time(selected_end)}.",
            "scheduleDate": payload.scheduleDate,
            "startTime": payload.startTime,
            "endTime": display_time(selected_end)
        }


@router.post("/doctors/{doctor_code}/cancel-slot", status_code=201)
def cancel_selected_time(doctor_code: str, payload: CancelSlotPayload, request: Request):
    target_date = future_working_date(payload.scheduleDate)
    start_minutes = minutes(datetime.strptime(payload.startTime, "%H:%M").time())
    if payload.endTime:
        end_minutes = minutes(datetime.strptime(payload.endTime, "%H:%M").time())
    else:
        end_minutes = start_minutes + 30
    if (start_minutes % 30 or end_minutes % 30 or
            not (420 <= start_minutes < end_minutes <= 1200)):
        raise HTTPException(422, "Choose a time range between 07:00 and 20:00 in 30-minute steps.")
    if datetime.combine(target_date, time(start_minutes // 60, start_minutes % 60), tzinfo=MALAYSIA) <= datetime.now(MALAYSIA):
        raise HTTPException(422, "You cannot cancel an appointment time that has already started.")

    def as_time(value):
        return time(value // 60, value % 60)

    requested_slots = [(as_time(m), as_time(m + 30)) for m in range(start_minutes, end_minutes, 30)]
    with connect() as connection:
        assert_staff(request, connection)
        lock_editor(connection)
        doctor = get_doctor(connection, doctor_code)
        doctor_id = doctor["DoctorID"]
        windows = effective_windows(connection, doctor_id, target_date)
        if not all(any(
            minutes(slot_start) >= minutes(working_start) and
            minutes(slot_end) <= minutes(working_end) and
            (minutes(slot_start) - minutes(working_start)) % 30 == 0
            for working_start, working_end in windows
        ) for slot_start, slot_end in requested_slots):
            raise HTTPException(409, "Selected hours are outside the doctor's working schedule or span a break.")
        cancelled_starts = {minutes(row["StartTime"]) for row in cancelled_slot_rows(connection, doctor_id, target_date)}
        if any(minutes(slot_start) in cancelled_starts for slot_start, _ in requested_slots):
            raise HTTPException(409, "Part of this time range has already been cancelled. Choose another range.")
        for slot_start, slot_end in requested_slots:
            ensure_no_booking_in_slot(connection, doctor_id, target_date, slot_start, slot_end)
        for slot_start, slot_end in requested_slots:
            connection.execute("""
                INSERT INTO dbo.TCMDoctorCancelledSlots
                    (DoctorID, ScheduleDate, StartTime, EndTime, Reason)
                VALUES (?, ?, ?, ?, ?)
            """, (doctor_id, target_date, display_time(slot_start), display_time(slot_end),
                  payload.reason.strip() or "Doctor unavailable"))
        return {
            "message": f"{doctor['FullName']} is unavailable on {target_date} "
                       f"from {payload.startTime} to {display_time(as_time(end_minutes))}. "
                       f"{len(requested_slots)} appointment slot(s) cancelled.",
            "date": payload.scheduleDate,
            "startTime": payload.startTime,
            "endTime": display_time(as_time(end_minutes)),
            "slotsCancelled": len(requested_slots)
        }


@router.delete("/doctors/{doctor_code}/cancel-slot/{schedule_date}/{slot_start}")
def restore_single_slot(doctor_code: str, schedule_date: str, slot_start: str, request: Request):
    target_date = future_working_date(schedule_date)
    try:
        requested = datetime.strptime(slot_start, "%H:%M").time()
    except ValueError:
        raise HTTPException(422, "Invalid appointment time.")
    with connect() as connection:
        assert_staff(request, connection)
        lock_editor(connection)
        doctor = get_doctor(connection, doctor_code)
        existing = connection.execute("""
            SELECT EndTime FROM dbo.TCMDoctorCancelledSlots
            WHERE DoctorID = ? AND ScheduleDate = ? AND StartTime = ?
        """, (doctor["DoctorID"], target_date, slot_start)).fetchone()
        if not existing:
            raise HTTPException(404, "Cancelled time slot not found.")
        windows = effective_windows(connection, doctor["DoctorID"], target_date)
        if not any(minutes(requested) >= minutes(a) and minutes(existing["EndTime"]) <= minutes(b)
                   for a, b in windows):
            raise HTTPException(409, "Restore the doctor's working hours first, then restore this slot.")
        # Restoring a cancelled slot only removes the cancellation record; it
        # does NOT change any weekly/date working hours.  Legacy rota conflicts
        # must be fixed in the schedule editor, not mistaken for an edit race.
        # Never rely on pyodbc cursor.rowcount here: with SQL Server/NOCOUNT it
        # can be -1 even though the DELETE succeeded.
        connection.execute("""
            DELETE FROM dbo.TCMDoctorCancelledSlots
            WHERE DoctorID = ? AND ScheduleDate = ? AND StartTime = ?
        """, (doctor["DoctorID"], target_date, slot_start))
        still_cancelled = connection.execute("""
            SELECT TOP 1 1 FROM dbo.TCMDoctorCancelledSlots
            WHERE DoctorID = ? AND ScheduleDate = ? AND StartTime = ?
        """, (doctor["DoctorID"], target_date, slot_start)).fetchone()
        if still_cancelled:
            raise HTTPException(409, "This cancelled slot could not be restored. Refresh and retry.")
        return {"message": f"{doctor['FullName']}'s {target_date} {slot_start} time slot is available again."}
