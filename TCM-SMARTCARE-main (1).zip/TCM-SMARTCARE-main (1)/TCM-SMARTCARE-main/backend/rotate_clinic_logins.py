import getpass
import json
import re
import sys

from .app import connect, initialize_database, set_password


def valid_email(email):
    return re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email) is not None


def main():
    initialize_database()
    with connect() as connection:
        accounts = connection.execute("""
            SELECT id, role, staff_id, email
            FROM dbo.accounts
            WHERE role IN ('staff', 'doctor')
            ORDER BY CASE role WHEN 'staff' THEN 0 ELSE 1 END, staff_id
        """).fetchall()
        state_row = connection.execute(
            "SELECT data_json FROM dbo.admin_state WHERE id = 1"
        ).fetchone()

    if not accounts or not state_row:
        print("No initialized clinic accounts found. Set up your TCM_SmartCare database first.")
        return

    changes = []
    passwords = set()
    legacy_ids = {"staff-frontdesk", "dr-lim", "dr-tan", "dr-wong"}
    print("Each clinic account needs its own password. Enter it without displaying it on screen.")
    print("For any account you do not want to change, press Enter at the new password prompt.")
    for account in accounts:
        print(f"\n{account['role'].upper()}: {account['staff_id']} ({account['id']})")
        print(f"Current email: {account['email']}")
        while True:
            entered = input("New email (Enter to keep): ").strip().lower()
            email = entered or account['email']
            if valid_email(email) and len(email) <= 254:
                break
            print("Invalid email address.")
        while True:
            password = getpass.getpass("New password (Enter to keep): ")
            if not password and account['id'] not in legacy_ids:
                break
            if not password:
                print("Please replace this legacy account's shared default password.")
                continue
            if password in ("Staff123!", "Doctor123!"):
                print("Do not reuse the old default password.")
                continue
            if len(password) < 8 or password in passwords:
                print("Use at least 8 characters and a different password for each account.")
                continue
            confirmation = getpass.getpass("Repeat new password: ")
            if password != confirmation:
                print("Passwords do not match.")
                continue
            passwords.add(password)
            break
        changes.append((account, email, password))

    check = [email.casefold() for _, email, _ in changes]
    if len(set(check)) != len(check):
        print("Duplicate email addresses detected. Nothing was updated.")
        return

    answer = input("\nApply these changes to SQL Server? Type YES: ").strip()
    if answer != "YES":
        print("Cancelled. No changes were made.")
        return

    with connect() as connection:
        row = connection.execute(
            "SELECT data_json FROM dbo.admin_state WITH (UPDLOCK, HOLDLOCK) WHERE id = 1"
        ).fetchone()
        state = json.loads(row['data_json'])
        for account, email, password in changes:
            connection.execute(
                "UPDATE dbo.accounts SET email = ? WHERE id = ?",
                (email, account['id']),
            )
            for key in ('staff', 'doctors'):
                for record in state.get(key, []):
                    if record.get('id') == account['id']:
                        record['email'] = email
                        record.pop('password', None)
            if account['role'] == 'doctor':
                connection.execute(
                    "UPDATE dbo.Doctors SET Email = ? WHERE DoctorCode = ?",
                    (email, account['id']),
                )
            if password:
                set_password(connection, account['id'], password)
                connection.execute(
                    "DELETE FROM dbo.sessions WHERE account_id = ?",
                    (account['id'],),
                )
        connection.execute(
            "UPDATE dbo.admin_state SET data_json = ?, updated_at = SYSDATETIMEOFFSET() WHERE id = 1",
            (json.dumps(state, ensure_ascii=False, separators=(',', ':')) ,),
        )
    print("\nClinic account credentials updated successfully. Sign in again with the new details.")


def apply_demo_accounts():
    """One-time LOCAL TEST migration. Keeps immutable account IDs and all doctor bookings."""
    demo_passwords = {"doctor": "Doctor123！", "staff": "Staff123!"}
    initialize_database()
    with connect() as connection:
        state_row = connection.execute(
            "SELECT data_json FROM dbo.admin_state WITH (UPDLOCK, HOLDLOCK) WHERE id = 1"
        ).fetchone()
        if not state_row:
            raise RuntimeError("Admin state not initialized. Open the staff portal first.")
        state = json.loads(state_row["data_json"])
        accounts = connection.execute("""
            SELECT id, role, staff_id FROM dbo.accounts WITH (UPDLOCK, HOLDLOCK)
            WHERE role IN ('doctor', 'staff')
            ORDER BY role, staff_id
        """).fetchall()
        if not accounts:
            raise RuntimeError("No clinic accounts found; nothing was changed.")

        # Keep existing doctor001 ... doctor003 and staff001 IDs unchanged.
        # Convert ONLY old randomly generated six-digit sign-in IDs.
        # The internal account ID and DoctorCode are never changed.
        used = {str(a["staff_id"]).lower() for a in accounts}
        next_number = {}
        for role in ("doctor", "staff"):
            numbered = [
                int(m.group(1))
                for a in accounts if a["role"] == role
                for m in [re.fullmatch(rf"{role}(\d{{3,5}})", str(a["staff_id"]), re.I)]
                if m
            ]
            next_number[role] = max(numbered, default=0) + 1

        changes = []
        for account in accounts:
            role = str(account["role"])
            previous = str(account["staff_id"])
            updated = previous
            if re.fullmatch(rf"{role}\d{{6}}", previous, re.I):
                while True:
                    candidate = f"{role}{next_number[role]:03d}"
                    next_number[role] += 1
                    if candidate.lower() not in used:
                        updated = candidate
                        used.add(candidate.lower())
                        break
                connection.execute(
                    "UPDATE dbo.accounts SET staff_id = ? WHERE id = ?",
                    (updated, account["id"]),
                )
                key = "doctors" if role == "doctor" else "staff"
                found = False
                for record in state.get(key, []):
                    if str(record.get("id")) == str(account["id"]):
                        record["staffId"] = updated
                        found = True
                        break
                if not found:
                    raise RuntimeError(f"Account {account['id']} missing from admin_state; changes rolled back.")

            set_password(connection, str(account["id"]), demo_passwords[role])
            connection.execute(
                "DELETE FROM dbo.sessions WHERE account_id = ?", (account["id"],)
            )
            changes.append((role, previous, updated))

        connection.execute(
            "UPDATE dbo.admin_state SET data_json = ?, updated_at = SYSDATETIMEOFFSET() WHERE id = 1",
            (json.dumps(state, ensure_ascii=False, separators=(',', ':')),),
        )
    for role, previous, updated in changes:
        label = f"{previous} -> {updated}" if previous != updated else updated
        print(f"{role}: {label} | password reset (PBKDF2 salted hash)")
    print("Local test logins updated. All previous sessions were signed out.")
    print("WARNING: shared passwords are unsafe for a deployed clinic system.")


if __name__ == '__main__':
    if sys.argv[1:] == ["--apply-demo-accounts"]:
        apply_demo_accounts()
    else:
        main()
