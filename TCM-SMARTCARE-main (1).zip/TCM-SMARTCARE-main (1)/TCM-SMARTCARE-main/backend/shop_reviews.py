from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from product_review_schema import ensure_product_review_schema

router = APIRouter(prefix="/api/admin", tags=["Shop Reviews"])


class ReviewReplyPayload(BaseModel):
    reply: str = Field(min_length=1, max_length=2000)


class ReviewFeaturedPayload(BaseModel):
    featured: bool


class ReviewEditPayload(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: str = Field(min_length=1)


def staff_connection(request):
    from .app import connect, require_account
    return connect, require_account


def require_staff(request, db):
    _, require_account = staff_connection(request)
    account = require_account(request, db)
    if account.get("role") != "staff":
        raise HTTPException(403, "Staff access required.")
    return str(account.get("id") or account.get("account_id") or "staff")


@router.get("/shop-reviews")
def list_shop_reviews(request: Request):
    connect, _ = staff_connection(request)
    with connect() as db:
        require_staff(request, db)
        ensure_product_review_schema(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT r.ReviewID, r.OrderID, r.ProductName, r.Rating,
                   r.Comment, r.CreatedAt, r.IsHidden, r.EditedByStaffAt,
                   r.ModeratedAt, r.ModeratedBy, p.FullName, p.Email,
                   r.IsFeatured, r.StaffReply, r.StaffRepliedAt
            FROM dbo.TCMProductReviews r
            JOIN dbo.Patients p ON r.PatientID = p.PatientID
            ORDER BY CASE WHEN r.IsHidden = 0 AND r.IsFeatured = 1 THEN 0 ELSE 1 END,
                     r.CreatedAt DESC, r.ReviewID DESC
        """)
        reviews = []
        for row in cursor.fetchall():
            reviews.append({
                "reviewId": int(row.ReviewID),
                "orderId": int(row.OrderID),
                "productName": str(row.ProductName),
                "rating": int(row.Rating),
                "comment": str(row.Comment or ""),
                "createdAt": row.CreatedAt.isoformat() if row.CreatedAt else "",
                "hidden": bool(row.IsHidden),
                "editedByStaff": row.EditedByStaffAt is not None,
                "editedAt": row.EditedByStaffAt.isoformat() if row.EditedByStaffAt else None,
                "moderatedAt": row.ModeratedAt.isoformat() if row.ModeratedAt else None,
                "moderatedBy": row.ModeratedBy,
                "customerName": str(row.FullName or "Customer"),
                "customerEmail": str(row.Email or ""),
                "featured": bool(row.IsFeatured),
                "staffReply": str(row.StaffReply or ""),
                "staffRepliedAt": row.StaffRepliedAt.isoformat() if row.StaffRepliedAt else None
            })
        return {"reviews": reviews}


@router.put("/shop-reviews/{review_id}/reply")
def reply_to_shop_review(review_id: int, payload: ReviewReplyPayload, request: Request):
    reply = payload.reply.strip()
    if not reply:
        raise HTTPException(422, "Reply cannot be blank.")
    connect, _ = staff_connection(request)
    with connect() as db:
        staff_id = require_staff(request, db)
        ensure_product_review_schema(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT IsHidden FROM dbo.TCMProductReviews WITH (UPDLOCK, HOLDLOCK)
            WHERE ReviewID = ?
        """, review_id)
        row = cursor.fetchone()
        if row is None:
            raise HTTPException(404, "Review not found.")
        if row.IsHidden:
            raise HTTPException(409, "Restore the review before replying.")
        cursor.execute("""
            UPDATE dbo.TCMProductReviews
            SET StaffReply = ?, StaffRepliedAt = SYSDATETIME(),
                ModeratedAt = SYSDATETIME(), ModeratedBy = ?
            WHERE ReviewID = ? AND IsHidden = 0
        """, reply, staff_id, review_id)
        return {"message": "Clinic reply saved and visible to customers."}


@router.put("/shop-reviews/{review_id}/featured")
def set_shop_review_featured(review_id: int, payload: ReviewFeaturedPayload, request: Request):
    connect, _ = staff_connection(request)
    with connect() as db:
        staff_id = require_staff(request, db)
        ensure_product_review_schema(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT IsHidden FROM dbo.TCMProductReviews WITH (UPDLOCK, HOLDLOCK)
            WHERE ReviewID = ?
        """, review_id)
        row = cursor.fetchone()
        if row is None:
            raise HTTPException(404, "Review not found.")
        if row.IsHidden and payload.featured:
            raise HTTPException(409, "Restore the review before featuring it.")
        cursor.execute("""
            UPDATE dbo.TCMProductReviews
            SET IsFeatured = ?, ModeratedAt = SYSDATETIME(), ModeratedBy = ?
            WHERE ReviewID = ?
        """, 1 if payload.featured else 0, staff_id, review_id)
        return {"message": "Review marked as featured." if payload.featured else "Review removed from featured."}


@router.put("/shop-reviews/{review_id}")
def edit_shop_review(review_id: int, payload: ReviewEditPayload, request: Request):
    content = payload.comment.strip()
    if not content:
        raise HTTPException(422, "Review text cannot be empty.")
    connect, _ = staff_connection(request)
    with connect() as db:
        staff_id = require_staff(request, db)
        ensure_product_review_schema(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT Rating, Comment, IsHidden
            FROM dbo.TCMProductReviews WITH (UPDLOCK, HOLDLOCK)
            WHERE ReviewID = ?
        """, review_id)
        row = cursor.fetchone()
        if row is None:
            raise HTTPException(404, "Review not found.")
        if row.IsHidden:
            raise HTTPException(409, "Restore this review before editing it.")
        if int(row.Rating) == payload.rating and str(row.Comment) == content:
            return {"message": "No changes needed."}
        cursor.execute("""
            UPDATE dbo.TCMProductReviews
            SET Rating = ?, Comment = ?, EditedByStaffAt = SYSDATETIME(),
                ModeratedAt = SYSDATETIME(), ModeratedBy = ?
            WHERE ReviewID = ? AND IsHidden = 0
        """, payload.rating, content, staff_id, review_id)
        cursor.execute("""
            INSERT INTO dbo.TCMReviewModerationLog
                (ReviewID, ActionName, StaffAccountID, OldRating,
                 NewRating, OldComment, NewComment)
            VALUES (?, N'Edited', ?, ?, ?, ?, ?)
        """, review_id, staff_id, int(row.Rating), payload.rating, row.Comment, content)
        return {"message": "Review updated. Customers will see that it was edited by staff."}


@router.delete("/shop-reviews/{review_id}")
def hide_shop_review(review_id: int, request: Request):
    connect, _ = staff_connection(request)
    with connect() as db:
        staff_id = require_staff(request, db)
        ensure_product_review_schema(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT Rating, Comment, IsHidden
            FROM dbo.TCMProductReviews WITH (UPDLOCK, HOLDLOCK)
            WHERE ReviewID = ?
        """, review_id)
        row = cursor.fetchone()
        if row is None:
            raise HTTPException(404, "Review not found.")
        if row.IsHidden:
            raise HTTPException(409, "Review is already hidden.")
        cursor.execute("""
            UPDATE dbo.TCMProductReviews
            SET IsHidden = 1, IsFeatured = 0, ModeratedAt = SYSDATETIME(), ModeratedBy = ?
            WHERE ReviewID = ? AND IsHidden = 0
        """, staff_id, review_id)
        cursor.execute("""
            INSERT INTO dbo.TCMReviewModerationLog
                (ReviewID, ActionName, StaffAccountID, OldRating, OldComment)
            VALUES (?, N'Hidden', ?, ?, ?)
        """, review_id, staff_id, int(row.Rating), row.Comment)
        return {"message": "Review hidden from the shop and product ratings."}


@router.post("/shop-reviews/{review_id}/restore")
def restore_shop_review(review_id: int, request: Request):
    connect, _ = staff_connection(request)
    with connect() as db:
        staff_id = require_staff(request, db)
        ensure_product_review_schema(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT Rating, Comment, IsHidden
            FROM dbo.TCMProductReviews WITH (UPDLOCK, HOLDLOCK)
            WHERE ReviewID = ?
        """, review_id)
        row = cursor.fetchone()
        if row is None:
            raise HTTPException(404, "Review not found.")
        if not row.IsHidden:
            raise HTTPException(409, "Review is already visible.")
        cursor.execute("""
            UPDATE dbo.TCMProductReviews
            SET IsHidden = 0, ModeratedAt = SYSDATETIME(), ModeratedBy = ?
            WHERE ReviewID = ? AND IsHidden = 1
        """, staff_id, review_id)
        cursor.execute("""
            INSERT INTO dbo.TCMReviewModerationLog
                (ReviewID, ActionName, StaffAccountID, NewRating, NewComment)
            VALUES (?, N'Restored', ?, ?, ?)
        """, review_id, staff_id, int(row.Rating), row.Comment)
        return {"message": "Review restored and visible in the shop."}
