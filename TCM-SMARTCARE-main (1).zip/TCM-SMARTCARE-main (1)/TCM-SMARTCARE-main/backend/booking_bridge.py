"""Read actual clinic patients/appointments, never the demo admin_state snapshots.
All identifiers in the admin UI are stable handles for SQL primary keys.
"""
from datetime import datetime, date, time, timedelta
from fastapi import HTTPException


ACTIVE = {'Scheduled', 'Checked In', 'In Consultation', 'Rescheduled'}
STATUS_VALUES = ACTIVE | {'Completed', 'Cancelled', 'Rejected', 'No Show'}


def patient_key(id_value):
    return f'PAT-SQL-{int(id_value)}'


def appointment_key(id_value):
    return f'APT-SQL-{int(id_value)}'


def parse_key(value, prefix):
    text = str(value)
    if not text.startswith(prefix) or not text[len(prefix):].isdigit():
        raise HTTPException(422, 'Select an SQL Server appointment or patient.')
    return int(text[len(prefix):])


def full_state(connection, account):
    doctor_code = account['id'] if account['role'] == 'doctor' else None
    doctor_where = 'WHERE d.DoctorCode = ?' if doctor_code else ''
    from .appointment_expiry import expire_overdue_appointments
    expire_overdue_appointments(connection)
    appointments = connection.execute(f"""
        SELECT a.AppointmentID, a.PatientID, a.DoctorID, a.ServiceID,
               a.AppointmentDate, a.StartTime, a.EndTime, a.Status, a.Room,
               p.FullName AS PatientName, p.Email AS PatientEmail, p.Phone AS PatientPhone,
               d.DoctorCode, d.FullName AS DoctorName, s.ServiceName
        FROM dbo.Appointments a
        JOIN dbo.Patients p ON p.PatientID = a.PatientID
        JOIN dbo.Doctors d ON d.DoctorID = a.DoctorID
        JOIN dbo.Services s ON s.ServiceID = a.ServiceID
        {doctor_where}
        ORDER BY a.AppointmentDate DESC, a.StartTime DESC, a.AppointmentID DESC
    """, (doctor_code,) if doctor_code else ()).fetchall()
    patient_where = """WHERE EXISTS (
            SELECT 1 FROM dbo.Appointments a
            JOIN dbo.Doctors d ON d.DoctorID = a.DoctorID
            WHERE a.PatientID = p.PatientID AND d.DoctorCode = ?)""" if doctor_code else ''
    # Profile details are linked by SQL PatientID, not by email or display name.
    has_profile_details = bool(connection.execute(
        "SELECT OBJECT_ID(N'dbo.TCMPatientProfileDetails', N'U') AS ID"
    ).fetchone()['ID'])
    extra_fields = ("pd.BirthDate, pd.ContactMethod, pd.Address, pd.Photo,"
                    if has_profile_details else
                    "CAST(NULL AS DATE) AS BirthDate, CAST(NULL AS NVARCHAR(10)) AS ContactMethod, "
                    "CAST(NULL AS NVARCHAR(1000)) AS Address, CAST(NULL AS NVARCHAR(MAX)) AS Photo,")
    details_join = ("LEFT JOIN dbo.TCMPatientProfileDetails pd ON pd.PatientID=p.PatientID"
                    if has_profile_details else "")
    patients = connection.execute(f"""
        SELECT p.PatientID, p.FullName, p.Email, p.Phone,
               {extra_fields}
               (SELECT MAX(prior.AppointmentDate)
                FROM dbo.Appointments prior
                WHERE prior.PatientID = p.PatientID
                  AND prior.Status = 'Completed'
                  AND prior.AppointmentDate < CAST(GETDATE() AS DATE)
               ) AS LastVisit
        FROM dbo.Patients p
        {details_join}
        {patient_where}
        ORDER BY p.FullName
    """, (doctor_code,) if doctor_code else ()).fetchall()
    patient_data = [{
        'id': patient_key(row['PatientID']), 'name': row['FullName'],
        'email': row['Email'], 'phone': row['Phone'] or '',
        'birthDate': str(row['BirthDate'])[:10] if row['BirthDate'] else '',
        'contactMethod': row['ContactMethod'] or 'phone',
        'address': row['Address'] or '', 'photo': row['Photo'] or '',
        'joined': '', 'lastVisit': str(row['LastVisit'])[:10] if row['LastVisit'] is not None else '',
        'preConsultation': {'submitted': False}
    } for row in patients]
    appointment_data = [{
        'id': appointment_key(row['AppointmentID']),
        'patientId': patient_key(row['PatientID']),
        'patient': row['PatientName'], 'patientEmail': row['PatientEmail'],
        'contact': row['PatientPhone'] or '',
        'doctorId': row['DoctorCode'], 'doctor': row['DoctorName'],
        'service': row['ServiceName'], 'date': str(row['AppointmentDate'])[:10],
        'time': str(row['StartTime'])[:5],
        'endTime': str(row['EndTime'])[:5] if row['EndTime'] else '',
        'room': row['Room'] or 'To be assigned',
        'status': row['Status'] or 'Scheduled'
    } for row in appointments]
    return patient_data, appointment_data


def check_access(connection, account, appointment_id):
    row = connection.execute('''
        SELECT a.AppointmentID, a.PatientID, a.DoctorID, a.AppointmentDate,
               a.StartTime, a.EndTime, a.Status, d.DoctorCode
        FROM dbo.Appointments a JOIN dbo.Doctors d ON a.DoctorID = d.DoctorID
        WHERE a.AppointmentID = ?
    ''', (appointment_id,)).fetchone()
    if not row:
        raise HTTPException(404, 'Appointment not found.')
    if account['role'] == 'doctor' and row['DoctorCode'] != account['id']:
        raise HTTPException(403, 'This appointment belongs to another doctor.')
    return row


def set_status(connection, account, appointment_id, new_status):
    if new_status not in STATUS_VALUES:
        raise HTTPException(422, 'Invalid appointment status.')
    from .appointment_expiry import expire_overdue_appointments
    expire_overdue_appointments(connection)
    row = check_access(connection, account, appointment_id)
    if row['Status'] in ('Cancelled', 'Completed', 'Rejected', 'No Show') and new_status != row['Status']:
        raise HTTPException(409, 'This appointment is already closed.')
    if new_status == 'In Consultation' and row['Status'] != 'Checked In':
        raise HTTPException(409, 'Check in the patient before starting the consultation.')
    if new_status == 'Completed' and row['Status'] not in ('Checked In', 'In Consultation', 'Completed'):
        raise HTTPException(409, 'Check in the patient before completing the appointment.')
    if new_status == 'Checked In':
        if row['Status'] not in ('Scheduled', 'Rescheduled'):
            raise HTTPException(409, 'Only scheduled or rescheduled appointments can be checked in.')
        updated = connection.execute('''
            UPDATE dbo.Appointments SET Status = 'Checked In'
            OUTPUT INSERTED.AppointmentID
            WHERE AppointmentID = ?
              AND Status IN ('Scheduled', 'Rescheduled')
              AND AppointmentDate = CONVERT(date, SYSDATETIME())
              AND COALESCE(EndTime, CONVERT(time(0), DATEADD(minute, 30, CAST(StartTime AS datetime)))) > CONVERT(time, SYSDATETIME())
        ''', (appointment_id,)).fetchone()
        if not updated:
            raise HTTPException(409, 'Check-in is only available on the appointment date before the booked time ends. Please refresh.')
    else:
        updated = connection.execute('''
            UPDATE dbo.Appointments SET Status = ?
            OUTPUT INSERTED.AppointmentID
            WHERE AppointmentID = ? AND Status = ?
        ''', (new_status, appointment_id, row['Status'])).fetchone()
        if not updated:
            raise HTTPException(409, 'Appointment was changed. Please refresh.')
    return {'status': new_status, 'id': appointment_key(appointment_id)}


def validate_slot(connection, date_value, start_value, doctor_code, *, exclude_appointment=None):
    try:
        target_date = date.fromisoformat(str(date_value))
        start = time.fromisoformat(str(start_value)[:5])
    except ValueError:
        raise HTTPException(422, 'Invalid appointment date or time.')
    if target_date.weekday() == 6 or not (time(7) <= start < time(20)):
        raise HTTPException(409, 'The clinic is closed at this time.')
    if start.minute not in (0, 30) or time(13) <= start < time(15):
        raise HTTPException(409, 'Appointments are 30 minutes; 1–3 PM is clinic rest.')
    end_dt = datetime.combine(target_date, start) + timedelta(minutes=30)
    end = end_dt.time()
    if end > time(20):
        raise HTTPException(409, 'The clinic is closed at this time.')
    doc = connection.execute('''SELECT DoctorID, DoctorCode FROM dbo.Doctors
        WHERE DoctorCode = ? AND IsActive = 1''', (doctor_code,)).fetchone()
    if not doc:
        raise HTTPException(404, 'Doctor not found.')
    doctor_id = doc['DoctorID']
    override = connection.execute('''SELECT COUNT(*) AS n FROM dbo.TCMDoctorDateOverrides
        WHERE DoctorID = ? AND ScheduleDate = ?''', (doctor_id, target_date)).fetchone()['n']
    if override:
        windows = connection.execute('''SELECT StartTime, EndTime FROM dbo.TCMDoctorDateOverrides
            WHERE DoctorID = ? AND ScheduleDate = ? AND IsClosed = 0''',
            (doctor_id, target_date)).fetchall()
    else:
        windows = connection.execute('''SELECT StartTime, EndTime FROM dbo.DoctorSchedules
            WHERE DoctorID = ? AND DayOfWeek = ? AND IsAvailable = 1''',
            (doctor_id, target_date.isoweekday())).fetchall()
    if not any(r['StartTime'] <= start and end <= r['EndTime'] for r in windows):
        raise HTTPException(409, 'Outside the doctor’s scheduled working hours.')
    cancelled = connection.execute('''SELECT COUNT(*) AS n FROM dbo.TCMDoctorCancelledSlots
        WHERE DoctorID = ? AND ScheduleDate = ? AND StartTime < ? AND EndTime > ?''',
        (doctor_id, target_date, end, start)).fetchone()['n']
    if cancelled:
        raise HTTPException(409, 'Doctor has cancelled this time.')
    excluded = 'AND AppointmentID <> ?' if exclude_appointment is not None else ''
    params = (doctor_id, target_date, end, start)
    if exclude_appointment is not None:
        params += (exclude_appointment,)
    collision = connection.execute(f'''SELECT COUNT(*) AS n FROM dbo.Appointments
        WHERE DoctorID = ? AND AppointmentDate = ?
          AND StartTime < ? AND (EndTime IS NULL OR EndTime > ?)
          AND (Status IS NULL OR Status NOT IN ('Cancelled','Rejected'))
          {excluded}''', params).fetchone()['n']
    if collision:
        raise HTTPException(409, 'This appointment slot is already taken.')
    return target_date, start, end, doctor_id
