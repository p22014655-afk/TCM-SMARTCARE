from fastapi import APIRouter, HTTPException, Request

router = APIRouter(prefix="/api/admin/doctor-directory", tags=["Doctor Directory"])


def sync_doctor_accounts(connection, previous_accounts, current_accounts):
    previous = {str(account.get("id")): account for account in previous_accounts}
    for account in current_accounts:
        doctor_code = str(account.get("id", "")).strip()
        before = previous.get(doctor_code)
        if before == account:
            continue
        if not doctor_code or len(doctor_code) > 30:
            raise HTTPException(422, "Doctor ID must contain 1 to 30 characters.")
        full_name = str(account.get("name", "")).strip()
        email = str(account.get("email", "")).strip()
        specialty = str(account.get("specialization", "")).strip()
        if not full_name or len(full_name) > 100 or len(email) > 255 or len(specialty) > 150:
            raise HTTPException(422, "Invalid doctor name, email or specialization.")
        raw_services = account.get("services", [])
        if not isinstance(raw_services, list):
            raise HTTPException(422, "Doctor services must be a list.")
        service_rows = connection.execute("""
            SELECT ServiceID, ServiceName FROM dbo.Services WHERE IsActive = 1
        """).fetchall()
        by_name = {str(row["ServiceName"]).casefold(): row for row in service_rows}
        if "cupping" in by_name and "cupping therapy" not in by_name:
            by_name["cupping therapy"] = by_name["cupping"]
        if "cupping therapy" in by_name and "cupping" not in by_name:
            by_name["cupping"] = by_name["cupping therapy"]
        chosen = []
        for label in raw_services:
            key = str(label).strip().casefold()
            if key not in by_name:
                raise HTTPException(422, f"Service unavailable: {label}")
            service_id = int(by_name[key]["ServiceID"])
            if service_id not in chosen:
                chosen.append(service_id)
        row = connection.execute("""
            SELECT DoctorID, Specialization FROM dbo.Doctors
            WHERE DoctorCode = ?
        """, (doctor_code,)).fetchone()
        if row:
            doctor_id = int(row["DoctorID"])
            connection.execute("""
                UPDATE dbo.Doctors SET FullName = ?, Email = ?,
                    Specialization = ?, IsActive = 1
                WHERE DoctorID = ?
            """, (full_name, email, specialty or row["Specialization"], doctor_id))
        else:
            result = connection.execute("""
                INSERT INTO dbo.Doctors
                    (DoctorCode, FullName, Email, Specialization, IsActive)
                OUTPUT INSERTED.DoctorID
                VALUES (?, ?, ?, ?, 1)
            """, (doctor_code, full_name, email, specialty or "TCM Practitioner"))
            doctor_id = int(result.fetchone()["DoctorID"])
        cursor = connection.execute("""
            SELECT DISTINCT ServiceID FROM dbo.Appointments
            WHERE DoctorID = ? AND AppointmentDate >= CONVERT(DATE, SYSDATETIME())
              AND (Status IS NULL OR Status NOT IN ('Cancelled', 'Rejected', 'Completed', 'No Show'))
        """, (doctor_id,))
        booked_service_ids = {int(record["ServiceID"]) for record in cursor.fetchall()}
        if not booked_service_ids.issubset(set(chosen)):
            raise HTTPException(409, "The doctor has upcoming appointments for a service being removed. Reassign those appointments first.")
        connection.execute("DELETE FROM dbo.DoctorServices WHERE DoctorID = ?", (doctor_id,))
        for service_id in chosen:
            connection.execute("""
                INSERT INTO dbo.DoctorServices (DoctorID, ServiceID)
                VALUES (?, ?)
            """, (doctor_id, service_id))


@router.get("/services")
def get_doctor_services_for_admin(request: Request):
    from .app import connect, require_account
    with connect() as connection:
        account = require_account(request, connection)
        if account["role"] != "staff":
            raise HTTPException(403, "Staff access required.")
        rows = connection.execute("""
            SELECT ServiceID, ServiceName FROM dbo.Services
            WHERE IsActive = 1
            ORDER BY ServiceName
        """).fetchall()
        return {
            "services": [
                {"serviceId": int(row["ServiceID"]), "serviceName": row["ServiceName"]}
                for row in rows
            ]
        }
