import base64
import binascii
import hashlib
import hmac
import json
import re

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/admin/accounts", tags=["Clinic Accounts"])


class DoctorCredentialsPayload(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    new_password: str | None = Field(default=None, max_length=1024)
    operator_password: str = Field(min_length=1, max_length=1024)


@router.put("/{doctor_id}/credentials")
def change_doctor_login(doctor_id: str, payload: DoctorCredentialsPayload, request: Request):
    from .app import connect, require_account, password_digest, set_password

    email = payload.email.strip().lower()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        raise HTTPException(422, "Enter a valid email address.")
    if payload.new_password is not None and len(payload.new_password) < 8:
        raise HTTPException(422, "New passwords must contain at least 8 characters.")

    with connect() as connection:
        admin = require_account(request, connection)
        if admin["role"] != "staff":
            raise HTTPException(403, "Staff access required.")

        operator = connection.execute(
            "SELECT password_salt, password_hash FROM dbo.accounts WHERE id = ?",
            (admin["id"],),
        ).fetchone()
        if operator is None or not hmac.compare_digest(
            password_digest(payload.operator_password, operator["password_salt"]),
            operator["password_hash"],
        ):
            raise HTTPException(403, "Your staff password is incorrect.")

        state_row = connection.execute(
            "SELECT data_json FROM dbo.admin_state WITH (UPDLOCK, HOLDLOCK) WHERE id = 1"
        ).fetchone()
        if not state_row:
            raise HTTPException(503, "Admin account directory is unavailable.")

        state = json.loads(state_row["data_json"])
        doctor = next(
            (entry for entry in state.get("doctors", []) if str(entry.get("id")) == doctor_id),
            None,
        )
        if doctor is None:
            raise HTTPException(404, "Doctor account not found.")

        account = connection.execute(
            "SELECT email, role FROM dbo.accounts WITH (UPDLOCK) WHERE id = ?",
            (doctor_id,),
        ).fetchone()
        if account is None or account["role"] != "doctor":
            raise HTTPException(404, "Doctor login does not exist.")

        duplicate = connection.execute(
            "SELECT id FROM dbo.accounts WHERE email = ? AND id <> ?",
            (email, doctor_id),
        ).fetchone()
        if duplicate:
            raise HTTPException(409, "This email is already assigned to another clinic account.")

        doctor["email"] = email
        connection.execute(
            "UPDATE dbo.accounts SET email = ? WHERE id = ? AND role = 'doctor'",
            (email, doctor_id),
        )
        connection.execute(
            "UPDATE dbo.Doctors SET Email = ? WHERE DoctorCode = ?",
            (email, doctor_id),
        )
        if payload.new_password is not None:
            set_password(connection, doctor_id, payload.new_password)
            connection.execute("DELETE FROM dbo.sessions WHERE account_id = ?", (doctor_id,))

        connection.execute(
            "UPDATE dbo.admin_state SET data_json = ?, updated_at = SYSDATETIMEOFFSET() WHERE id = 1",
            (json.dumps(state, ensure_ascii=False, separators=(",", ":")),),
        )
        return {
            "message": "Doctor login updated.",
            "doctorId": doctor_id,
            "email": email,
            "passwordChanged": payload.new_password is not None,
        }


class DoctorPicturePayload(BaseModel):
    # A resized JPEG thumbnail sent by the admin page; no filesystem storage.
    photo: str = Field(default="", max_length=350000)


@router.put("/{doctor_id}/picture")
def change_doctor_picture(doctor_id: str, payload: DoctorPicturePayload, request: Request):
    from .app import connect, require_account

    photo = payload.photo
    if photo:
        prefix = "data:image/jpeg;base64,"
        if not photo.startswith(prefix) or len(photo) >= 350000:
            raise HTTPException(422, "Choose a smaller JPG, PNG, or WEBP image.")
        try:
            content = base64.b64decode(photo[len(prefix):], validate=True)
        except (binascii.Error, ValueError):
            raise HTTPException(422, "Invalid photo data.")
        if (not 500 <= len(content) <= 250000 or
                not content.startswith(b"\xff\xd8\xff") or
                not content.endswith(b"\xff\xd9")):
            raise HTTPException(422, "Invalid or oversized JPEG image.")

    with connect() as connection:
        operator = require_account(request, connection)
        if operator["role"] != "staff":
            raise HTTPException(403, "Staff access required.")
        account = connection.execute(
            "SELECT role FROM dbo.accounts WHERE id = ?", (doctor_id,)
        ).fetchone()
        if not account or account["role"] != "doctor":
            raise HTTPException(404, "Doctor login does not exist.")
        row = connection.execute(
            "SELECT data_json FROM dbo.admin_state WITH (UPDLOCK, HOLDLOCK) WHERE id = 1"
        ).fetchone()
        if not row:
            raise HTTPException(503, "Clinic account directory is unavailable.")
        state = json.loads(row["data_json"])
        doctor = next((item for item in state.get("doctors", [])
                       if str(item.get("id")) == doctor_id), None)
        if doctor is None:
            raise HTTPException(404, "Doctor not found.")
        doctor["profilePicture"] = photo
        connection.execute(
            "UPDATE dbo.admin_state SET data_json = ?, updated_at = SYSDATETIMEOFFSET() WHERE id = 1",
            (json.dumps(state, ensure_ascii=False, separators=(",", ":")),)
        )
        return {"message": "Doctor picture saved.", "doctorId": doctor_id,
                "hasPicture": bool(photo)}


@router.delete("/{account_id}")
def delete_clinic_account(account_id: str, request: Request):
    """Remove an account login and directory entry without deleting medical history.

    Doctors are retired (IsActive=0) in the clinic directory. Their appointment,
    clinical-note and scheduling rows remain intact for auditing. A doctor with
    outstanding bookings cannot be retired until those visits are reassigned.
    """
    from .app import connect, require_account

    with connect() as connection:
        operator = require_account(request, connection)
        if operator["role"] != "staff":
            raise HTTPException(403, "Staff access required.")
        if operator["id"] == account_id:
            raise HTTPException(403, "You cannot delete your own account.")

        row = connection.execute(
            "SELECT data_json FROM dbo.admin_state WITH (UPDLOCK, HOLDLOCK) WHERE id = 1"
        ).fetchone()
        if row is None:
            raise HTTPException(503, "Clinic account directory is unavailable.")
        state = json.loads(row["data_json"])
        target = None
        role = None
        key = None
        for candidate_role, candidate_key in (("doctor", "doctors"), ("staff", "staff")):
            for item in state.get(candidate_key, []):
                if str(item.get("id")) == account_id:
                    target, role, key = item, candidate_role, candidate_key
                    break
            if target is not None:
                break
        if target is None:
            raise HTTPException(404, "Clinic account not found.")

        # The original Front Desk Staff login must always be retained.
        if role == "staff" and (
            str(target.get("staffId", "")).casefold() == "staff001"
            or str(target.get("id", "")).casefold() == "staff-frontdesk"
            or str(target.get("name", "")).strip().casefold() == "front desk staff"
        ):
            raise HTTPException(403, "Front Desk Staff cannot be deleted.")

        active_account = connection.execute(
            "SELECT role FROM dbo.accounts WITH (UPDLOCK) WHERE id = ?", (account_id,)
        ).fetchone()
        if active_account is None or active_account["role"] != role:
            raise HTTPException(409, "Clinic login and account directory do not match. Refresh and retry.")

        if role == "doctor":
            doctor = connection.execute(
                "SELECT DoctorID FROM dbo.Doctors WITH (UPDLOCK) WHERE DoctorCode = ?",
                (account_id,),
            ).fetchone()
            if doctor is not None:
                open_bookings = connection.execute("""
                    SELECT COUNT(*) AS Total
                    FROM dbo.Appointments
                    WHERE DoctorID = ?
                      AND AppointmentDate >= CONVERT(date, SYSDATETIME())
                      AND (Status IS NULL OR Status NOT IN
                           ('Completed','Cancelled','Rejected','No Show'))
                """, (doctor["DoctorID"],)).fetchone()["Total"]
                if open_bookings:
                    raise HTTPException(
                        409,
                        f"This doctor still has {open_bookings} active upcoming appointment(s). "
                        "Reassign or cancel them before deleting the doctor."
                    )
                connection.execute(
                    "UPDATE dbo.Doctors SET IsActive = 0 WHERE DoctorID = ?",
                    (doctor["DoctorID"],),
                )

        state[key] = [item for item in state[key] if str(item.get("id")) != account_id]
        # Reserve sequential IDs after deletion so doctor004 won't be recycled.
        prior = state.get("retiredAccountIds", [])
        if not isinstance(prior, list):
            prior = []
        signin = str(target.get("staffId", "")).strip()
        if signin and signin.casefold() not in {str(item).casefold() for item in prior}:
            prior.append(signin)
        state["retiredAccountIds"] = prior

        # Terminate the deleted person's sessions; never delete historical bookings.
        connection.execute("DELETE FROM dbo.sessions WHERE account_id = ?", (account_id,))
        connection.execute("DELETE FROM dbo.accounts WHERE id = ?", (account_id,))
        connection.execute(
            "UPDATE dbo.admin_state SET data_json = ?, updated_at = SYSDATETIMEOFFSET() WHERE id = 1",
            (json.dumps(state, ensure_ascii=False, separators=(",", ":")),),
        )
        return {"message": "Clinic account deleted.", "role": role,
                "accountId": account_id, "name": target.get("name", "")}
