import secrets
from decimal import Decimal

import pyodbc
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from inventory_store import all_products, require_inventory

router = APIRouter(prefix="/api/admin", tags=["Product Inventory"])


class ProductPayload(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    category: str = Field(default="Herbal ingredients", max_length=100)
    description: str = Field(default="", max_length=10000)
    ingredients: str = Field(default="", max_length=10000)
    instructions: str = Field(default="", max_length=10000)
    precautions: str = Field(default="", max_length=10000)
    price: Decimal = Field(ge=0, le=9999999999, decimal_places=2)
    stock: int = Field(ge=0, le=100000000)
    lowStockThreshold: int = Field(default=5, ge=0, le=100000000)
    image: str = Field(default="", max_length=2000000)
    status: str = Field(default="Active", pattern="^(Active|Inactive)$")
    expectedStock: int | None = Field(default=None, ge=0)


class StockPayload(BaseModel):
    change: int = Field(ge=-100000000, le=100000000)


class StatusPayload(BaseModel):
    status: str = Field(pattern="^(Active|Inactive)$")


def db_for_staff(request):
    from .app import connect, require_account
    return connect, require_account


def check_staff(request, connection):
    from .app import require_account
    account = require_account(request, connection)
    if account["role"] != "staff":
        raise HTTPException(403, "Staff access required.")


def check_name(cursor, name, exclude_id=None):
    if exclude_id:
        cursor.execute("""
            SELECT ProductID FROM dbo.TCMInventoryProducts
            WHERE ProductName = ? AND ProductID <> ?
        """, name, exclude_id)
    else:
        cursor.execute("""
            SELECT ProductID FROM dbo.TCMInventoryProducts
            WHERE ProductName = ?
        """, name)
    if cursor.fetchone():
        raise HTTPException(409, "A product with this name already exists.")


def clean(data):
    values = data.model_dump()
    values["name"] = values["name"].strip()
    values["category"] = values["category"].strip() or "Herbal ingredients"
    for key in ("description", "ingredients", "instructions", "precautions"):
        values[key] = values[key].strip()
    if not values["name"]:
        raise HTTPException(422, "Product name is required.")
    return values


@router.get("/products")
def list_products(request: Request):
    from .app import connect
    with connect() as db:
        check_staff(request, db)
        return {"products": all_products(db.connection)}


@router.post("/products", status_code=201)
def add_product(payload: ProductPayload, request: Request):
    from .app import connect
    values = clean(payload)
    with connect() as db:
        check_staff(request, db)
        require_inventory(db.connection)
        cursor = db.connection.cursor()
        check_name(cursor, values["name"])
        product_id = "PROD-" + secrets.token_hex(10).upper()
        try:
            cursor.execute("""
                INSERT INTO dbo.TCMInventoryProducts (
                    ProductID, ProductName, Category, Description, Ingredients,
                    Instructions, Precautions, Price, Stock, LowStockThreshold,
                    ImageData, Status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, product_id, values["name"], values["category"],
                values["description"], values["ingredients"],
                values["instructions"], values["precautions"],
                values["price"], values["stock"], values["lowStockThreshold"],
                values["image"], values["status"])
        except pyodbc.IntegrityError:
            raise HTTPException(409, "Product ID or name already exists.")
        return {"productId": product_id}


@router.put("/products/{product_id}")
def edit_product(product_id: str, payload: ProductPayload, request: Request):
    from .app import connect
    values = clean(payload)
    with connect() as db:
        check_staff(request, db)
        require_inventory(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT Stock FROM dbo.TCMInventoryProducts WITH (UPDLOCK, HOLDLOCK)
            WHERE ProductID = ?
        """, product_id)
        row = cursor.fetchone()
        if row is None:
            raise HTTPException(404, "Product not found.")
        if payload.expectedStock is not None and int(row.Stock) != payload.expectedStock:
            raise HTTPException(409, "Stock changed while editing. Reload the product and try again.")
        check_name(cursor, values["name"], product_id)
        cursor.execute("""
            UPDATE dbo.TCMInventoryProducts
            SET ProductName = ?, Category = ?, Description = ?, Ingredients = ?,
                Instructions = ?, Precautions = ?, Price = ?, Stock = ?,
                LowStockThreshold = ?, ImageData = ?, Status = ?,
                UpdatedAt = SYSDATETIME()
            WHERE ProductID = ?
        """, values["name"], values["category"], values["description"],
            values["ingredients"], values["instructions"],
            values["precautions"], values["price"], values["stock"],
            values["lowStockThreshold"], values["image"],
            values["status"], product_id)
        return {"message": "Product updated."}


@router.post("/products/{product_id}/stock")
def update_stock(product_id: str, payload: StockPayload, request: Request):
    from .app import connect
    if payload.change == 0:
        raise HTTPException(422, "Stock adjustment cannot be zero.")
    with connect() as db:
        check_staff(request, db)
        require_inventory(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            UPDATE dbo.TCMInventoryProducts
            SET Stock = Stock + ?, UpdatedAt = SYSDATETIME()
            WHERE ProductID = ? AND Stock + ? >= 0
                AND Stock + ? <= 100000000
        """, payload.change, product_id, payload.change, payload.change)
        if cursor.rowcount != 1:
            raise HTTPException(409, "Product not found or stock adjustment is invalid.")
        cursor.execute("SELECT Stock FROM dbo.TCMInventoryProducts WHERE ProductID = ?", product_id)
        return {"stock": int(cursor.fetchone()[0])}


@router.post("/products/{product_id}/status")
def set_product_status(product_id: str, payload: StatusPayload, request: Request):
    from .app import connect
    with connect() as db:
        check_staff(request, db)
        require_inventory(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            UPDATE dbo.TCMInventoryProducts
            SET Status = ?, UpdatedAt = SYSDATETIME()
            WHERE ProductID = ?
        """, payload.status, product_id)
        if cursor.rowcount != 1:
            raise HTTPException(404, "Product not found.")
        return {"status": payload.status}


@router.delete("/products/{product_id}")
def delete_product(product_id: str, request: Request):
    from .app import connect
    with connect() as db:
        check_staff(request, db)
        require_inventory(db.connection)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT TOP 1 1
            FROM dbo.TCMCheckoutItems i
            JOIN dbo.TCMCheckoutOrders o ON o.OrderID = i.OrderID
            JOIN dbo.TCMInventoryProducts p ON p.ProductID = ?
            WHERE o.Status IN (N'Pending Packing', N'Packed', N'Shipped')
              AND o.InventoryDeducted = 1
              AND o.InventoryRestoredAt IS NULL
              AND (i.InventoryProductID = p.ProductID
                   OR (i.InventoryProductID IS NULL AND i.ProductName COLLATE Latin1_General_100_CI_AS = p.ProductName))
        """, product_id)
        if cursor.fetchone():
            raise HTTPException(409, "This product belongs to an open order. Deactivate it instead of deleting it.")
        cursor.execute("DELETE FROM dbo.TCMInventoryProducts WHERE ProductID = ?", product_id)
        if cursor.rowcount != 1:
            raise HTTPException(404, "Product not found.")
        return {"deleted": True}
