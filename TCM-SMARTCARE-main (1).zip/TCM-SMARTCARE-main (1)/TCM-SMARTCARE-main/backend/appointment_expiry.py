def expire_overdue_appointments(connection):
    connection.execute('''
        UPDATE dbo.Appointments
        SET Status = 'Cancelled'
        WHERE Status IN ('Scheduled', 'Rescheduled')
          AND (
              AppointmentDate < CONVERT(date, SYSDATETIME())
              OR (
                  AppointmentDate = CONVERT(date, SYSDATETIME())
                  AND COALESCE(EndTime, CONVERT(time(0), DATEADD(minute, 30, CAST(StartTime AS datetime)))) <= CONVERT(time, SYSDATETIME())
              )
          )
    ''')
