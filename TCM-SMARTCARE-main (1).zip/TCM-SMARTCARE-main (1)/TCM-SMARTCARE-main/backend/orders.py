from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from order_store import load_orders

router = APIRouter(prefix="/api/admin", tags=["Orders"])


class StatusPayload(BaseModel):
    status: str = Field(pattern=r"^(Packed|Shipped|Completed|Cancelled)$")
    courier: str = Field(default="", max_length=100)


def authorize(request, connection):
    from .app import require_account
    account = require_account(request, connection)
    if account["role"] != "staff":
        raise HTTPException(403, "Staff access required.")


@router.get("/orders")
def all_orders(request: Request):
    from .app import connect
    with connect() as db:
        authorize(request, db)
        return {"orders": load_orders(db.connection)}


def restore_order_stock(cursor, order_id):
    cursor.execute("""
        SELECT ProductName, Quantity, InventoryProductID
        FROM dbo.TCMCheckoutItems WITH (HOLDLOCK)
        WHERE OrderID = ?
        ORDER BY ProductName
    """, order_id)
    items = cursor.fetchall()
    if not items:
        raise HTTPException(409, "Cannot restore stock: order has no items.")

    for item in items:
        if item.InventoryProductID:
            cursor.execute("""
                SELECT ProductID FROM dbo.TCMInventoryProducts WITH (UPDLOCK, HOLDLOCK)
                WHERE ProductID = ?
            """, item.InventoryProductID)
        else:
            cursor.execute("""
                SELECT ProductID FROM dbo.TCMInventoryProducts WITH (UPDLOCK, HOLDLOCK)
                WHERE ProductName = ?
            """, item.ProductName)
        product = cursor.fetchone()
        if product is None:
            raise HTTPException(409, f"Cannot restore {item.ProductName}: product missing. Contact staff.")

        cursor.execute("""
            UPDATE dbo.TCMInventoryProducts
            SET Stock = Stock + ?, UpdatedAt = SYSDATETIME()
            WHERE ProductID = ? AND Stock <= 100000000 - ?
        """, int(item.Quantity), product.ProductID, int(item.Quantity))
        if cursor.rowcount != 1:
            raise HTTPException(409, f"Cannot restore stock for {item.ProductName}.")


@router.put("/orders/{order_id}/status")
def change_status(order_id: int, payload: StatusPayload, request: Request):
    from .app import connect
    with connect() as db:
        authorize(request, db)
        cursor = db.connection.cursor()
        cursor.execute("""
            SELECT Status, FulfillmentMethod, InventoryDeducted, InventoryRestoredAt
            FROM dbo.TCMCheckoutOrders WITH (UPDLOCK, HOLDLOCK)
            WHERE OrderID = ?
        """, order_id)
        row = cursor.fetchone()
        if row is None:
            raise HTTPException(404, "Order not found.")
        previous, method, inventory_deducted, inventory_restored_at = row
        if previous in ("Completed", "Cancelled"):
            raise HTTPException(409, "This order is already finalized.")
        if previous == payload.status:
            raise HTTPException(409, "Status has not changed.")

        if payload.status == "Cancelled":
            if previous not in ("Pending Packing", "Packed"):
                raise HTTPException(409, "Only unshipped, uncompleted orders can be cancelled.")
            if inventory_deducted and inventory_restored_at is None:
                restore_order_stock(cursor, order_id)
            cursor.execute("""
                UPDATE dbo.TCMCheckoutOrders
                SET Status = N'Cancelled', PaymentStatus = N'Voided',
                    InventoryRestoredAt = CASE
                        WHEN InventoryDeducted = 1 AND InventoryRestoredAt IS NULL
                        THEN SYSDATETIME() ELSE InventoryRestoredAt END
                WHERE OrderID = ? AND Status IN (N'Pending Packing', N'Packed')
            """, order_id)
            if cursor.rowcount != 1:
                raise HTTPException(409, "Order status changed. Please reload.")
            message = "Your order was cancelled. Please order again."
        else:
            if payload.status == "Shipped" and method == "pickup":
                raise HTTPException(422, "Pickup orders cannot be shipped.")
            rank = {"Pending Packing": 0, "Packed": 1, "Shipped": 2, "Completed": 3}
            if payload.status != "Completed" and rank.get(payload.status, 0) <= rank.get(previous, 0):
                raise HTTPException(409, "Cannot move order status backward.")
            messages = {
                "Packed": "Your order has been packed.",
                "Shipped": "Your delivery is on the way.",
                "Completed": "Order Completed! Your products have been received."
            }
            message = messages[payload.status]
            cursor.execute("""
                UPDATE dbo.TCMCheckoutOrders
                SET Status = ?, Courier = ?,
                    CompletedAt = CASE WHEN ? = N'Completed' THEN SYSDATETIME() ELSE CompletedAt END
                WHERE OrderID = ?
            """, payload.status, payload.courier.strip() or None,
                payload.status, order_id)

        cursor.execute("""
            INSERT INTO dbo.TCMCheckoutEvents (OrderID, Status, Message)
            VALUES (?, ?, ?)
        """, order_id, payload.status, message)
        cursor.execute("SELECT PatientID, FulfillmentMethod FROM dbo.TCMCheckoutOrders WHERE OrderID=?", order_id)
        destination = cursor.fetchone()
        from tcm_notifications import record
        status_message = message
        if payload.status == 'Packed':
            status_message += ' Pending pickup.' if destination.FulfillmentMethod == 'pickup' else ' Pending shipping.'
        record(db.connection, 'patient', destination.PatientID, 'order',
               f'Order #{order_id} · {payload.status}', status_message,
               '/User/history.html', f'order:{order_id}:{payload.status}')
        return {"status": payload.status, "message": message}
