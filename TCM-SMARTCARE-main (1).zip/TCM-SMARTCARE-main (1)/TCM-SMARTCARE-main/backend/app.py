import hashlib
import hmac
import json
import os
import re
import secrets
from contextlib import contextmanager
from datetime import datetime, date, time, timedelta, timezone
from pathlib import Path
from typing import Any

import pyodbc

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from clinical_records import ensure_schema, wellness_by_patient, plans_by_appointment


ROOT = Path(__file__).resolve().parent.parent

SQLSERVER_NAME = os.environ.get(
    "TCM_SQLSERVER_SERVER",
    r"(localdb)\MSSQLLocalDB"
)

DATABASE_NAME = os.environ.get(
    "TCM_SQLSERVER_DATABASE",
    "TCM_SmartCare"
)

SESSION_COOKIE = "tcm_admin_session"
SESSION_HOURS = 8
PASSWORD_ITERATIONS = 310_000

app = FastAPI(title="TCM SmartCare Admin API")


class QueryResult:
    def __init__(self, cursor: pyodbc.Cursor):
        self.cursor = cursor

    def _row_as_dict(self, row: pyodbc.Row | None) -> dict[str, Any] | None:
        if row is None:
            return None
        columns = [column[0] for column in self.cursor.description or []]
        return dict(zip(columns, row))

    def fetchone(self) -> dict[str, Any] | None:
        return self._row_as_dict(self.cursor.fetchone())

    def fetchall(self) -> list[dict[str, Any]]:
        return [self._row_as_dict(row) for row in self.cursor.fetchall() if row is not None]

    @property
    def rowcount(self) -> int:
        return self.cursor.rowcount


class DatabaseConnection:
    def __init__(self, connection: pyodbc.Connection):
        self.connection = connection

    def execute(self, sql: str, parameters: tuple[Any, ...] = ()) -> QueryResult:
        cursor = self.connection.cursor()
        cursor.execute(sql, parameters)
        return QueryResult(cursor)


def connection_string(database: str) -> str:
    drivers = pyodbc.drivers()
    driver = next(
        (name for name in ("ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server", "SQL Server") if name in drivers),
        None,
    )
    if not driver:
        raise RuntimeError("Install Microsoft ODBC Driver 17 or 18 for SQL Server.")
    return (
        f"DRIVER={{{driver}}};SERVER={SQLSERVER_NAME};DATABASE={database};"
        "Trusted_Connection=yes;Encrypt=no;Connection Timeout=10;"
    )


@contextmanager
def connect(database: str = DATABASE_NAME, autocommit: bool = False):
    connection = pyodbc.connect(connection_string(database), autocommit=autocommit)
    try:
        yield DatabaseConnection(connection)
        if not autocommit:
            connection.commit()
    except Exception:
        if not autocommit:
            connection.rollback()
        raise
    finally:
        connection.close()


class DataPayload(BaseModel):
    data: dict[str, Any]


class LoginPayload(BaseModel):
    identifier: str = Field(min_length=1, max_length=254)
    password: str = Field(min_length=1, max_length=1024)


class PasswordPayload(BaseModel):
    current_password: str = Field(min_length=1, max_length=1024)
    new_password: str = Field(min_length=8, max_length=1024)


class OwnProfilePayload(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    email: str = Field(min_length=3, max_length=254)
    profilePicture: str | None = None


def initialize_database() -> None:
    if not re.fullmatch(r"[A-Za-z0-9_]+", DATABASE_NAME):
        raise RuntimeError("TCM_SQLSERVER_DATABASE may contain only letters, numbers, and underscores.")
    with connect("master", autocommit=True) as connection:
        exists = connection.execute(
            "SELECT 1 FROM sys.databases WHERE name = ?", (DATABASE_NAME,)
        ).fetchone()
        if not exists:
            connection.execute(f"CREATE DATABASE [{DATABASE_NAME}]")

    with connect() as connection:
        connection.execute(
            """
            IF OBJECT_ID(N'dbo.admin_state', N'U') IS NULL
            BEGIN
                CREATE TABLE dbo.admin_state (
                    id INT NOT NULL PRIMARY KEY CHECK (id = 1),
                    data_json NVARCHAR(MAX) NOT NULL,
                    updated_at DATETIMEOFFSET(7) NOT NULL
                );
            END;
            IF OBJECT_ID(N'dbo.accounts', N'U') IS NULL
            BEGIN
                CREATE TABLE dbo.accounts (
                    id NVARCHAR(128) NOT NULL PRIMARY KEY,
                    role NVARCHAR(16) NOT NULL,
                    staff_id NVARCHAR(128) COLLATE Latin1_General_100_CI_AS NOT NULL UNIQUE,
                    email NVARCHAR(254) COLLATE Latin1_General_100_CI_AS NOT NULL UNIQUE,
                    password_salt VARBINARY(32) NOT NULL,
                    password_hash VARBINARY(64) NOT NULL
                );
            END;
            IF OBJECT_ID(N'dbo.sessions', N'U') IS NULL
            BEGIN
                CREATE TABLE dbo.sessions (
                    token_hash CHAR(64) NOT NULL PRIMARY KEY,
                    account_id NVARCHAR(128) NOT NULL,
                    expires_at DATETIMEOFFSET(7) NOT NULL,
                    CONSTRAINT FK_sessions_accounts FOREIGN KEY (account_id)
                        REFERENCES dbo.accounts(id) ON DELETE CASCADE
                );
            END;
            """
        )


def password_digest(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS
    )


def set_password(connection: DatabaseConnection, account_id: str, password: str) -> None:
    if len(password) < 8:
        raise HTTPException(status_code=422, detail="Account passwords must be at least 8 characters.")
    salt = secrets.token_bytes(16)
    connection.execute(
        "UPDATE accounts SET password_salt = ?, password_hash = ? WHERE id = ?",
        (salt, password_digest(password, salt), account_id),
    )


def public_state(data: dict[str, Any]) -> dict[str, Any]:
    safe_data = json.loads(json.dumps(data))
    for key in ("staff", "doctors"):
        safe_data[key] = [
            {field: value for field, value in account.items() if field != "password"}
            for account in safe_data.get(key, [])
        ]
    return safe_data


def validate_state(data: dict[str, Any]) -> None:
    for key in (
        "staff", "doctors", "patients", "appointments", "schedules", "products",
        "orders", "messages", "carePlans", "feedback", "announcements",
    ):
        if key in data and not isinstance(data[key], list):
            raise HTTPException(status_code=422, detail=f"{key} must be a list.")
    if not isinstance(data.get("staff", []), list) or not isinstance(data.get("doctors", []), list):
        raise HTTPException(status_code=422, detail="Account lists are invalid.")

    seen_ids: set[str] = set()
    seen_emails: set[str] = set()
    seen_staff_ids: set[str] = set()
    for role, key in (("staff", "staff"), ("doctor", "doctors")):
        for account in data.get(key, []):
            if not isinstance(account, dict):
                raise HTTPException(status_code=422, detail="Account records must be objects.")
            account_id = str(account.get("id", "")).strip()
            staff_id = str(account.get("staffId", "")).strip()
            email = str(account.get("email", "")).strip().lower()
            if not account_id or not staff_id or not email or account.get("role") != role:
                raise HTTPException(status_code=422, detail="Account records require an ID, sign-in ID, email, and role.")
            if account_id in seen_ids or email in seen_emails or staff_id.lower() in seen_staff_ids:
                raise HTTPException(status_code=409, detail="Account IDs, sign-in IDs, and emails must be unique.")
            seen_ids.add(account_id)
            seen_emails.add(email)
            seen_staff_ids.add(staff_id.lower())


def save_state(connection: DatabaseConnection, data: dict[str, Any], allow_email_change_for: str | None = None) -> dict[str, Any]:
    validate_state(data)
    for role, key in (("staff", "staff"), ("doctor", "doctors")):
        for account in data.get(key, []):
            existing = connection.execute(
                "SELECT id, email FROM accounts WHERE id = ?", (account["id"],)
            ).fetchone()
            if existing and account["id"] != allow_email_change_for:
                account["email"] = existing["email"]
            password = account.get("password")
            if not existing and not password:
                raise HTTPException(status_code=422, detail="New accounts require a temporary password.")

            if existing:
                connection.execute(
                    "UPDATE accounts SET role = ?, staff_id = ?, email = ? WHERE id = ?",
                    (role, account["staffId"], account["email"], account["id"]),
                )
            else:
                salt = secrets.token_bytes(16)
                connection.execute(
                    """
                    INSERT INTO accounts
                        (id, role, staff_id, email, password_salt, password_hash)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        account["id"], role, account["staffId"], account["email"],
                        salt, password_digest(str(password), salt),
                    ),
                )
            if existing and password:
                set_password(connection, account["id"], str(password))

    from .doctor_directory import sync_doctor_accounts
    previous_state = connection.execute(
        "SELECT data_json FROM dbo.admin_state WHERE id = 1"
    ).fetchone()
    previous_doctors = (
        json.loads(previous_state["data_json"]).get("doctors", [])
        if previous_state else []
    )
    sync_doctor_accounts(connection, previous_doctors, data.get("doctors", []))

    safe_data = public_state(data)
    from inventory_store import all_products, available
    if available(connection.connection):
        safe_data["products"] = all_products(connection.connection)
    serialized_data = json.dumps(safe_data, separators=(",", ":"))
    updated_at = datetime.now(timezone.utc)
    updated = connection.execute(
        "UPDATE admin_state SET data_json = ?, updated_at = ? WHERE id = 1",
        (serialized_data, updated_at),
    )
    if updated.rowcount == 0:
        connection.execute(
            "INSERT INTO admin_state (id, data_json, updated_at) VALUES (1, ?, ?)",
            (serialized_data, updated_at),
        )
    return safe_data


def find_session(request: Request, connection: DatabaseConnection) -> dict[str, Any] | None:
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        return None
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    return connection.execute(
        """
        SELECT accounts.id, accounts.role, accounts.staff_id, accounts.email
        FROM sessions JOIN accounts ON accounts.id = sessions.account_id
        WHERE sessions.token_hash = ? AND sessions.expires_at > ?
        """,
        (token_hash, datetime.now(timezone.utc)),
    ).fetchone()


def require_account(request: Request, connection: DatabaseConnection) -> dict[str, Any]:
    account = find_session(request, connection)
    if not account:
        raise HTTPException(status_code=401, detail="Please sign in to continue.")
    return account


def account_from_state(data: dict[str, Any], account_id: str) -> dict[str, Any] | None:
    for key in ("staff", "doctors"):
        for account in data.get(key, []):
            if account.get("id") == account_id:
                return account
    return None


def new_session(connection: DatabaseConnection, account_id: str, response: Response) -> dict[str, str]:
    token = secrets.token_urlsafe(32)
    expires = datetime.now(timezone.utc) + timedelta(hours=SESSION_HOURS)
    connection.execute(
        "INSERT INTO sessions (token_hash, account_id, expires_at) VALUES (?, ?, ?)",
        (hashlib.sha256(token.encode("utf-8")).hexdigest(), account_id, expires),
    )
    response.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=SESSION_HOURS * 60 * 60,
        httponly=True,
        secure=os.environ.get("TCM_COOKIE_SECURE", "false").lower() == "true",
        samesite="strict",
        path="/api",
    )
    return {"message": "Signed in."}


def current_user(connection: DatabaseConnection, account: dict[str, Any]) -> dict[str, str]:
    state_row = connection.execute("SELECT data_json FROM admin_state WHERE id = 1").fetchone()
    if not state_row:
        raise HTTPException(status_code=503, detail="Admin database has not been initialized.")
    account_data = account_from_state(json.loads(state_row["data_json"]), account["id"])
    if not account_data:
        raise HTTPException(status_code=401, detail="Account is no longer available.")
    return {
        "id": account["id"],
        "name": str(account_data.get("name", "")),
        "role": account["role"],
        "avatar": str(account_data.get("avatar", "")),
    }




class ManageAppointmentReviewPayload(BaseModel):
    status: str = Field(pattern='^(Pending|Published|Hidden)$')
    adminReply: str = Field(default='', max_length=2000)
    featured: bool = False


def review_feature_column(connection):
    row = connection.execute("SELECT COL_LENGTH(N'dbo.TCMAppointmentReviews', 'IsFeatured') AS column_length").fetchone()
    return row['column_length'] is not None


@app.get('/api/admin/appointment-reviews')
def admin_appointment_reviews(request: Request):
    with connect() as connection:
        account = require_account(request, connection)
        if not connection.execute("SELECT OBJECT_ID(N'dbo.TCMAppointmentReviews', N'U') AS object_id").fetchone()['object_id']:
            raise HTTPException(503, 'TCMAppointmentReviews table is missing.')
        featured_column = review_feature_column(connection)
        featured_sql = 'r.IsFeatured' if featured_column else 'CAST(0 AS BIT)'
        rows = connection.execute(f'''
            SELECT r.ReviewID, r.AppointmentID, r.Rating, r.ReviewText,
                   r.ReviewStatus, r.AdminReply, r.CreatedAt,
                   {featured_sql} AS IsFeatured,
                   p.FullName AS PatientName, d.FullName AS DoctorName,
                   d.DoctorCode, s.ServiceName, a.AppointmentDate
            FROM dbo.TCMAppointmentReviews r
            JOIN dbo.Appointments a ON a.AppointmentID = r.AppointmentID
            JOIN dbo.Patients p ON p.PatientID = a.PatientID
            JOIN dbo.Doctors d ON d.DoctorID = a.DoctorID
            JOIN dbo.Services s ON s.ServiceID = a.ServiceID
            WHERE (? = 'staff' OR d.DoctorCode = ?)
            ORDER BY r.CreatedAt DESC, r.ReviewID DESC
        ''', (account['role'], account['id'])).fetchall()
        return {'featuredEnabled': featured_column, 'role': account['role'], 'reviews': [
            {'reviewId': row['ReviewID'], 'appointmentId': f"APT-SQL-{row['AppointmentID']}",
             'rating': row['Rating'], 'comment': row['ReviewText'] or '',
             'status': row['ReviewStatus'], 'adminReply': row['AdminReply'] or '',
             'featured': bool(row['IsFeatured']), 'patient': row['PatientName'],
             'doctor': row['DoctorName'], 'service': row['ServiceName'],
             'appointmentDate': str(row['AppointmentDate'])[:10],
             'createdAt': row['CreatedAt'].isoformat() if row['CreatedAt'] else ''}
            for row in rows]}


@app.patch('/api/admin/appointment-reviews/{review_id}')
def manage_appointment_review(review_id: int, payload: ManageAppointmentReviewPayload, request: Request):
    with connect() as connection:
        account = require_account(request, connection)
        if account['role'] != 'staff':
            raise HTTPException(403, 'Only staff can manage appointment feedback.')
        has_featured = review_feature_column(connection)
        if payload.featured and not has_featured:
            raise HTTPException(409, 'To feature reviews, first run SQL/OPTIONAL_add_featured_column.sql in SSMS.')
        if payload.featured and payload.status != 'Published':
            raise HTTPException(422, 'Only published reviews can be featured.')
        sql = '''UPDATE dbo.TCMAppointmentReviews
                 SET ReviewStatus=?, AdminReply=?, UpdatedAt=SYSUTCDATETIME()'''
        values = [payload.status, payload.adminReply.strip()]
        if has_featured:
            sql += ', IsFeatured=?'
            values.append(int(payload.featured))
        sql += ' OUTPUT INSERTED.ReviewID WHERE ReviewID=?'
        values.append(review_id)
        if not connection.execute(sql, tuple(values)).fetchone():
            raise HTTPException(404, 'Review not found.')
        return {'message': 'Review moderation saved.', 'reviewId': review_id}


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/admin/data")
def get_admin_data(request: Request) -> dict[str, Any]:
    with connect() as connection:
        account = require_account(request, connection)
        row = connection.execute("SELECT data_json FROM admin_state WHERE id = 1").fetchone()
        if not row:
            raise HTTPException(status_code=503, detail="Admin database has not been initialized.")
        from tcm_notifications import reconcile_announcements
        reconcile_announcements(connection.connection)
        row = connection.execute("SELECT data_json FROM admin_state WHERE id = 1").fetchone()
        state = json.loads(row["data_json"])
        # Replace legacy demo bookings/patients with real SQL Server data.
        from .booking_bridge import full_state
        state["patients"], state["appointments"] = full_state(connection, account)
        ensure_schema(connection.connection.cursor())
        patient_ids = [int(item["id"].removeprefix("PAT-SQL-")) for item in state["patients"]]
        wellness = wellness_by_patient(connection.connection.cursor(), patient_ids)
        for patient in state["patients"]:
            patient["preConsultation"] = wellness.get(int(patient["id"].removeprefix("PAT-SQL-")), {"submitted": False})
        appointment_ids = [int(item["id"].removeprefix("APT-SQL-")) for item in state["appointments"]]
        state["carePlans"] = plans_by_appointment(connection.connection.cursor(), appointment_ids)
        patient_for_booking = {a["id"]: a["patientId"] for a in state["appointments"]}
        for plan in state["carePlans"]:
            plan["patientId"] = patient_for_booking.get(plan["appointmentId"])
        from inventory_store import all_products, available
        if available(connection.connection):
            state["products"] = all_products(connection.connection)
        return {"data": state}


@app.post("/api/admin/initialize")
def initialize_admin_data(payload: DataPayload) -> dict[str, Any]:
    raise HTTPException(
        status_code=403,
        detail="Browser account initialization is disabled. Configure clinic accounts on the server."
    )


@app.put("/api/admin/data")
def put_admin_data(payload: DataPayload, request: Request) -> dict[str, Any]:
    with connect() as connection:
        account = require_account(request, connection)
        state_row = connection.execute("SELECT data_json FROM admin_state WHERE id = 1").fetchone()
        if not state_row:
            raise HTTPException(status_code=503, detail="Admin database has not been initialized.")
        current = json.loads(state_row["data_json"])
        incoming = payload.data
        if account["role"] != "staff":
            from .booking_bridge import full_state
            own_patients, own_appointments = full_state(connection, account)
            if (incoming.get("patients") != own_patients or
                    incoming.get("appointments") != own_appointments):
                raise HTTPException(403, "Patient records and bookings must be managed through clinic APIs.")
            own_appointment_ids = {item["id"] for item in own_appointments}
            incoming_plans = incoming.get("carePlans", [])
            if not isinstance(incoming_plans, list) or any(
                not isinstance(plan, dict) or plan.get("appointmentId") not in own_appointment_ids
                for plan in incoming_plans
            ):
                raise HTTPException(403, "You can only edit notes for your own appointments.")
            incoming = dict(incoming)
            incoming["patients"] = current.get("patients", [])
            incoming["appointments"] = current.get("appointments", [])
            # Product data can be overlaid from live SQL in GET; doctors cannot edit it.
            incoming["products"] = current.get("products", [])
            incoming["carePlans"] = [
                plan for plan in current.get("carePlans", [])
                if plan.get("appointmentId") not in own_appointment_ids
            ] + incoming_plans
            # Doctor profile updates may modify only their own display name,
            # email, initials and doctor-portal picture. The official clinic
            # profilePicture must remain exclusively controlled by staff.
            allowed = {"appointments", "carePlans", "messages", "doctors"}
            for key in set(current) | set(incoming):
                if key not in allowed and current.get(key) != incoming.get(key):
                    raise HTTPException(status_code=403, detail="Your account cannot change this admin data.")
            if incoming.get("staff") != current.get("staff"):
                raise HTTPException(status_code=403, detail="Your account cannot change staff accounts.")
            for key in ("staff", "doctors"):
                incoming_accounts = {item.get("id"): item for item in incoming.get(key, [])}
                current_accounts = {item.get("id"): item for item in current.get(key, [])}
                if incoming_accounts.keys() != current_accounts.keys():
                    raise HTTPException(status_code=403, detail="Your account cannot change clinic accounts.")
                for user_id, item in incoming_accounts.items():
                    original = current_accounts[user_id]
                    if user_id != account["id"]:
                        if item != original:
                            raise HTTPException(status_code=403, detail="Your account can only update your own profile.")
                        continue
                    editable_fields = {"email"}
                    if any(item.get(field) != original.get(field)
                           for field in set(item) | set(original) if field not in editable_fields):
                        raise HTTPException(status_code=403,
                                            detail="Only staff can change the clinic doctor photo or services.")
            if not account_from_state(incoming, account["id"]):
                raise HTTPException(status_code=403, detail="Your account is missing from the submitted data.")
            for key in ("staff", "doctors"):
                for item in incoming.get(key, []):
                    if "password" in item:
                        raise HTTPException(status_code=403, detail="Password changes must use the password endpoint.")

        if account["role"] == "staff":
            from tcm_notifications import remove_demo_announcement
            incoming = dict(incoming)
            incoming["announcements"] = remove_demo_announcement(incoming.get("announcements", []))
        data = save_state(connection, incoming, allow_email_change_for=account["id"])
        if account["role"] == "staff":
            from tcm_notifications import reconcile_announcements
            reconcile_announcements(connection.connection)
        return {"data": data}


@app.patch("/api/admin/profile")
def update_own_profile(payload: OwnProfilePayload, request: Request) -> dict[str, Any]:
    email = payload.email.strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise HTTPException(status_code=422, detail="Enter a valid email address.")
    with connect() as connection:
        session = require_account(request, connection)
        if session["role"] not in ("doctor", "staff"):
            raise HTTPException(status_code=403, detail="This account cannot edit a clinic profile.")
        row = connection.execute(
            "SELECT data_json FROM dbo.admin_state WITH (UPDLOCK, HOLDLOCK) WHERE id = 1"
        ).fetchone()
        if not row:
            raise HTTPException(status_code=503, detail="Clinic profile data is not available.")
        state = json.loads(row["data_json"])
        profile = account_from_state(state, session["id"])
        if not profile:
            raise HTTPException(status_code=404, detail="Your clinic account could not be found.")
        name = str(profile.get("name", ""))
        if payload.name is not None and payload.name.strip() != name:
            raise HTTPException(status_code=403, detail="Full name cannot be changed from your profile.")
        duplicate = connection.execute(
            "SELECT id FROM dbo.accounts WHERE email = ? AND id <> ?",
            (email, session["id"]),
        ).fetchone()
        if duplicate:
            raise HTTPException(status_code=409, detail="Another account already uses this email address.")
        if payload.profilePicture is not None:
            if session["role"] != "staff":
                raise HTTPException(status_code=403, detail="Doctor pictures are managed by clinic staff.")
            photo = payload.profilePicture
            if (len(photo) > 1500000 or (photo and not re.fullmatch(
                    r"data:image/jpeg;base64,[A-Za-z0-9+/=]+", photo))):
                raise HTTPException(status_code=422, detail="Invalid profile picture.")
            profile["profilePicture"] = photo
        profile["email"] = email
        connection.execute(
            "UPDATE dbo.accounts SET email = ? WHERE id = ?", (email, session["id"])
        )
        if session["role"] == "doctor":
            connection.execute(
                "UPDATE dbo.Doctors SET Email = ? WHERE DoctorCode = ?",
                (email, str(profile.get("id", ""))),
            )
        connection.execute(
            "UPDATE dbo.admin_state SET data_json = ?, updated_at = ? WHERE id = 1",
            (json.dumps(public_state(state), separators=(",", ":")), datetime.now(timezone.utc)),
        )
        return {"profile": {
            "id": session["id"], "role": session["role"],
            "name": name, "email": email, "avatar": profile.get("avatar", ""),
        }}


@app.post("/api/auth/login")
def login(payload: LoginPayload, response: Response) -> dict[str, Any]:
    with connect() as connection:
        value = payload.identifier.strip()
        account = connection.execute(
            """
            SELECT id, role, password_salt, password_hash FROM accounts
            WHERE email = ? OR staff_id = ?
            """,
            (value, value),
        ).fetchone()
        if not account or not hmac.compare_digest(
            password_digest(payload.password, account["password_salt"]),
            account["password_hash"],
        ):
            raise HTTPException(status_code=401, detail="Invalid ID/email or password.")
        user = current_user(connection, account)
        new_session(connection, account["id"], response)
        return {"user": user}


@app.get("/api/auth/me")
def me(request: Request) -> dict[str, Any]:
    with connect() as connection:
        account = require_account(request, connection)
        return {"user": current_user(connection, account)}


@app.post("/api/auth/logout")
def logout(request: Request, response: Response) -> dict[str, str]:
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        with connect() as connection:
            connection.execute(
                "DELETE FROM sessions WHERE token_hash = ?",
                (hashlib.sha256(token.encode("utf-8")).hexdigest(),),
            )
    response.delete_cookie(SESSION_COOKIE, path="/api", httponly=True, samesite="strict")
    return {"message": "Signed out."}


@app.put("/api/auth/password")
def change_password(payload: PasswordPayload, request: Request) -> dict[str, str]:
    with connect() as connection:
        account = require_account(request, connection)
        record = connection.execute(
            "SELECT password_salt, password_hash FROM accounts WHERE id = ?",
            (account["id"],),
        ).fetchone()
        if not hmac.compare_digest(
            password_digest(payload.current_password, record["password_salt"]),
            record["password_hash"],
        ):
            raise HTTPException(status_code=400, detail="Your current password is incorrect.")
        set_password(connection, account["id"], payload.new_password)
        return {"message": "Password updated."}


@app.get("/", include_in_schema=False)
def home() -> RedirectResponse:
    return RedirectResponse("/Admin/admin-login.html")


@app.get("/api/admin/doctor-schedules")
def get_doctor_schedules(request: Request):

    with connect() as connection:
        account = require_account(request, connection)

        if account["role"] != "staff":
            raise HTTPException(
                status_code=403,
                detail="Staff access required."
            )

        result = connection.execute("""
            SELECT
                d.DoctorID,
                d.DoctorCode,
                d.FullName,
                ds.ScheduleID,
                ds.DayOfWeek,
                ds.StartTime,
                ds.EndTime,
                ds.SlotDurationMinutes,
                ds.Capacity,
                ds.IsAvailable
            FROM dbo.DoctorSchedules ds
            INNER JOIN dbo.Doctors d
                ON ds.DoctorID = d.DoctorID
            ORDER BY d.FullName, ds.DayOfWeek
        """)

        schedules = []

        for row in result.fetchall():
            schedules.append({
                "doctorId": row["DoctorID"],
                "doctorCode": row["DoctorCode"],
                "doctorName": row["FullName"],
                "scheduleId": row["ScheduleID"],
                "dayOfWeek": row["DayOfWeek"],
                "startTime": str(row["StartTime"]),
                "endTime": str(row["EndTime"]),
                "slotDuration": row["SlotDurationMinutes"],
                "capacity": row["Capacity"],
                "isAvailable": bool(row["IsAvailable"])
            })

        return {
            "status": "success",
            "schedules": schedules
        }


class ScheduleUpdate(BaseModel):
    workingDays: list[int] = Field(min_length=1)
    morningStart: str
    morningEnd: str
    afternoonStart: str
    afternoonEnd: str
    slotDuration: int = Field(ge=15, le=120)
    capacity: int = Field(ge=1, le=100)


@app.put("/api/admin/doctors/{doctor_code}/schedule", status_code=410)
def update_doctor_schedule(doctor_code: str, payload: ScheduleUpdate, request: Request):
    with connect() as connection:
        account = require_account(request, connection)
        if account["role"] != "staff":
            raise HTTPException(403, "Staff access required.")
    raise HTTPException(
        410,
        "Use Doctor Schedule Management to edit weekly or individual-date shifts. The old endpoint cannot enforce cross-doctor conflicts."
    )


@app.get('/api/admin/notifications')
def admin_notifications(request: Request):
    from tcm_notifications import inbox
    with connect() as db:
        account = require_account(request, db)
        return inbox(db.connection, account['role'], account['id'])


@app.post('/api/admin/notifications/read-all')
def admin_notifications_read_all(request: Request):
    from tcm_notifications import mark_read
    with connect() as db:
        account = require_account(request, db)
        return mark_read(db.connection, account['role'], account['id'])


@app.post('/api/admin/notifications/{notification_id}/read')
def admin_notification_read(notification_id: int, request: Request):
    from tcm_notifications import mark_read
    with connect() as db:
        account = require_account(request, db)
        return mark_read(db.connection, account['role'], account['id'], notification_id)


app.mount("/Admin", StaticFiles(directory=ROOT / "Admin"), name="admin")
app.mount("/User", StaticFiles(directory=ROOT / "User"), name="user")

initialize_database()

from .orders import router as orders_router
app.include_router(orders_router)

from .inventory_api import router as inventory_router
app.include_router(inventory_router)

from .shop_reviews import router as shop_reviews_router
app.include_router(shop_reviews_router)

from .schedule_editor import router as schedule_editor_router
app.include_router(schedule_editor_router)

from .doctor_directory import router as doctor_directory_router
app.include_router(doctor_directory_router)

from .account_credentials import router as account_credentials_router
app.include_router(account_credentials_router)

# Clinic appointment / patient data bridge. Both servers read the same SQL tables.
from . import booking_bridge as clinic_booking

class ClinicStatusPayload(BaseModel):
    status: str = Field(min_length=1, max_length=32)

class ClinicReschedulePayload(BaseModel):
    date: str
    time: str
    doctorId: str

class ClinicNewAppointmentPayload(ClinicReschedulePayload):
    patientId: str
    service: str
    room: str = 'To be assigned'

@app.patch('/api/admin/clinic-appointments/{appointment_key}/status')
def clinic_appointment_status(appointment_key: str, payload: ClinicStatusPayload, request: Request):
    with connect() as connection:
        account = require_account(request, connection)
        number = clinic_booking.parse_key(appointment_key, 'APT-SQL-')
        if payload.status == 'Completed':
            booking = clinic_booking.check_access(connection, account, number)
            if booking['Status'] not in ('Checked In', 'In Consultation', 'Completed'):
                raise HTTPException(409, 'Check in the patient before completing this appointment.')
            if booking['Status'] != 'Completed':
                ensure_schema(connection.connection.cursor())
                plan = connection.execute('''SELECT PlanStatus, NotesJSON
                    FROM dbo.TCMClinicalCarePlans WHERE AppointmentID = ?''', (number,)).fetchone()
                if not plan or plan['PlanStatus'] not in ('Saved', 'Completed'):
                    raise HTTPException(409, 'The doctor must save the care plan before completing the appointment.')
                formula = json.loads(plan['NotesJSON']).get('formula') or ''
                if not isinstance(formula, str) or not formula.strip():
                    raise HTTPException(409, 'Fill in Medicine / Formula to Prepare before completing. If no medicine is needed, enter No medicine required.')
        outcome = clinic_booking.set_status(connection, account, number, payload.status)
        if payload.status == 'Completed' and booking['Status'] != 'Completed':
            from tcm_notifications import record
            record(connection.connection, 'patient', booking['PatientID'], 'appointment',
                   'Appointment completed',
                   'Your appointment is completed. You can view your appointment details and leave a review.',
                   '/User/appointments.html', f'appointment-completed:{number}')
        return outcome

@app.patch('/api/admin/clinic-appointments/{appointment_key}/reschedule')
def clinic_appointment_reschedule(appointment_key: str, payload: ClinicReschedulePayload, request: Request):
    if len(payload.date) != 10 or len(payload.time) != 5:
        raise HTTPException(422, 'Invalid date or time.')
    with connect() as connection:
        account = require_account(request, connection)
        if account['role'] != 'staff':
            raise HTTPException(403, 'Only clinic staff can reschedule appointments.')
        number = clinic_booking.parse_key(appointment_key, 'APT-SQL-')
        old = clinic_booking.check_access(connection, account, number)
        if old['Status'] in ('Cancelled', 'Completed', 'Rejected'):
            raise HTTPException(409, 'A closed appointment cannot be rescheduled.')
        target_date, start, end, doctor_id = clinic_booking.validate_slot(
            connection, payload.date, payload.time, payload.doctorId, exclude_appointment=number)
        result = connection.execute('''UPDATE dbo.Appointments
            SET AppointmentDate=?, StartTime=?, EndTime=?, DoctorID=?, Status='Rescheduled'
            OUTPUT INSERTED.AppointmentID WHERE AppointmentID=?''',
            (target_date, start, end, doctor_id, number)).fetchone()
        if not result: raise HTTPException(409, 'Appointment was changed.')
        return {'id': appointment_key, 'status': 'Rescheduled'}

class ClinicClinicalNotesPayload(BaseModel):
    status: str = Field(pattern='^(Draft|Saved|Completed)$')
    notes: str = Field(default='', max_length=6000)
    formula: str = Field(default='', max_length=4000)
    careInstructions: str = Field(default='', max_length=3000)
    daysSupply: str = Field(default='', max_length=100)
    followUpRecommendation: str = Field(default='', max_length=100)


class ClinicPreparationPayload(BaseModel):
    status: str = Field(pattern='^(Pending|Prepared|Dispensed)$')
    notes: str = Field(default='', max_length=2000)


@app.put('/api/admin/clinical-notes/{appointment_key}')
def clinic_save_notes(appointment_key: str, payload: ClinicClinicalNotesPayload, request: Request):
    with connect() as db:
        account = require_account(request, db)
        if account['role'] != 'doctor':
            raise HTTPException(403, 'Only the assigned doctor can write clinical notes.')
        from .booking_bridge import parse_key, check_access
        appointment_id = parse_key(appointment_key, 'APT-SQL-')
        booking = check_access(db, account, appointment_id)
        if booking['Status'] not in ('Checked In', 'In Consultation', 'Completed'):
            raise HTTPException(409, 'Patient must be checked in before doctor consultation notes can be saved.')
        if payload.status == 'Completed' and booking['Status'] == 'Completed':
            raise HTTPException(409, 'This appointment has already been completed.')
        if payload.status == 'Completed' and not payload.formula.strip():
            raise HTTPException(422, 'Fill in Medicine / Formula to Prepare before completing. If no medicine is needed, enter No medicine required.')
        ensure_schema(db.connection.cursor())
        notes_json = json.dumps({
            'notes': payload.notes.strip(), 'formula': payload.formula.strip(),
            'careInstructions': payload.careInstructions.strip(),
            'daysSupply': payload.daysSupply.strip(),
            'followUpRecommendation': payload.followUpRecommendation.strip()
        }, ensure_ascii=False)
        exists = db.execute('''SELECT AppointmentID, PreparationStatus
            FROM dbo.TCMClinicalCarePlans WITH (UPDLOCK, HOLDLOCK)
            WHERE AppointmentID=?''', (appointment_id,)).fetchone()
        if exists:
            if exists['PreparationStatus'] == 'Dispensed':
                raise HTTPException(409, 'Medicine was dispensed. Contact staff before changing the plan.')
            db.execute('''UPDATE dbo.TCMClinicalCarePlans SET PlanStatus=?, NotesJSON=?,
                UpdatedAt=SYSUTCDATETIME(), PreparationStatus='Pending',
                PreparationNotes='', PreparedBy=NULL, PreparedAt=NULL, DispensedAt=NULL
                WHERE AppointmentID=?''', (payload.status, notes_json, appointment_id))
        else:
            db.execute('''INSERT INTO dbo.TCMClinicalCarePlans
                (AppointmentID, DoctorCode, PlanStatus, NotesJSON)
                VALUES (?, ?, ?, ?)''', (appointment_id, account['id'], payload.status, notes_json))
        return {'message': 'Clinical notes saved.', 'appointmentId': appointment_key}


@app.put('/api/admin/medicine-preparation/{appointment_key}')
def clinic_save_preparation(appointment_key: str, payload: ClinicPreparationPayload, request: Request):
    with connect() as db:
        account = require_account(request, db)
        if account['role'] != 'staff':
            raise HTTPException(403, 'Only clinic staff can record preparation or handover.')
        from .booking_bridge import parse_key, check_access
        appointment_id = parse_key(appointment_key, 'APT-SQL-')
        booking = check_access(db, account, appointment_id)
        if booking['Status'] in ('Cancelled', 'Rejected'):
            raise HTTPException(409, 'Cannot prepare medicine for a cancelled booking.')
        ensure_schema(db.connection.cursor())
        plan = db.execute('''SELECT PlanStatus, NotesJSON, PreparationStatus FROM dbo.TCMClinicalCarePlans
            WITH (UPDLOCK, HOLDLOCK) WHERE AppointmentID=?''', (appointment_id,)).fetchone()
        if not plan or plan['PlanStatus'] == 'Draft':
            raise HTTPException(409, 'The doctor must save the clinical plan first.')
        prescribed_formula = (json.loads(plan['NotesJSON']).get('formula') or '').strip()
        if not prescribed_formula:
            raise HTTPException(409, 'There is no prescribed medicine/formula to prepare.')
        if (prescribed_formula.casefold() == 'no medicine required'
                and payload.status in ('Prepared', 'Dispensed')):
            raise HTTPException(409, 'The doctor specified no medicine is required. Nothing should be prepared or dispensed.')
        if payload.status in ('Prepared', 'Dispensed') and not payload.notes.strip():
            raise HTTPException(422, 'Record the patient, formulation and handover verification in staff notes.')
        previous = plan['PreparationStatus']
        if payload.status == 'Dispensed' and previous != 'Prepared':
            raise HTTPException(409, 'Record the medicine as Prepared before dispensing to the patient.')
        if previous == 'Dispensed' and payload.status != 'Dispensed':
            raise HTTPException(409, 'A dispensed record cannot be reset here.')
        db.execute('''UPDATE dbo.TCMClinicalCarePlans
            SET PreparationStatus=?, PreparationNotes=?, PreparedBy=?,
                PreparedAt=CASE WHEN ?='Prepared' THEN SYSUTCDATETIME() ELSE PreparedAt END,
                DispensedAt=CASE WHEN ?='Dispensed' THEN SYSUTCDATETIME() ELSE DispensedAt END
            WHERE AppointmentID=?''', (payload.status, payload.notes.strip(), account['id'],
                                      payload.status, payload.status, appointment_id))
        return {'message': 'Medicine preparation status saved.', 'status': payload.status}


@app.get('/api/admin/clinic-appointments/availability')
def clinic_create_availability(request: Request, date_value: str = "", service: str = ""):
    try:
        chosen_date = date.fromisoformat(date_value)
    except ValueError:
        raise HTTPException(422, "Choose a valid appointment date.")
    now = datetime.now(timezone(timedelta(hours=8)))
    if chosen_date < now.date() or chosen_date > now.date() + timedelta(days=60):
        raise HTTPException(422, "Choose a date within the next 60 days.")
    with connect() as connection:
        account = require_account(request, connection)
        if account['role'] not in ('staff', 'doctor'):
            raise HTTPException(403, 'Only staff and doctors can create appointments.')
        services = connection.execute('''SELECT ServiceName FROM dbo.Services
            WHERE IsActive=1 ORDER BY ServiceName''').fetchall()
        service_names = [row['ServiceName'] for row in services]
        if service and service not in service_names:
            raise HTTPException(422, 'Selected service is unavailable.')
        if chosen_date.isoweekday() == 7:
            return {'services': service_names, 'doctors': [], 'message': 'The clinic is closed on Sunday.'}
        params = []
        conditions = ['d.IsActive=1']
        if account['role'] == 'doctor':
            conditions.append('d.DoctorCode=?')
            params.append(account['id'])
        if service:
            conditions.append('EXISTS (SELECT 1 FROM dbo.DoctorServices ds JOIN dbo.Services s ON s.ServiceID=ds.ServiceID WHERE ds.DoctorID=d.DoctorID AND s.ServiceName=? AND s.IsActive=1)')
            params.append(service)
        rows = connection.execute('''SELECT d.DoctorID, d.DoctorCode, d.FullName
            FROM dbo.Doctors d WHERE ''' + ' AND '.join(conditions) + ' ORDER BY d.FullName', tuple(params)).fetchall()
        doctors = []
        for doctor in rows:
            did = doctor['DoctorID']
            overrides = connection.execute('''SELECT StartTime, EndTime, IsClosed
                FROM dbo.TCMDoctorDateOverrides WHERE DoctorID=? AND ScheduleDate=?''',
                (did, chosen_date)).fetchall()
            if overrides:
                windows = [row for row in overrides if not row['IsClosed']]
            else:
                windows = connection.execute('''SELECT StartTime, EndTime
                    FROM dbo.DoctorSchedules WHERE DoctorID=? AND DayOfWeek=? AND IsAvailable=1''',
                    (did, chosen_date.isoweekday())).fetchall()
            if not windows:
                continue
            booked = connection.execute('''SELECT StartTime, EndTime FROM dbo.Appointments
                WHERE DoctorID=? AND AppointmentDate=?
                  AND (Status IS NULL OR Status NOT IN ('Cancelled','Rejected'))''',
                (did, chosen_date)).fetchall()
            cancelled = connection.execute('''SELECT StartTime, EndTime
                FROM dbo.TCMDoctorCancelledSlots WHERE DoctorID=? AND ScheduleDate=?''',
                (did, chosen_date)).fetchall()
            slots = []
            seen = set()
            for window in windows:
                start_value = window['StartTime']
                end_value = window['EndTime']
                start_minute = start_value.hour * 60 + start_value.minute
                end_minute = end_value.hour * 60 + end_value.minute
                for minute in range(max(420, ((start_minute + 29) // 30) * 30), min(end_minute, 1200), 30):
                    if minute + 30 > end_minute or 780 <= minute < 900:
                        continue
                    slot_datetime = datetime.combine(chosen_date, time(minute // 60, minute % 60), tzinfo=timezone(timedelta(hours=8)))
                    if slot_datetime <= now:
                        continue
                    def intersects(row):
                        row_start = row['StartTime']
                        row_end = row['EndTime']
                        a = row_start.hour * 60 + row_start.minute
                        b = row_end.hour * 60 + row_end.minute if row_end else a + 30
                        return minute < b and a < minute + 30
                    if any(intersects(row) for row in booked) or any(intersects(row) for row in cancelled):
                        continue
                    stamp = f'{minute // 60:02d}:{minute % 60:02d}'
                    if stamp in seen:
                        continue
                    seen.add(stamp)
                    final_minute = minute + 30
                    slots.append({'time': stamp, 'endTime': f'{final_minute // 60:02d}:{final_minute % 60:02d}'})
            doctors.append({'doctorId': doctor['DoctorCode'], 'name': doctor['FullName'],
                            'slots': sorted(slots, key=lambda slot: slot['time'])})
        return {'services': service_names, 'doctors': doctors, 'message': ''}


@app.post('/api/admin/clinic-appointments', status_code=201)
def clinic_appointment_create(payload: ClinicNewAppointmentPayload, request: Request):
    with connect() as connection:
        account = require_account(request, connection)
        if account['role'] not in ('staff', 'doctor'):
            raise HTTPException(403, 'Only clinic staff and doctors can create appointments.')
        if account['role'] == 'doctor' and payload.doctorId != account['id']:
            raise HTTPException(403, 'Doctors can only create appointments assigned to themselves.')
        patient_id = clinic_booking.parse_key(payload.patientId, 'PAT-SQL-')
        if not connection.execute('SELECT PatientID FROM dbo.Patients WHERE PatientID=?', (patient_id,)).fetchone():
            raise HTTPException(404, 'Patient not found.')
        service = connection.execute('''SELECT ServiceID FROM dbo.Services
            WHERE ServiceName = ? AND IsActive = 1''', (payload.service,)).fetchone()
        if not service:
            raise HTTPException(422, 'Service is not available.')
        target_date, start, end, doctor_id = clinic_booking.validate_slot(
            connection, payload.date, payload.time, payload.doctorId)
        if datetime.combine(target_date, start, tzinfo=timezone(timedelta(hours=8))) <= datetime.now(timezone(timedelta(hours=8))):
            raise HTTPException(409, 'Choose a future appointment time.')
        offered = connection.execute('''SELECT 1 AS ok FROM dbo.DoctorServices
            WHERE DoctorID=? AND ServiceID=?''', (doctor_id, service['ServiceID'])).fetchone()
        if not offered:
            raise HTTPException(422, 'Doctor does not provide that service.')
        lock = connection.execute('''
            DECLARE @res INT;
            EXEC @res = sys.sp_getapplock @Resource = ?, @LockMode='Exclusive',
                @LockOwner='Transaction', @LockTimeout=10000;
            SELECT @res AS res;
        ''', (f'TCM-Appointment-{doctor_id}-{target_date.isoformat()}',)).fetchone()
        if not lock or lock['res'] < 0:
            raise HTTPException(503, 'Booking busy. Please retry.')
        # Repeat check after obtaining booking lock to prevent parallel double booking.
        clinic_booking.validate_slot(connection, payload.date, payload.time, payload.doctorId)
        patient_overlap = connection.execute('''SELECT COUNT(*) AS n FROM dbo.Appointments WITH (UPDLOCK, HOLDLOCK)
            WHERE PatientID=? AND AppointmentDate=? AND StartTime<?
              AND (EndTime IS NULL OR EndTime>?)
              AND (Status IS NULL OR Status NOT IN ('Cancelled','Rejected'))''',
              (patient_id, target_date, end, start)).fetchone()
        if patient_overlap['n']:
            raise HTTPException(409, 'Patient already has an overlapping appointment.')
        result = connection.execute('''INSERT INTO dbo.Appointments (
            PatientID, DoctorID, ServiceID, AppointmentDate, StartTime,
            EndTime, Room, Status, CreatedAt)
            OUTPUT INSERTED.AppointmentID
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Scheduled', SYSDATETIME())''',
            (patient_id, doctor_id, service['ServiceID'], target_date, start, end,
             payload.room[:50])).fetchone()
        return {'id': clinic_booking.appointment_key(result['AppointmentID']), 'status': 'Scheduled'}


from tcm_messages import ensure_schema as ensure_chat_schema, list_threads as chat_list_threads, read_thread as chat_read_thread, send_message as chat_send_message


class ChatMessagePayload(BaseModel):
    text: str = Field(min_length=1, max_length=1000)


@app.get('/api/admin/messages/threads')
def clinic_message_threads(request: Request):
    with connect() as db:
        account = require_account(request, db)
        cursor = db.connection.cursor()
        if account["role"] not in ("staff", "doctor"):
            raise HTTPException(403, "Clinic messaging requires staff or doctor access.")
        ensure_chat_schema(cursor)
        return chat_list_threads(cursor, account['role'], account['id'])


@app.get('/api/admin/messages/threads/{thread_id}')
def clinic_message_thread(thread_id: str, request: Request):
    with connect() as db:
        account = require_account(request, db)
        cursor = db.connection.cursor()
        if account["role"] not in ("staff", "doctor"):
            raise HTTPException(403, "Clinic messaging requires staff or doctor access.")
        ensure_chat_schema(cursor)
        return chat_read_thread(cursor, account['role'], account['id'], thread_id)


@app.post('/api/admin/messages/threads/{thread_id}', status_code=201)
def clinic_message_send(thread_id: str, payload: ChatMessagePayload, request: Request):
    with connect() as db:
        account = require_account(request, db)
        cursor = db.connection.cursor()
        if account["role"] not in ("staff", "doctor"):
            raise HTTPException(403, "Clinic messaging requires staff or doctor access.")
        ensure_chat_schema(cursor)
        return chat_send_message(cursor, account['role'], account['id'], thread_id, payload.text)
