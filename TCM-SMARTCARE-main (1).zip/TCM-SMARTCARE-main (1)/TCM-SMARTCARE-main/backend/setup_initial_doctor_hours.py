"""One-time safe initial rota for TCM SmartCare.

Run from the existing project root: python -m backend.setup_initial_doctor_hours
Uses the EXISTING SQL Server settings in backend/app.py. No new services/ports.
This intentionally does not run on app startup, so newly added doctors keep their
individually edited hours and are never overridden automatically.
"""
from datetime import datetime, time

from fastapi import HTTPException

from .app import connect
from .schedule_editor import (
    lock_editor, validate_appointments, date_override, weekly_windows, overlaps,
    display_time,
)

EARLY = (time(7, 0), time(13, 0))
LATE = (time(15, 0), time(20, 0))
DAY_PLAN = {
    1: ("lim wei ming", "tan mei ling"),
    2: ("tan mei ling", "wong jun hao"),
    3: ("wong jun hao", "lim wei ming"),
    4: ("lim wei ming", "tan mei ling"),
    5: ("tan mei ling", "wong jun hao"),
    6: ("wong jun hao", "lim wei ming"),
}


def normalized(name):
    text = " ".join(str(name).lower().replace(".", " ").split())
    return text.removeprefix("dr ")


def plan(doctors):
    lookup = {normalized(doc["FullName"]): doc for doc in doctors}
    required = {name for pair in DAY_PLAN.values() for name in pair}
    missing = required - set(lookup)
    if missing:
        raise RuntimeError("Cannot find the original 3 active doctors: " + ", ".join(sorted(missing)))
    result = {doc["DoctorID"]: {day: [] for day in range(1, 7)} for doc in doctors}
    original = {lookup[key]["DoctorID"] for key in required}
    for day, (early, late) in DAY_PLAN.items():
        result[lookup[early]["DoctorID"]][day] = [EARLY]
        result[lookup[late]["DoctorID"]][day] = [LATE]
    return result, original


def calculate_windows(connection, doctor, day, shifts, original):
    doctor_id = doctor["DoctorID"]
    if doctor_id in original:
        return shifts[doctor_id].get(day, [])
    return weekly_windows(connection, doctor_id, day)


def verify_day_non_overlapping(doctors, day, per_doc):
    working = [(doc["FullName"], per_doc(doc, day)) for doc in doctors]
    working = [(name, windows) for name, windows in working if windows]
    if len(working) > 2:
        raise RuntimeError(f"Weekday {day} has more than 2 doctors after the change: " + ", ".join(name for name, _ in working))
    for i, (name, windows) in enumerate(working):
        for other_name, others in working[i + 1:]:
            if any(overlaps(a, b) for a in windows for b in others):
                raise RuntimeError(f"Weekday {day}: {name} overlaps {other_name}; no changes saved.")


def verify_non_overlapping(doctors, per_doc):
    for day in range(1, 7):
        verify_day_non_overlapping(doctors, day, per_doc)


def setup():
    with connect() as connection:
        lock_editor(connection)
        doctors = connection.execute("""
            SELECT DoctorID, DoctorCode, FullName FROM dbo.Doctors
            WHERE IsActive = 1 ORDER BY DoctorID
        """).fetchall()
        shifts, original = plan(doctors)

        # Preserve every existing patient booking; abort the WHOLE transaction if one
        # cannot be served by the new shift (date exceptions are honored).
        for doctor in doctors:
            did = doctor["DoctorID"]
            if did in original:
                validate_appointments(connection, did, proposed_week=shifts[did])

        # Also inspect additional doctors, if any: no collision and max 2 per day.
        verify_non_overlapping(
            doctors,
            lambda doc, day: calculate_windows(connection, doc, day, shifts, original),
        )

        # Existing date exceptions override the weekly shift. Ensure upcoming date
        # exceptions do not create an overlap after the new weekly shifts are set.
        exception_dates = connection.execute("""
            SELECT DISTINCT ScheduleDate FROM dbo.TCMDoctorDateOverrides
            WHERE ScheduleDate >= CONVERT(DATE, SYSDATETIME())
            ORDER BY ScheduleDate
        """).fetchall()
        for row in exception_dates:
            target = row["ScheduleDate"]
            if isinstance(target, datetime):
                target = target.date()
            if target.isoweekday() == 7:
                continue
            def on_date(doc, day):
                override = date_override(connection, doc["DoctorID"], target)
                if override is not None:
                    for start, end in override:
                        if start < time(15, 0) and end > time(13, 0):
                            raise RuntimeError(f"Date exception for {doc['FullName']} on {target} overlaps the 13:00-15:00 clinic break. Edit this date exception before applying the initial rota.")
                return override if override is not None else calculate_windows(connection, doc, day, shifts, original)
            verify_day_non_overlapping(doctors, target.isoweekday(), on_date)

        print("\nREADY TO APPLY (SQL Server):")
        for day, (early, late) in DAY_PLAN.items():
            print(f"  {day}  07:00-13:00 {early.title()} | 13:00-15:00 BREAK | 15:00-20:00 {late.title()}")
        print("  7  Sunday CLOSED")
        print("  Upcoming patient bookings / date exceptions: kept unchanged.")
        approval = input("\nType YES to apply the 3 initial schedules: ").strip()
        if approval != "YES":
            raise RuntimeError("Not confirmed. Nothing changed.")

        total = 0
        for did in original:
            connection.execute("DELETE FROM dbo.DoctorSchedules WHERE DoctorID = ?", (did,))
            for weekday, windows in shifts[did].items():
                for start, end in windows:
                    connection.execute("""
                        INSERT INTO dbo.DoctorSchedules
                            (DoctorID, DayOfWeek, StartTime, EndTime, SlotDurationMinutes, Capacity, IsAvailable)
                        VALUES (?, ?, ?, ?, 30, 1, 1)
                    """, (did, weekday, display_time(start), display_time(end)))
                    total += 1
    print(f"SUCCESS: {total} weekly shifts COMMITTED to SQL Server for the 3 existing doctors.")


if __name__ == "__main__":
    try:
        setup()
    except (RuntimeError, HTTPException) as ex:
        message = ex.detail if isinstance(ex, HTTPException) else str(ex)
        print("\nNOT SAVED:", message)
        raise SystemExit(1) from None
