
import pyodbc
from .db import get_connection


class SQLUserRepository:

    _details_schema_ready = False

    def _ensure_profile_details(self, cursor):

        if self._details_schema_ready:
            return
        cursor.execute("""
            IF OBJECT_ID(N'dbo.TCMPatientProfileDetails', N'U') IS NULL
            BEGIN
                CREATE TABLE dbo.TCMPatientProfileDetails (
                    PatientID INT NOT NULL PRIMARY KEY
                        REFERENCES dbo.Patients(PatientID),
                    BirthDate DATE NULL,
                    ContactMethod NVARCHAR(10) NOT NULL DEFAULT N'phone',
                    Address NVARCHAR(1000) NOT NULL DEFAULT N'',
                    Photo NVARCHAR(MAX) NULL,
                    UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
                );
            END
        """)


    def _profile_details(self, cursor, patient_id):
        self._ensure_profile_details(cursor)
        cursor.execute("""SELECT BirthDate, ContactMethod, Address, Photo
            FROM dbo.TCMPatientProfileDetails WHERE PatientID = ?""", int(patient_id))
        row = cursor.fetchone()
        return {
            'profileDetailsSaved': bool(row),
            'birthDate': str(row[0])[:10] if row and row[0] else '',
            'contactMethod': (row[1] if row and row[1] in ('phone', 'email') else 'phone'),
            'address': row[2] if row and row[2] else '',
            'photo': row[3] if row and row[3] else '',
        }


    # Convert SQL Server record to Python Dictionary
    def _to_user(self, row):
        if row is None:
            return None

        stored_password = row.PasswordHash or ""

        try:
            salt, password_hash = stored_password.split("$", 1)
        except ValueError:
            salt, password_hash = "", ""

        return {
            "id": str(row.PatientID),
            "fullName": row.FullName,
            "email": row.Email,
            "phone": row.Phone or "",
            "gender": row.Gender or "",
            "age": row.Age,
            "salt": salt,
            "password_hash": password_hash
        }

    # 1. Register Patient
    def create(self, profile, salt, password_hash):
        conn = get_connection()

        try:
            cursor = conn.cursor()

            email = profile["email"].strip().lower()

            cursor.execute("""
                INSERT INTO dbo.Patients
                (
                    FullName,
                    Email,
                    Phone,
                    Gender,
                    Age,
                    PasswordHash
                )
                OUTPUT INSERTED.PatientID
                VALUES (?, ?, ?, ?, ?, ?)
            """,
                profile["fullName"],
                email,
                profile["phone"],
                profile["gender"],
                profile["age"],
                salt + "$" + password_hash
            )

            patient_id = cursor.fetchone()[0]
            conn.commit()

            return self.find_by_id(patient_id)

        except pyodbc.IntegrityError as error:
            conn.rollback()

            if "2601" in str(error) or "2627" in str(error):
                raise ValueError("duplicate") from error

            raise

        except Exception:
            conn.rollback()
            raise

        finally:
            conn.close()

    # 2. Find Patient by Email
    def find_by_email(self, email):
        conn = get_connection()

        try:
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    PatientID,
                    FullName,
                    Email,
                    Phone,
                    Gender,
                    Age,
                    PasswordHash
                FROM dbo.Patients
                WHERE Email = ?
            """, email.strip().lower())

            result = self._to_user(cursor.fetchone())
            # Login only needs credentials. My Profile explicitly fetches details.
            return result

        finally:
            conn.close()

    # 3. Find Patient by ID
    def find_by_id(self, user_id, include_details=False):
        try:
            patient_id = int(user_id)
        except (ValueError, TypeError):
            return None

        conn = get_connection()

        try:
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    PatientID,
                    FullName,
                    Email,
                    Phone,
                    Gender,
                    Age,
                    PasswordHash
                FROM dbo.Patients
                WHERE PatientID = ?
            """, patient_id)

            result = self._to_user(cursor.fetchone())
            if result and include_details:
                result.update(self._profile_details(cursor, patient_id))
                conn.commit()  # Commit any first-use profile details schema creation.
                self._details_schema_ready = True
            return result

        finally:
            conn.close()

    # 4. Update Patient Profile
    def update_profile(self, user_id, fields):
        conn = get_connection()

        try:
            cursor = conn.cursor()

            cursor.execute("""
                UPDATE dbo.Patients
                SET FullName = ?, Email = ?, Phone = ?
                WHERE PatientID = ?
            """,
                fields["fullName"],
                fields["email"],
                fields.get("phone", ""),
                int(user_id)
            )

            if cursor.rowcount == 0:
                raise ValueError("Patient not found")

            self._ensure_profile_details(cursor)
            cursor.execute("""
                UPDATE dbo.TCMPatientProfileDetails
                SET BirthDate = ?, ContactMethod = ?, Address = ?, Photo = ?,
                    UpdatedAt = SYSUTCDATETIME()
                WHERE PatientID = ?
            """, fields.get('birthDate') or None, fields.get('contactMethod', 'phone'),
                fields.get('address', ''), fields.get('photo', '') or None, int(user_id))
            if cursor.rowcount == 0:
                cursor.execute("""
                    INSERT INTO dbo.TCMPatientProfileDetails
                        (PatientID, BirthDate, ContactMethod, Address, Photo)
                    VALUES (?, ?, ?, ?, ?)
                """, int(user_id), fields.get('birthDate') or None,
                    fields.get('contactMethod', 'phone'), fields.get('address', ''),
                    fields.get('photo', '') or None)
            conn.commit()
            self._details_schema_ready = True

        except pyodbc.IntegrityError as error:
            conn.rollback()
            if "2601" in str(error) or "2627" in str(error):
                raise ValueError("duplicate") from error
            raise
        except Exception:
            conn.rollback()
            raise

        finally:
            conn.close()

        return self.find_by_id(user_id, include_details=True)

    def update_photo(self, user_id, photo):
        conn = get_connection()
        try:
            cursor = conn.cursor()
            self._ensure_profile_details(cursor)
            cursor.execute("""UPDATE dbo.TCMPatientProfileDetails
                SET Photo=?, UpdatedAt=SYSUTCDATETIME() WHERE PatientID=?""",
                photo or None, int(user_id))
            if cursor.rowcount == 0:
                cursor.execute("""INSERT INTO dbo.TCMPatientProfileDetails
                    (PatientID, Photo) VALUES (?, ?)""", int(user_id), photo or None)
            conn.commit()
            self._details_schema_ready = True
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
        return self.find_by_id(user_id, include_details=True)

    # 5. Change Password
    def update_password(self, user_id, salt, password_hash, expected_password=None):
        conn = get_connection()

        try:
            cursor = conn.cursor()

            if expected_password is None:
                cursor.execute("""
                    UPDATE dbo.Patients SET PasswordHash = ?
                    WHERE PatientID = ?
                """, salt + "$" + password_hash, int(user_id))
            else:
                cursor.execute("""
                    UPDATE dbo.Patients SET PasswordHash = ?
                    WHERE PatientID = ? AND PasswordHash = ?
                """, salt + "$" + password_hash, int(user_id), expected_password)

            if cursor.rowcount == 0:
                raise ValueError("Patient not found")

            conn.commit()

        except Exception:
            conn.rollback()
            raise

        finally:
            conn.close()


# Use SQL Server instead of temporary Memory
repository = SQLUserRepository()
