
import pyodbc

# SQL Server Configuration
SERVER = r"(localdb)\MSSQLLocalDB"
DATABASE = "TCM_SmartCare"


def get_connection():

    # Find available SQL Server ODBC Driver
    drivers = pyodbc.drivers()

    if "ODBC Driver 18 for SQL Server" in drivers:
        driver = "ODBC Driver 18 for SQL Server"

    elif "ODBC Driver 17 for SQL Server" in drivers:
        driver = "ODBC Driver 17 for SQL Server"

    else:
        raise RuntimeError(
            "SQL Server ODBC Driver 17/18 not found."
        )

    # SQL Server Connection String
    connection_string = (
        f"DRIVER={{{driver}}};"
        f"SERVER={SERVER};"
        f"DATABASE={DATABASE};"
        "Trusted_Connection=yes;"
        "Encrypt=yes;"
        "TrustServerCertificate=yes;"
    )

    return pyodbc.connect(
        connection_string,
        timeout=10
    )


# Test SQL Server Connection
if __name__ == "__main__":

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT DB_NAME()")
        database = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COUNT(*)
            FROM sys.tables
            WHERE name = 'Patients'
        """)

        patients_exists = cursor.fetchone()[0]

        print("SQL Server Connected Successfully!")
        print("Database:", database)
        print("Patients Table Exists:", bool(patients_exists))

        conn.close()

    except Exception as error:
        print("Database Connection Failed!")
        print(error)
