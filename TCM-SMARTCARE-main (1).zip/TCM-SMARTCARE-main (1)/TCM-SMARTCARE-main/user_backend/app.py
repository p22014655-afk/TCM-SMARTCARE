import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import secrets
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import parse_qs

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .repository import repository
from .db import get_connection
from clinical_records import ensure_schema

ROOT = Path(__file__).resolve().parent.parent
COOKIE = 'tcm_user_session'
ITERATIONS = 310_000

sessions = {}
app = FastAPI(title='TCM SmartCare User Backend')


def digest(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), ITERATIONS).hex()


def valid_password(value):
    return (8 <= len(value) <= 1024 and len(re.findall(r'[0-9]', value)) >= 4
            and re.search(r'[A-Z]', value) and re.search(r'[^A-Za-z0-9]', value))


def public_user(record):
    return {key: value for key, value in record.items() if key not in {'salt', 'password_hash'}}


def require_user(request):
    token = request.cookies.get(COOKIE, '')
    key = hashlib.sha256(token.encode()).hexdigest()
    session = sessions.get(key)
    if not session or session['expires'] <= datetime.now(timezone.utc):
        sessions.pop(key, None)
        raise HTTPException(401, 'Please sign in to continue.')
    user = repository.find_by_id(session['user_id'])
    if not user or session.get('password_fingerprint') != user['password_hash']:
        sessions.pop(key, None)
        raise HTTPException(401, 'Please sign in again.')
    return user


async def form_values(request):
    
    if len(await request.body()) > 16_384:
        raise HTTPException(413, 'Form is too large.')
    return {key: values[0] for key, values in parse_qs(
        (await request.body()).decode('utf-8'), keep_blank_values=True).items()}



@app.get("/api/user/health")
def health():
    try:
        conn = get_connection()

        try:
            cursor = conn.cursor()
            cursor.execute("SELECT DB_NAME()")
            database_name = cursor.fetchone()[0]

            return {
                "status": "ok",
                "storage": "sql-server",
                "sql_connected": True,
                "database": database_name
            }

        finally:
            conn.close()

    except Exception as error:
        print("Database Health Error:", repr(error))

        return {
            "status": "error",
            "storage": "sql-server",
            "sql_connected": False,
            "database": None
        }


@app.post('/api/user/register')
async def register(request: Request):
    data = await form_values(request)
    name = data.get('fullName', '').strip()
    email = data.get('email', '').strip().lower()
    phone = data.get('phone', '').strip()
    password = data.get('password', '')
    try:
        age = int(data.get('age', ''))
    except ValueError:
        age = 0
    error = None
    if (not 2 <= len(name) <= 100 or len(email) > 254
            or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email)
            or not 1 <= age <= 120 or data.get('gender') not in
            {'female', 'male', 'non-binary', 'prefer-not-to-say', 'self-describe'}):
        error = 'details'
    elif len(phone) > 25 or len(re.sub(r'\D', '', phone)) < 7:
        error = 'phone'
    elif not valid_password(password):
        error = 'password'
    elif password != data.get('confirmPassword'):
        error = 'confirm'
    elif not data.get('terms'):
        error = 'terms'
    if error:
        return RedirectResponse('/User/createaccount.html?error=' + error, 303)
    salt = secrets.token_hex(16)
    try:
        repository.create(dict(fullName=name, email=email, phone=phone,
                               gender=data['gender'], age=age), salt, digest(password, salt))
    except ValueError:
        return RedirectResponse('/User/createaccount.html?error=duplicate', 303)
    return RedirectResponse('/User/createaccount.html?success=1', 303)


@app.post('/api/user/login')
async def login(request: Request):
    data = await form_values(request)
    user = repository.find_by_email(data.get('identifier', ''))
    password = data.get('password', '')
    if (not user or not user.get('salt') or len(password) > 1024 or not hmac.compare_digest(
            digest(password, user['salt']), user['password_hash'])):
        return RedirectResponse('/User/login.html?error=invalid', 303)
    
    profile_json = json.dumps(public_user(user)).replace('<', '\\u003c')
    response = HTMLResponse('''<!doctype html><meta charset="utf-8"><title>Signing in</title>
<script>
const user = ''' + profile_json + ''';
sessionStorage.setItem('tcmPatientName', user.fullName);
sessionStorage.setItem('tcmPatientEmail', user.email);
localStorage.setItem('tcmPatientProfile', JSON.stringify(user));
localStorage.removeItem('tcmPatientAccount');
location.replace('/User/main.html');
</script>''', headers={'Cache-Control': 'no-store'})
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    for key in list(sessions):
        if sessions[key]['expires'] <= now:
            sessions.pop(key, None)
    old_token = request.cookies.get(COOKIE, '')
    sessions.pop(hashlib.sha256(old_token.encode()).hexdigest(), None)
    sessions[hashlib.sha256(token.encode()).hexdigest()] = {
        'user_id': user['id'], 'expires': now + timedelta(hours=8),
        'password_fingerprint': user['password_hash']}
    response.set_cookie(COOKIE, token, max_age=28800, httponly=True,
                        secure=os.getenv('TCM_COOKIE_SECURE', 'false').lower() == 'true',
                        samesite='strict', path='/api/user')
    return response


@app.get('/api/user/me')
def me(request: Request):
    user = require_user(request)
    return {'user': public_user(repository.find_by_id(user['id'], include_details=True))}


class ProfilePayload(BaseModel):
    fullName: str = Field(min_length=2, max_length=100)
    email: str = Field(min_length=5, max_length=254)
    phone: str = Field(default='', max_length=25)
    currentPassword: str = Field(default='', max_length=1024)
    birthDate: str = Field(default='', max_length=10)
    contactMethod: str = Field(default='phone', pattern='^(phone|email)$')
    address: str = Field(default='', max_length=1000)
    photo: str = Field(default='', max_length=2_000_000)


def validate_profile_photo(photo: str) -> str:
    if not photo:
        return ''
    # Accept resized browser images only; reject untrusted HTML/SVG or remote URLs.
    match = re.fullmatch(r'data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)', photo)
    if not match:
        raise HTTPException(422, 'Upload a JPG, PNG or WEBP photo.')
    try:
        raw = base64.b64decode(match.group(2), validate=True)
    except (binascii.Error, ValueError) as error:
        raise HTTPException(422, 'Invalid picture data.') from error
    if not raw or len(raw) > 2 * 1024 * 1024:
        raise HTTPException(413, 'Profile picture must be no larger than 2 MB.')
    kind = match.group(1)
    if not ((kind == 'jpeg' and raw.startswith(b'\xff\xd8\xff')) or
            (kind == 'png' and raw.startswith(b'\x89PNG\r\n\x1a\n')) or
            (kind == 'webp' and raw.startswith(b'RIFF') and raw[8:12] == b'WEBP')):
        raise HTTPException(422, 'Image content does not match its file type.')
    return photo


class ProfilePhotoPayload(BaseModel):
    photo: str = Field(default='', max_length=2_000_000)


@app.put('/api/user/profile-photo')
def update_profile_photo(payload: ProfilePhotoPayload, request: Request):
    user = require_user(request)
    updated = repository.update_photo(user['id'], validate_profile_photo(payload.photo))
    return {'user': public_user(updated)}


def check_current_password(user, password):
    return bool(user and user.get('salt') and len(password) <= 1024 and
                hmac.compare_digest(digest(password, user['salt']), user['password_hash']))


@app.put('/api/user/profile')
def update_profile(payload: ProfilePayload, request: Request):
    user = require_user(request)
    email = payload.email.strip().lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
        raise HTTPException(422, 'Enter a valid email.')
    if email != user['email'].strip().lower():
        if not check_current_password(user, payload.currentPassword):
            raise HTTPException(400, 'Current password is required to change your email.')
    if payload.birthDate:
        try:
            birth = date.fromisoformat(payload.birthDate)
        except ValueError as error:
            raise HTTPException(422, 'Enter a valid date of birth.') from error
        if birth > date.today():
            raise HTTPException(422, 'Date of birth cannot be in the future.')
    try:
        updated = repository.update_profile(user['id'], {
            'fullName': payload.fullName.strip(), 'email': email,
            'phone': payload.phone.strip(),
            'birthDate': payload.birthDate, 'contactMethod': payload.contactMethod,
            'address': payload.address.strip(),
            'photo': validate_profile_photo(payload.photo),
        })
    except ValueError as error:
        if str(error) == 'duplicate':
            raise HTTPException(409, 'This email is already registered.') from error
        raise
    return {'user': public_user(updated)}


class PasswordPayload(BaseModel):
    current_password: str = Field(min_length=1, max_length=1024)
    new_password: str = Field(min_length=8, max_length=1024)


def set_new_password(user, new_password, keep_session_key=None):
    if not valid_password(new_password):
        raise HTTPException(422, 'Use at least 8 characters, 4 numbers, an uppercase letter and a symbol.')
    if check_current_password(user, new_password):
        raise HTTPException(422, 'Choose a different password from your current password.')
    salt = secrets.token_hex(16)
    new_hash = digest(new_password, salt)
    try:
        repository.update_password(user['id'], salt, new_hash,
                                   user['salt'] + '$' + user['password_hash'])
    except ValueError as error:
        raise HTTPException(409, 'Could not update the password. Please try again.') from error

    # Login and My Profile MUST read the same dbo.Patients row. Confirm that
    # the credentials just saved will pass the next login, before saying success.
    saved_user = repository.find_by_id(user['id'])
    if (not saved_user or not saved_user.get('salt') or
            not hmac.compare_digest(digest(new_password, saved_user['salt']),
                                    saved_user['password_hash'])):
        raise HTTPException(500, 'Password update could not be verified. Please contact support.')

    for key in list(sessions):
        if sessions[key]['user_id'] == user['id']:
            if key == keep_session_key:
                sessions[key]['password_fingerprint'] = new_hash
            else:
                sessions.pop(key, None)
    return {'message': 'Password updated successfully. Use your new password next time.'}


@app.put('/api/user/password')
def change_password(payload: PasswordPayload, request: Request):
    user = require_user(request)
    if not check_current_password(user, payload.current_password):
        raise HTTPException(400, 'Current password is incorrect.')
    key = hashlib.sha256(request.cookies.get(COOKIE, '').encode()).hexdigest()
    return set_new_password(user, payload.new_password, keep_session_key=key)


@app.post('/api/user/logout')
def logout(request: Request, response: Response):
    token = request.cookies.get(COOKIE, '')
    sessions.pop(hashlib.sha256(token.encode()).hexdigest(), None)
    response.delete_cookie(COOKIE, path='/api/user')
    return {'message': 'Signed out.'}


from .password_recovery import create_reset_router
app.include_router(create_reset_router(repository, digest, valid_password, sessions))


@app.get('/')
def home():
    return RedirectResponse('/User/login.html')


class WellnessSubmission(BaseModel):
    age: str = Field(default='', max_length=60)
    duration: str = Field(default='', max_length=60)
    energy: str = Field(min_length=1, max_length=40)
    sleep: str = Field(min_length=1, max_length=40)
    digestion: str = Field(min_length=1, max_length=40)
    temperature: str = Field(min_length=1, max_length=40)
    mood: str = Field(min_length=1, max_length=40)
    symptoms: list[str] = Field(default_factory=list, max_length=10)
    notes: str = Field(default='', max_length=500)
    consent: bool


@app.put('/api/user/wellness')
def save_patient_wellness(payload: WellnessSubmission, request: Request):
    user = require_user(request)
    if not payload.consent:
        raise HTTPException(422, 'Consent is required to submit this assessment.')
    if any(len(value) > 40 for value in payload.symptoms):
        raise HTTPException(422, 'Invalid symptom selection.')
    value = json.dumps({**payload.model_dump(exclude={'consent'}),
                        'concerns': ', '.join(payload.symptoms) or 'None selected'}, ensure_ascii=False)
    conn = get_connection()
    try:
        cur = conn.cursor()
        ensure_schema(cur)
        cur.execute("""SELECT PatientID FROM dbo.TCMWellnessAssessments WITH (UPDLOCK, HOLDLOCK)
            WHERE PatientID=?""", int(user['id']))
        if cur.fetchone() is None:
            cur.execute("""INSERT INTO dbo.TCMWellnessAssessments (PatientID, AssessmentJSON)
                VALUES (?,?)""", int(user['id']), value)
        else:
            cur.execute("""UPDATE dbo.TCMWellnessAssessments SET AssessmentJSON=?,
                SubmittedAt=SYSUTCDATETIME() WHERE PatientID=?""", value, int(user['id']))
        conn.commit()
        return {'message': 'Wellness Assessment saved to your patient record.'}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.get('/api/user/wellness')
def get_patient_wellness(request: Request):
    user = require_user(request)
    conn = get_connection()
    try:
        cur = conn.cursor()
        ensure_schema(cur)
        conn.commit()
        cur.execute('''SELECT AssessmentJSON, SubmittedAt FROM dbo.TCMWellnessAssessments
                       WHERE PatientID=?''', int(user['id']))
        row = cur.fetchone()
        return {'assessment': {**json.loads(row[0]), 'submittedAt': row[1].isoformat()}
                if row else None}
    finally:
        conn.close()


@app.get('/api/user/medicine-status')
def get_patient_medicine_status(request: Request):
    user = require_user(request)
    conn = get_connection()
    try:
        cur = conn.cursor()
        ensure_schema(cur)
        conn.commit()
        cur.execute('''SELECT a.AppointmentID, c.PreparationStatus
            FROM dbo.Appointments a
            JOIN dbo.TCMClinicalCarePlans c ON c.AppointmentID = a.AppointmentID
            WHERE a.PatientID=? AND c.PreparationStatus IN ('Prepared','Dispensed')''', int(user['id']))
        return {'statuses': {f'APT-SQL-{row[0]}': row[1] for row in cur.fetchall()}}
    finally:
        conn.close()


@app.get("/api/user/booking-data")
def get_booking_data():

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                DoctorID,
                DoctorCode,
                FullName,
                Specialization
            FROM dbo.Doctors
            WHERE IsActive = 1
            ORDER BY FullName
        """)

        doctors = [
            {
                "doctorId": row.DoctorID,
                "doctorCode": row.DoctorCode,
                "name": row.FullName,
                "specialization": row.Specialization
            }
            for row in cursor.fetchall()
        ]

        # Read published doctor profile photos from the same SQL Server admin_state
        # used by Staff & Accounts. Do not expose staff pictures or account details.
        try:
            cursor.execute("SELECT data_json FROM dbo.admin_state WHERE id = 1")
            state_row = cursor.fetchone()
            doctor_photos = {}
            if state_row:
                stored_state = json.loads(state_row[0] or "{}")
                for account in stored_state.get("doctors", []):
                    picture = account.get("profilePicture", "")
                    if (isinstance(picture, str) and len(picture) < 350000
                            and re.fullmatch(r"data:image/jpeg;base64,[A-Za-z0-9+/=]+", picture)):
                        doctor_photos[str(account.get("id", ""))] = picture
            for doctor in doctors:
                doctor["photo"] = doctor_photos.get(str(doctor["doctorCode"]), "")
        except Exception as error:
            # Doctor booking must continue even if photos are temporarily unavailable.
            print("Doctor Photo Lookup Error:", repr(error))

        cursor.execute("""
            SELECT
                ServiceID,
                ServiceName,
                DurationMinutes,
                Price
            FROM dbo.Services
            WHERE IsActive = 1
            ORDER BY ServiceName
        """)

        services = [
            {
                "serviceId": row.ServiceID,
                "serviceName": row.ServiceName,
                "duration": row.DurationMinutes,
                "price": float(row.Price)
            }
            for row in cursor.fetchall()
        ]

        cursor.execute("""
            SELECT
                ds.DoctorID,
                ds.ServiceID
            FROM dbo.DoctorServices ds
            JOIN dbo.Doctors d
                ON ds.DoctorID = d.DoctorID
            JOIN dbo.Services s
                ON ds.ServiceID = s.ServiceID
            WHERE d.IsActive = 1
              AND s.IsActive = 1
        """)

        doctor_services = [
            {
                "doctorId": row.DoctorID,
                "serviceId": row.ServiceID
            }
            for row in cursor.fetchall()
        ]

        cursor.execute("""
            SELECT
                ds.ScheduleID,
                ds.DoctorID,
                ds.DayOfWeek,
                ds.StartTime,
                ds.EndTime,
                ds.SlotDurationMinutes,
                ds.Capacity
            FROM dbo.DoctorSchedules ds
            JOIN dbo.Doctors d
                ON ds.DoctorID = d.DoctorID
            WHERE ds.IsAvailable = 1
              AND d.IsActive = 1
        """)

        schedules = [
            {
                "scheduleId": row.ScheduleID,
                "doctorId": row.DoctorID,
                "dayOfWeek": row.DayOfWeek,
                "startTime": str(row.StartTime),
                "endTime": str(row.EndTime),
                "slotDuration": row.SlotDurationMinutes,
                "capacity": row.Capacity
            }
            for row in cursor.fetchall()
        ]

        cursor.execute("""
            SELECT DoctorID, ScheduleDate, StartTime, EndTime, IsClosed
            FROM dbo.TCMDoctorDateOverrides
            WHERE ScheduleDate BETWEEN CAST(SYSDATETIME() AS DATE)
                AND DATEADD(DAY, 60, CAST(SYSDATETIME() AS DATE))
        """)

        date_overrides = [{
            "doctorId": row.DoctorID,
            "date": str(row.ScheduleDate)[:10],
            "startTime": str(row.StartTime)[:5] if row.StartTime else None,
            "endTime": str(row.EndTime)[:5] if row.EndTime else None,
            "isClosed": bool(row.IsClosed),
            "slotDuration": 30,
            "capacity": 1
        } for row in cursor.fetchall()]

        cursor.execute("""
            SELECT a.DoctorID, a.AppointmentDate, a.StartTime, a.EndTime
            FROM dbo.Appointments a
            JOIN dbo.Doctors d ON d.DoctorID = a.DoctorID
            WHERE d.IsActive = 1
              AND a.AppointmentDate BETWEEN CONVERT(DATE, SYSDATETIME())
              AND DATEADD(DAY, 14, CONVERT(DATE, SYSDATETIME()))
              AND (a.Status IS NULL OR a.Status NOT IN
                   ('Cancelled', 'Rejected'))
              AND a.EndTime IS NOT NULL
        """)
        booked_slots = [
            {
                "doctorId": row.DoctorID,
                "date": str(row.AppointmentDate)[:10],
                "startTime": str(row.StartTime)[:5],
                "endTime": str(row.EndTime)[:5]
            }
            for row in cursor.fetchall()
        ]

        cursor.execute("""
            SELECT DoctorID, ScheduleDate, StartTime, EndTime
            FROM dbo.TCMDoctorCancelledSlots
            WHERE ScheduleDate BETWEEN CAST(SYSDATETIME() AS DATE)
                AND DATEADD(DAY, 60, CAST(SYSDATETIME() AS DATE))
        """)
        cancelled_slots = [
            {
                "doctorId": row.DoctorID,
                "date": str(row.ScheduleDate)[:10],
                "startTime": str(row.StartTime)[:5],
                "endTime": str(row.EndTime)[:5]
            }
            for row in cursor.fetchall()
        ]

        return {
            "status": "success",
            "doctors": doctors,
            "services": services,
            "doctorServices": doctor_services,
            "schedules": schedules,
            "dateOverrides": date_overrides,
            "bookedSlots": booked_slots,
            "cancelledSlots": cancelled_slots
        }

    except Exception as error:
        print("Booking Data Error:", repr(error))
        raise HTTPException(
            status_code=500,
            detail="Unable to load booking data."
        )

    finally:
        if "conn" in locals():
            conn.close()


class AppointmentPayload(BaseModel):
    doctorId: int = Field(gt=0)
    serviceId: int = Field(gt=0)
    appointmentDate: str = Field(
        pattern=r"^\d{4}-\d{2}-\d{2}$"
    )
    startTime: str = Field(
        pattern=r"^([01]\d|2[0-3]):[0-5]\d$"
    )
    endTime: str = Field(
        pattern=r"^([01]\d|2[0-3]):[0-5]\d$"
    )


@app.post("/api/user/appointments", status_code=201)
def create_appointment(
    payload: AppointmentPayload,
    request: Request
):
    user = require_user(request)

    try:
        patient_id = int(user["id"])

        appointment_date = datetime.strptime(
            payload.appointmentDate, "%Y-%m-%d"
        ).date()

        start_time = datetime.strptime(
            payload.startTime, "%H:%M"
        ).time()

        end_time = datetime.strptime(
            payload.endTime, "%H:%M"
        ).time()

    except (ValueError, TypeError):
        raise HTTPException(
            status_code=422,
            detail="Invalid appointment information."
        )

    malaysia_time = timezone(timedelta(hours=8))
    now = datetime.now(malaysia_time)

    appointment_start = datetime.combine(
        appointment_date,
        start_time,
        tzinfo=malaysia_time
    )

    if appointment_start <= now:
        raise HTTPException(
            status_code=422,
            detail="Please select a future appointment."
        )

    if end_time <= start_time:
        raise HTTPException(
            status_code=422,
            detail="Invalid appointment time."
        )

    if appointment_date.isoweekday() == 7:
        raise HTTPException(
            status_code=422,
            detail="The clinic is closed on Sunday."
        )

    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            SET NOCOUNT ON;
            DECLARE @result INT;
            EXEC @result = sys.sp_getapplock
                @Resource = N'TCMDoctorScheduleChanges',
                @LockMode = N'Shared',
                @LockOwner = N'Transaction',
                @LockTimeout = 10000;
            SELECT @result;
        """)
        schedule_lock = cursor.fetchone()
        if not schedule_lock or int(schedule_lock[0]) < 0:
            raise HTTPException(503, "Doctor schedule is being updated. Please retry.")

        cursor.execute("""
            SELECT DoctorID
            FROM dbo.Doctors
            WHERE DoctorID = ?
              AND IsActive = 1
        """, payload.doctorId)

        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail="Doctor not found or inactive."
            )

        cursor.execute("""
            SELECT ServiceID
            FROM dbo.Services
            WHERE ServiceID = ?
              AND IsActive = 1
        """, payload.serviceId)

        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail="Service not available."
            )

        cursor.execute("""
            SELECT 1
            FROM dbo.DoctorServices
            WHERE DoctorID = ?
              AND ServiceID = ?
        """, payload.doctorId, payload.serviceId)

        if not cursor.fetchone():
            raise HTTPException(
                status_code=422,
                detail="Doctor does not provide this service."
            )

        day_of_week = appointment_date.isoweekday()

        cursor.execute("""
            SELECT StartTime, EndTime, CAST(30 AS INT) AS SlotDurationMinutes, CAST(1 AS INT) AS Capacity
            FROM dbo.TCMDoctorDateOverrides
            WHERE DoctorID = ? AND ScheduleDate = ? AND IsClosed = 0
        """, payload.doctorId, appointment_date)
        date_windows = cursor.fetchall()

        cursor.execute("""
            SELECT COUNT(*) FROM dbo.TCMDoctorDateOverrides
            WHERE DoctorID = ? AND ScheduleDate = ?
        """, payload.doctorId, appointment_date)
        has_date_override = cursor.fetchone()[0] > 0

        if has_date_override:
            schedules = date_windows
        else:
            cursor.execute("""
                SELECT StartTime, EndTime, SlotDurationMinutes, Capacity
                FROM dbo.DoctorSchedules
                WHERE DoctorID = ? AND DayOfWeek = ? AND IsAvailable = 1
            """, payload.doctorId, day_of_week)
            schedules = cursor.fetchall()

        valid_capacity = None

        requested_start = (
            start_time.hour * 60 + start_time.minute
        )

        requested_end = (
            end_time.hour * 60 + end_time.minute
        )

        for schedule in schedules:
            schedule_start_time = schedule.StartTime
            schedule_end_time = schedule.EndTime

            schedule_start = (
                schedule_start_time.hour * 60 +
                schedule_start_time.minute
            )

            schedule_end = (
                schedule_end_time.hour * 60 +
                schedule_end_time.minute
            )

            duration = int(
                schedule.SlotDurationMinutes or 0
            )

            capacity = int(
                schedule.Capacity or 0
            )

            if duration <= 0 or capacity <= 0:
                continue

            if (
                requested_start >= schedule_start
                and requested_end <= schedule_end
                and requested_end - requested_start == duration
                and (requested_start - schedule_start) % duration == 0
            ):
                valid_capacity = capacity
                break

        if valid_capacity is None:
            raise HTTPException(
                status_code=409,
                detail="Selected time is outside the doctor's schedule."
            )

        cursor.execute("""
            SELECT 1 FROM dbo.TCMDoctorCancelledSlots
            WHERE DoctorID = ? AND ScheduleDate = ?
              AND StartTime < ? AND EndTime > ?
        """, payload.doctorId, appointment_date, end_time, start_time)
        if cursor.fetchone():
            raise HTTPException(
                status_code=409,
                detail="Doctor is unavailable at this time. Please choose another appointment."
            )

        cursor.execute("""
            SELECT DoctorID FROM dbo.Doctors
            WHERE IsActive = 1 AND DoctorID <> ?
        """, payload.doctorId)
        other_doctor_ids = [int(row[0]) for row in cursor.fetchall()]

        for other_id in other_doctor_ids:
            cursor.execute("""
                SELECT COUNT(*) FROM dbo.TCMDoctorDateOverrides
                WHERE DoctorID = ? AND ScheduleDate = ?
            """, other_id, appointment_date)
            has_override = cursor.fetchone()[0] > 0
            if has_override:
                cursor.execute("""
                    SELECT StartTime, EndTime
                    FROM dbo.TCMDoctorDateOverrides
                    WHERE DoctorID = ? AND ScheduleDate = ? AND IsClosed = 0
                """, other_id, appointment_date)
            else:
                cursor.execute("""
                    SELECT StartTime, EndTime FROM dbo.DoctorSchedules
                    WHERE DoctorID = ? AND DayOfWeek = ? AND IsAvailable = 1
                """, other_id, day_of_week)
            for other in cursor.fetchall():
                other_start = other.StartTime.hour * 60 + other.StartTime.minute
                other_end = other.EndTime.hour * 60 + other.EndTime.minute
                if requested_start < other_end and other_start < requested_end:
                    raise HTTPException(
                        status_code=409,
                        detail="The selected time overlaps another doctor's schedule. Please choose another time."
                    )

        lock_name = (
            f"TCM-Appointment-{payload.doctorId}-"
            f"{payload.appointmentDate}"
        )

        cursor.execute("""
            SET NOCOUNT ON;
            DECLARE @lock_result INT;

            EXEC @lock_result = sys.sp_getapplock
                @Resource = ?,
                @LockMode = 'Exclusive',
                @LockOwner = 'Transaction',
                @LockTimeout = 10000;

            SELECT @lock_result AS LockResult;
        """, lock_name)

        lock_result = cursor.fetchone()[0]

        if lock_result < 0:
            raise HTTPException(
                status_code=503,
                detail="Booking is busy. Please try again."
            )

        cursor.execute("""
            SELECT COUNT(*)
            FROM dbo.Appointments
            WHERE PatientID = ?
              AND AppointmentDate = ?
              AND StartTime < ?
              AND (
                  EndTime IS NULL
                  OR EndTime > ?
              )
              AND (
                  Status IS NULL
                  OR Status NOT IN ('Cancelled', 'Rejected')
              )
        """, patient_id, appointment_date, end_time, start_time)

        existing_patient_booking = cursor.fetchone()[0]

        if existing_patient_booking > 0:
            raise HTTPException(
                status_code=409,
                detail="You already have an appointment overlapping this time."
            )

        cursor.execute("""
            SELECT COUNT(*)
            FROM dbo.Appointments
            WHERE DoctorID = ?
              AND AppointmentDate = ?
              AND StartTime < ?
              AND (
                  EndTime IS NULL
                  OR EndTime > ?
              )
              AND (
                  Status IS NULL
                  OR Status NOT IN ('Cancelled', 'Rejected')
              )
        """,
            payload.doctorId,
            appointment_date,
            end_time,
            start_time
        )

        booked_count = cursor.fetchone()[0]

        if booked_count >= valid_capacity:
            raise HTTPException(
                status_code=409,
                detail="This time slot is fully booked."
            )

        cursor.execute("""
            INSERT INTO dbo.Appointments (
                PatientID,
                DoctorID,
                ServiceID,
                AppointmentDate,
                StartTime,
                EndTime,
                Room,
                Status,
                CreatedAt
            )
            OUTPUT INSERTED.AppointmentID
            VALUES (
                ?, ?, ?, ?, ?, ?, ?,
                'Scheduled',
                SYSDATETIME()
            )
        """,
            patient_id,
            payload.doctorId,
            payload.serviceId,
            appointment_date,
            start_time,
            end_time,
            "To be assigned"
        )

        appointment_id = cursor.fetchone()[0]

        conn.commit()

        return {
            "status": "success",
            "message": "Appointment booked successfully.",
            "appointmentId": appointment_id,
            "patientId": patient_id,
            "doctorId": payload.doctorId,
            "serviceId": payload.serviceId,
            "appointmentDate": payload.appointmentDate,
            "startTime": payload.startTime,
            "endTime": payload.endTime,
            "appointmentStatus": "Scheduled"
        }

    except HTTPException:
        conn.rollback()
        raise

    except Exception as error:
        conn.rollback()
        print("Appointment Database Error:", repr(error))

        raise HTTPException(
            status_code=500,
            detail="Unable to save appointment."
        )

    finally:
        conn.close()


@app.get('/api/user/notifications')
def patient_notifications(request: Request):
    from tcm_notifications import inbox
    user = require_user(request)
    conn = get_connection()
    try:
        result = inbox(conn, 'patient', user['id'])
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.post('/api/user/notifications/read-all')
def patient_notifications_read_all(request: Request):
    from tcm_notifications import mark_read
    user = require_user(request)
    conn = get_connection()
    try:
        result = mark_read(conn, 'patient', user['id'])
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.post('/api/user/notifications/{notification_id}/read')
def patient_notification_read(notification_id: int, request: Request):
    from tcm_notifications import mark_read
    user = require_user(request)
    conn = get_connection()
    try:
        result = mark_read(conn, 'patient', user['id'], notification_id)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


app.mount('/User', StaticFiles(directory=ROOT / 'User'), name='user')

from .orders import router as orders_router
app.include_router(orders_router)

@app.get('/api/user/appointments')
def list_my_appointments(request: Request):
    user = require_user(request)
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT a.AppointmentID, a.AppointmentDate, a.StartTime, a.EndTime,
                   a.Status, a.Room, d.FullName AS DoctorName,
                   s.ServiceName, d.DoctorCode
            FROM dbo.Appointments a
            JOIN dbo.Doctors d ON d.DoctorID=a.DoctorID
            JOIN dbo.Services s ON s.ServiceID=a.ServiceID
            WHERE a.PatientID=?
            ORDER BY a.AppointmentDate DESC, a.StartTime DESC, a.AppointmentID DESC
        ''', int(user['id']))
        return {'appointments': [{
            'id': f'APT-SQL-{int(row.AppointmentID)}',
            'date': str(row.AppointmentDate)[:10],
            'time': str(row.StartTime)[:5],
            'endTime': str(row.EndTime)[:5] if row.EndTime else '',
            'status': row.Status or 'Scheduled',
            'doctor': row.DoctorName, 'doctorId': row.DoctorCode,
            'service': row.ServiceName, 'room': row.Room or 'To be assigned'
        } for row in cursor.fetchall()]}
    except HTTPException:
        raise
    except Exception as error:
        print('My appointments database error:', repr(error))
        raise HTTPException(500, 'Unable to load appointments from SQL Server.')
    finally:
        conn.close()



class AppointmentReviewPayload(BaseModel):
    appointmentId: str = Field(min_length=9, max_length=30)
    rating: int = Field(ge=1, le=5)
    reviewText: str = Field(min_length=1, max_length=2000)


def appointment_review_table(cursor):
    cursor.execute("SELECT OBJECT_ID(N'dbo.TCMAppointmentReviews', N'U')")
    if cursor.fetchone()[0] is None:
        raise HTTPException(503, 'Appointment Review table missing. Create dbo.TCMAppointmentReviews in SSMS first.')


@app.get('/api/user/appointment-reviews')
def my_appointment_reviews(request: Request):
    user = require_user(request)
    conn = get_connection()
    try:
        cursor = conn.cursor()
        appointment_review_table(cursor)
        cursor.execute("SELECT COL_LENGTH(N'dbo.TCMAppointmentReviews', 'IsFeatured')")
        has_featured = cursor.fetchone()[0] is not None
        feature_expr = 'r.IsFeatured' if has_featured else 'CAST(0 AS BIT)'
        cursor.execute(f'''
            SELECT r.ReviewID, r.AppointmentID, r.Rating, r.ReviewText,
                   r.ReviewStatus, r.AdminReply, r.CreatedAt,
                   {feature_expr} AS IsFeatured,
                   a.AppointmentDate, s.ServiceName, d.FullName AS DoctorName
            FROM dbo.TCMAppointmentReviews r
            JOIN dbo.Appointments a ON a.AppointmentID = r.AppointmentID
            JOIN dbo.Services s ON a.ServiceID = s.ServiceID
            JOIN dbo.Doctors d ON a.DoctorID = d.DoctorID
            WHERE a.PatientID = ? ORDER BY {feature_expr} DESC, r.CreatedAt DESC, r.ReviewID DESC
        ''', int(user['id']))
        return {'reviews': [{
            'reviewId': row.ReviewID, 'appointmentId': f'APT-SQL-{row.AppointmentID}',
            'rating': row.Rating, 'featured': bool(row.IsFeatured), 'reviewText': row.ReviewText or '',
            'status': row.ReviewStatus, 'adminReply': row.AdminReply or '',
            'createdAt': row.CreatedAt.isoformat() if row.CreatedAt else '',
            'appointmentDate': str(row.AppointmentDate)[:10],
            'service': row.ServiceName, 'doctor': row.DoctorName
        } for row in cursor.fetchall()]}
    except HTTPException:
        raise
    except Exception as error:
        print('Appointment reviews load error:', repr(error))
        raise HTTPException(500, 'Could not load appointment reviews.') from error
    finally:
        conn.close()


@app.get('/api/user/appointment-reviews/public')
def public_appointment_reviews():
    conn = get_connection()
    try:
        cursor = conn.cursor()
        appointment_review_table(cursor)
        cursor.execute("SELECT COL_LENGTH(N'dbo.TCMAppointmentReviews', 'IsFeatured')")
        has_featured = cursor.fetchone()[0] is not None
        feature_expr = 'r.IsFeatured' if has_featured else 'CAST(0 AS BIT)'
        cursor.execute(f'''
            SELECT TOP (100) r.ReviewID, r.AppointmentID, r.Rating, r.ReviewText,
                   r.AdminReply, r.CreatedAt, s.ServiceName, d.FullName AS DoctorName,
                   {feature_expr} AS IsFeatured
            FROM dbo.TCMAppointmentReviews r
            JOIN dbo.Appointments a ON r.AppointmentID = a.AppointmentID
            JOIN dbo.Doctors d ON a.DoctorID = d.DoctorID
            JOIN dbo.Services s ON a.ServiceID = s.ServiceID
            WHERE r.ReviewStatus = 'Published'
            ORDER BY {feature_expr} DESC, r.CreatedAt DESC, r.ReviewID DESC
        ''')
        # This public route intentionally never exposes patient names, emails or IDs.
        return {'reviews': [{
            'reviewId': row.ReviewID, 'featured': bool(row.IsFeatured),
            'rating': row.Rating, 'reviewText': row.ReviewText or '',
            'adminReply': row.AdminReply or '',
            'createdAt': row.CreatedAt.isoformat() if row.CreatedAt else '',
            'service': row.ServiceName, 'doctor': row.DoctorName
        } for row in cursor.fetchall()]}
    except HTTPException:
        raise
    except Exception as error:
        print('Public appointment reviews error:', repr(error))
        raise HTTPException(500, 'Could not load reviews.') from error
    finally:
        conn.close()


@app.post('/api/user/appointment-reviews', status_code=201)
def submit_appointment_review(payload: AppointmentReviewPayload, request: Request):
    user = require_user(request)
    match = re.fullmatch(r'APT-SQL-([1-9][0-9]*)', payload.appointmentId)
    if not match:
        raise HTTPException(422, 'Invalid Booking ID.')
    text = payload.reviewText.strip()
    if not (1 <= len(text) <= 2000):
        raise HTTPException(422, 'Please write a review (maximum 2000 characters).')
    conn = get_connection()
    try:
        cursor = conn.cursor()
        appointment_review_table(cursor)
        appointment_id = int(match.group(1))
        cursor.execute('''
            SELECT AppointmentID, Status FROM dbo.Appointments WITH (UPDLOCK, HOLDLOCK)
            WHERE AppointmentID = ? AND PatientID = ?
        ''', appointment_id, int(user['id']))
        appointment = cursor.fetchone()
        if not appointment:
            raise HTTPException(404, 'This appointment was not found in your account.')
        if str(appointment.Status).lower() != 'completed':
            raise HTTPException(409, 'Only Completed appointments can be reviewed.')
        cursor.execute('SELECT ReviewID FROM dbo.TCMAppointmentReviews WHERE AppointmentID = ?', appointment_id)
        if cursor.fetchone():
            raise HTTPException(409, 'You have already reviewed this appointment.')
        cursor.execute('''
            INSERT INTO dbo.TCMAppointmentReviews
                (AppointmentID, Rating, ReviewText, ReviewStatus)
            OUTPUT INSERTED.ReviewID VALUES (?, ?, ?, 'Published')
        ''', appointment_id, payload.rating, text)
        new_id = cursor.fetchone()[0]
        conn.commit()
        return {'reviewId': int(new_id), 'appointmentId': payload.appointmentId, 'message': 'Review submitted.'}
    except HTTPException:
        conn.rollback()
        raise
    except Exception as error:
        conn.rollback()
        # The UNIQUE constraint also protects against concurrent duplicate submissions.
        if 'UQ_AppointmentReviews_Appointment' in str(error) or '2601' in str(error) or '2627' in str(error):
            raise HTTPException(409, 'You have already reviewed this appointment.') from error
        print('Submit appointment review error:', repr(error))
        raise HTTPException(500, 'Could not save review to SQL Server.') from error
    finally:
        conn.close()


@app.patch('/api/user/appointments/{appointment_id}/cancel')
def cancel_my_appointment(appointment_id: int, request: Request):
    user = require_user(request)
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE dbo.Appointments SET Status='Cancelled'
            OUTPUT INSERTED.AppointmentID
            WHERE AppointmentID=? AND PatientID=?
              AND Status IN ('Scheduled','Rescheduled')
              AND (AppointmentDate > CONVERT(DATE, SYSDATETIME())
                   OR (AppointmentDate = CONVERT(DATE, SYSDATETIME())
                       AND StartTime > CONVERT(TIME, SYSDATETIME())))
        ''', appointment_id, int(user['id']))
        row = cursor.fetchone()
        if not row:
            raise HTTPException(409, 'Appointment cannot be cancelled. It may already be in progress or closed.')
        conn.commit()
        return {'id': f'APT-SQL-{appointment_id}', 'status': 'Cancelled'}
    except HTTPException:
        conn.rollback()
        raise
    except Exception as error:
        conn.rollback()
        print('Appointment cancellation database error:', repr(error))
        raise HTTPException(500, 'Unable to cancel appointment.')
    finally:
        conn.close()


from tcm_messages import ensure_schema as ensure_chat_schema, list_threads as chat_list_threads, read_thread as chat_read_thread, send_message as chat_send_message


class UserChatPayload(BaseModel):
    text: str = Field(min_length=1, max_length=1000)


@app.get('/api/user/messages/threads')
def user_message_threads(request: Request):
    patient = require_user(request)
    conn = get_connection()
    try:
        cursor = conn.cursor()
        ensure_chat_schema(cursor)
        result = chat_list_threads(cursor, 'patient', int(patient['id']))
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.get('/api/user/messages/threads/{thread_id}')
def user_message_thread(thread_id: str, request: Request):
    patient = require_user(request)
    conn = get_connection()
    try:
        cursor = conn.cursor()
        ensure_chat_schema(cursor)
        result = chat_read_thread(cursor, 'patient', int(patient['id']), thread_id)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.post('/api/user/messages/threads/{thread_id}', status_code=201)
def user_message_send(thread_id: str, payload: UserChatPayload, request: Request):
    patient = require_user(request)
    conn = get_connection()
    try:
        cursor = conn.cursor()
        ensure_chat_schema(cursor)
        result = chat_send_message(cursor, 'patient', int(patient['id']), thread_id, payload.text)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
