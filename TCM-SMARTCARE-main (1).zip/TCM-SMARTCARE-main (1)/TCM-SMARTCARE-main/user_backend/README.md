# User Python backend (SQL not connected)

This separate FastAPI application follows the admin backend framework. It does
not import the admin backend, connect to SQL, create tables or need an ODBC driver.

From the project root, with Python 3.10 or newer:

```powershell
python -m venv user_backend/.venv
.\user_backend\.venv\Scripts\python.exe -m pip install -r user_backend/requirements.txt
.\user_backend\.venv\Scripts\python.exe -m uvicorn user_backend.app:app --reload --port 8001
```

Open http://127.0.0.1:8001/User/createaccount.html to register, then log in at
http://127.0.0.1:8001/User/login.html. Open pages through this server, not file://
or Live Server. The admin application can run separately on port 8000.

## Files and integration

- app.py: serves User pages and handles registration, login, sessions, profile,
  password change and logout. Login/register HTML form actions now call Python.
- repository.py: temporary account storage and the replacement point for SQL.
- requirements.txt: Python dependencies. No SQL package is required yet.
- __init__.py: marks this folder as a Python package.

Accounts and sessions are in memory ONLY. Restart/reload removes them. Use one
server worker. This is a development scaffold, not persistent storage.
Passwords are hashed with salted PBKDF2; API responses exclude hashes and salts.

API documentation: http://127.0.0.1:8001/docs

| Method | Path | Input |
| --- | --- | --- |
| GET | /api/user/health | Reports SQL disconnected |
| POST | /api/user/register | Existing registration form fields |
| POST | /api/user/login | Form identifier (email) and password |
| GET | /api/user/me | Session cookie |
| PUT | /api/user/profile | Profile JSON; see /docs |
| PUT | /api/user/password | current_password, new_password JSON |
| POST | /api/user/logout | Session cookie |

Registration and login are connected to Python. Login populates the existing
browser profile/name/email for compatibility. Other existing screens (including
profile saving, forgot-password, appointments, shop, messages and payments) still
use their original demo/browser behavior; their forms are not silently migrated.
Profile/password/logout API endpoints are available for later frontend wiring.
The existing email cannot be changed through the profile endpoint.

## Connect your own SQL later

Replace repository in repository.py with your SQL implementation of create,
find_by_email, find_by_id, update_profile and update_password. Preserve their
record shapes. Store the salt and password_hash as hex strings, and keep the
PBKDF2 SHA-256 iteration count (310000) consistent with app.py. Use parameterized
queries, an email uniqueness constraint and transactions. You choose your SQL
server, tables, driver and credentials; none are configured here. Move sessions
to persistent storage too if you need multiple workers or sessions across restarts.

The original PHP files and admin backend are unchanged. The two user form actions
now require this Python server (or routing these user API paths to this app).
