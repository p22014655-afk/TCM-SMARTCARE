import csv
import io
import json
import re
import os
import threading
from pathlib import Path
from urllib.request import Request, urlopen
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from html import escape

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from order_store import load_orders
from inventory_store import shop_products, reserve_products, deduct_products, require_inventory
from .db import get_connection

router = APIRouter(prefix="/api/user", tags=["Orders"])
MALAYSIA = timezone(timedelta(hours=8))
STATES = {
    "Johor", "Kedah", "Kelantan", "Melaka", "Negeri Sembilan",
    "Pahang", "Penang", "Perak", "Perlis", "Selangor",
    "Terengganu", "Kuala Lumpur", "Putrajaya"
}

class CartItem(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    quantity: int = Field(ge=1, le=99)


class PickupInfo(BaseModel):
    date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    time: str = Field(pattern=r"^([01]\d|2[0-3]):[0-5]\d$")


class DeliveryInfo(BaseModel):
    recipientName: str = Field(min_length=1, max_length=100)
    phoneNumber: str = Field(min_length=9, max_length=20)
    address: str = Field(min_length=5, max_length=500)
    city: str = Field(min_length=1, max_length=100)
    state: str = Field(min_length=1, max_length=50)
    postcode: str = Field(pattern=r"^\d{5}$")
    notes: str = Field(default="", max_length=500)


class CheckoutPayload(BaseModel):
    checkoutReference: str = Field(min_length=8, max_length=80)
    fulfillmentMethod: str = Field(pattern=r"^(pickup|delivery)$")
    paymentMethod: str = Field(pattern=r"^(fpx|card|tng-ewallet)$")
    bank: str = Field(default="", max_length=50)
    pickupInfo: PickupInfo | None = None
    deliveryInfo: DeliveryInfo | None = None
    items: list[CartItem] = Field(min_length=1, max_length=50)


def patient_id_from(request):
    from .app import require_user
    return int(require_user(request)["id"])


POSTCODE_CACHE = Path(__file__).with_name("west_malaysia_areas.json")
DELIVERY_AREAS = None


def get_delivery_areas():
    global DELIVERY_AREAS
    if DELIVERY_AREAS is None:
        try:
            areas = json.loads(POSTCODE_CACHE.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            print("Delivery Area Data Error:", repr(error))
            raise HTTPException(503, "West Malaysia postcode data file is missing or invalid.")
        if (
            not isinstance(areas, dict)
            or set(areas) != STATES
            or not all(isinstance(cities, dict) and cities for cities in areas.values())
            or sum(len(codes) for cities in areas.values() for codes in cities.values()) < 2000
        ):
            raise HTTPException(503, "West Malaysia postcode data is incomplete.")
        DELIVERY_AREAS = areas
    return DELIVERY_AREAS


@router.get("/delivery-areas")
def list_delivery_areas():
    areas = get_delivery_areas()
    return {
        "states": areas,
        "coverage": {
            "states": len(areas),
            "areas": sum(len(cities) for cities in areas.values()),
            "postcodeMappings": sum(len(codes) for cities in areas.values() for codes in cities.values())
        }
    }


def validate_fulfillment(payload):
    if payload.fulfillmentMethod == "pickup":
        if not payload.pickupInfo:
            raise HTTPException(422, "Please select pickup date and time.")
        try:
            pick_at = datetime.strptime(
                f"{payload.pickupInfo.date} {payload.pickupInfo.time}",
                "%Y-%m-%d %H:%M"
            ).replace(tzinfo=MALAYSIA)
        except ValueError:
            raise HTTPException(422, "Invalid pickup date or time.")
        now = datetime.now(MALAYSIA)
        if pick_at <= now or pick_at.date() > now.date() + timedelta(days=14):
            raise HTTPException(422, "Pickup must be within the next 14 days.")
        if not (
            (pick_at.hour == 20 and pick_at.minute == 0)
            or (7 <= pick_at.hour < 20 and pick_at.minute in (0, 30))
        ):
            raise HTTPException(422, "Pickup time must be 7 AM to 8 PM in 30-minute slots.")
        return pick_at.date(), pick_at.time(), None

    info = payload.deliveryInfo
    if info is None:
        raise HTTPException(422, "Please enter delivery information.")

    areas = get_delivery_areas()
    allowed = areas.get(info.state, {}).get(info.city, [])
    if info.state not in STATES or info.postcode not in allowed:
        raise HTTPException(422, "Selected postcode does not match the chosen state and city / area.")
    digits = re.sub(r"\D", "", info.phoneNumber)
    if not 9 <= len(digits) <= 12:
        raise HTTPException(422, "Invalid phone number.")
    return None, None, info


@router.get("/products")
def list_shop_products():
    connection = get_connection()
    try:
        products = shop_products(connection)
        cursor = connection.cursor()
        cursor.execute("""
            SELECT InventoryProductID, ProductName, Rating
            FROM dbo.TCMProductReviews
            WHERE Rating BETWEEN 1 AND 5 AND IsHidden = 0
        """)
        reviews = [
            (
                str(row.InventoryProductID or "").strip().casefold(),
                str(row.ProductName or "").strip().casefold(),
                int(row.Rating)
            )
            for row in cursor.fetchall()
        ]
        for product in products:
            product_id = str(product.get("id") or "").strip().casefold()
            product_name = str(product.get("name") or "").strip().casefold()
            ratings = [rating for rid, name, rating in reviews
                       if (product_id and rid == product_id) or name == product_name]
            product["reviewCount"] = len(ratings)
            product["averageRating"] = round(sum(ratings) / len(ratings), 1) if ratings else 0
        return {"products": products}
    finally:
        connection.close()


@router.get("/orders")
def my_orders(request: Request):
    patient_id = patient_id_from(request)
    connection = get_connection()
    try:
        return {"orders": load_orders(connection, patient_id=patient_id)}
    finally:
        connection.close()


@router.post("/orders", status_code=201)
def checkout(payload: CheckoutPayload, request: Request):
    patient_id = patient_id_from(request)
    pickup_date, pickup_time, recipient = validate_fulfillment(payload)
    names = [item.name.strip() for item in payload.items]
    if len({name.casefold() for name in names}) != len(names):
        raise HTTPException(422, "Duplicate product entries in cart.")
    connection = get_connection()
    try:
        require_inventory(connection)
        cursor = connection.cursor()
        cursor.execute("""
            SELECT OrderID, PatientID FROM dbo.TCMCheckoutOrders WITH (UPDLOCK, HOLDLOCK)
            WHERE CheckoutReference = ?
        """, payload.checkoutReference)
        existing = cursor.fetchone()
        if existing:
            if int(existing.PatientID) != patient_id:
                raise HTTPException(409, "Checkout reference is already in use.")
            old = load_orders(connection, patient_id=patient_id, order_id=int(existing.OrderID))
            if old and old[0]["status"] == "Cancelled":
                raise HTTPException(409, "This checkout was cancelled. Please start a new checkout.")
            return {"order": old[0]}
        selected_products, subtotal = reserve_products(cursor, payload.items)
        fee = Decimal("5.00") if recipient else Decimal("0.00")
        total = subtotal + fee
        if total > Decimal("99999999.99"):
            raise HTTPException(422, "Order total is too large.")
        address = recipient.address.strip() if recipient else None
        cursor.execute("""
            INSERT INTO dbo.TCMCheckoutOrders (
                PatientID, CheckoutReference, FulfillmentMethod, PickupDate,
                PickupTime, RecipientName, PhoneNumber, AddressLine,
                City, StateName, Postcode, DeliveryNotes, DeliveryFee,
                Subtotal, TotalAmount, PaymentMethod, BankName,
                PaymentStatus, Status, InventoryDeducted
            ) OUTPUT INSERTED.OrderID
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                    N'Simulated', N'Pending Packing', 1)
        """, patient_id, payload.checkoutReference, payload.fulfillmentMethod,
            pickup_date, pickup_time,
            recipient.recipientName.strip() if recipient else None,
            recipient.phoneNumber.strip() if recipient else None,
            address,
            recipient.city.strip() if recipient else None,
            recipient.state if recipient else None,
            recipient.postcode if recipient else None,
            recipient.notes.strip() if recipient else None,
            fee, subtotal, total,
            {"fpx": "FPX", "card": "Card", "tng-ewallet": "Touch 'n Go eWallet"}[payload.paymentMethod],
            payload.bank.strip() if payload.paymentMethod == "fpx" else None
        )
        order_id = int(cursor.fetchone()[0])
        prefix = "pu" if payload.fulfillmentMethod == "pickup" else "dy"
        tracking_id = f"{prefix}-{datetime.now(MALAYSIA):%Y%m%d}-{order_id:06d}"
        cursor.execute("""
            UPDATE dbo.TCMCheckoutOrders SET TrackingID = ? WHERE OrderID = ?
        """, tracking_id, order_id)
        deduct_products(cursor, selected_products)
        for item in selected_products:
            cursor.execute("""
                INSERT INTO dbo.TCMCheckoutItems
                    (OrderID, ProductName, Quantity, UnitPrice, InventoryProductID)
                VALUES (?, ?, ?, ?, ?)
            """, order_id, item["name"], item["quantity"], item["price"], item["id"])
        cursor.execute("""
            INSERT INTO dbo.TCMCheckoutEvents (OrderID, Status, Message)
            VALUES (?, N'Pending Packing', N'Your order has been received.')
        """, order_id)
        from tcm_notifications import record
        record(connection, 'patient', patient_id, 'order', f'Order #{order_id} · Pending Packing',
               'Your order has been received and is pending packing.',
               '/User/history.html', f'order:{order_id}:Pending Packing')
        connection.commit()
        result = load_orders(connection, patient_id=patient_id, order_id=order_id)
        return {"order": result[0]}
    except HTTPException:
        connection.rollback()
        raise
    except Exception as exc:
        connection.rollback()
        print("Checkout SQL error:", repr(exc))
        raise HTTPException(500, "Unable to save order. Check the SQL setup and Port 8001 terminal.")
    finally:
        connection.close()


def create_receipt(order):
    try:
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_CENTER
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    except ImportError:
        raise HTTPException(503, "Run: python -m pip install reportlab")

    import unicodedata
    from pathlib import Path

    regular_font = "Helvetica"
    bold_font = "Helvetica-Bold"

    candidates = [
        ("C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/msyhbd.ttc"),
        ("C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/simhei.ttf"),
        ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
        ("/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf", "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf"),
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
    ]

    for regular_path, bold_path in candidates:
        if not Path(regular_path).is_file():
            continue
        try:
            pdfmetrics.registerFont(TTFont("TCMReceiptRegular", regular_path))
            if Path(bold_path).is_file():
                pdfmetrics.registerFont(TTFont("TCMReceiptBold", bold_path))
                bold_font = "TCMReceiptBold"
            else:
                bold_font = "TCMReceiptRegular"
            regular_font = "TCMReceiptRegular"
            break
        except Exception:
            continue

    def clean_text(value):
        text = unicodedata.normalize("NFKC", str(value if value is not None else "-"))
        text = "".join(
            " " if unicodedata.category(char) in {"Cc", "Cf", "Cs"} or char in {"■", "□", "�"} else char
            for char in text
        )
        return " ".join(text.split()) or "-"

    data = io.BytesIO()
    doc = SimpleDocTemplate(
        data,
        pagesize=A4,
        leftMargin=45,
        rightMargin=45,
        topMargin=42,
        bottomMargin=42
    )

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="ReceiptTitleCustom",
        parent=styles["Heading1"],
        fontName=bold_font,
        alignment=TA_CENTER,
        fontSize=20,
        leading=25,
        textColor=colors.HexColor("#17585B")
    ))
    styles.add(ParagraphStyle(
        name="ReceiptNoteCustom",
        parent=styles["Normal"],
        fontName=regular_font,
        alignment=TA_CENTER,
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#17585B")
    ))
    styles.add(ParagraphStyle(
        name="ReceiptSmallCustom",
        parent=styles["Normal"],
        fontName=regular_font,
        fontSize=9,
        leading=14,
        wordWrap="CJK"
    ))

    def para(value):
        return Paragraph(escape(clean_text(value)), styles["ReceiptSmallCustom"])

    story = [
        Paragraph("TCM SMARTCARE+", styles["ReceiptTitleCustom"]),
        Spacer(1, 8),
        Paragraph("E-RECEIPT", styles["ReceiptNoteCustom"]),
        Spacer(1, 25)
    ]

    info = [
        ["Receipt / Order", order["orderNumber"]],
        ["Tracking ID", order["trackingId"]],
        ["Date", order["purchasedAt"]],
        ["Customer", order["buyer"]["name"]],
        ["Email", order["buyer"]["email"]],
        ["Payment method", order["paymentMethod"]],
        ["Payment status", "Simulated - no funds transferred"],
        ["Collection", order["fulfillmentMethod"].title()]
    ]

    if order["fulfillmentMethod"] == "pickup":
        info.append([
            "Pickup date/time",
            f"{order['pickupInfo']['date']} {order['pickupInfo']['time']}"
        ])
    else:
        details = order["deliveryInfo"]
        info.extend([
            ["Recipient", details["recipientName"]],
            ["Phone", details["phoneNumber"]],
            ["Delivery address", ", ".join(
                clean_text(value)
                for value in (
                    details["address"], details["city"],
                    details["state"], details["postcode"]
                ) if value
            )]
        ])

    data_table = Table(
        [[para(name), para(value)] for name, value in info],
        colWidths=[120, 380],
        hAlign="LEFT"
    )
    data_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
        ("LINEBELOW", (0, -1), (-1, -1), .5, colors.HexColor("#DCE8E6"))
    ]))
    story.extend([data_table, Spacer(1, 19)])

    item_rows = [["Product", "Qty", "Unit", "Amount"]]
    for item in order["items"]:
        item_rows.append([
            para(item["name"]),
            str(item["quantity"]),
            f"RM {item['price']:.2f}",
            f"RM {item['quantity'] * item['price']:.2f}"
        ])
    item_rows.extend([
        ["Subtotal", "", "", f"RM {order['subtotal']:.2f}"],
        ["Delivery fee", "", "", f"RM {order['deliveryFee']:.2f}"],
        ["Total", "", "", f"RM {order['total']:.2f}"]
    ])

    item_table = Table(
        item_rows,
        colWidths=[270, 50, 85, 95],
        repeatRows=1
    )
    item_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E6F1EF")),
        ("FONTNAME", (0, 0), (-1, 0), bold_font),
        ("FONTNAME", (0, -1), (-1, -1), bold_font),
        ("FONTNAME", (0, 1), (-1, -2), regular_font),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
        ("LINEBELOW", (0, -1), (-1, -1), .8, colors.HexColor("#17585B"))
    ]))
    story.extend([
        item_table,
        Spacer(1, 24),
        Paragraph(
            "Generated for system testing only. Not proof of payment.",
            styles["ReceiptNoteCustom"]
        )
    ])

    doc.build(story)
    data.seek(0)
    return data


@router.get("/orders/{order_id}/receipt")
def download_receipt(order_id: int, request: Request):
    patient_id = patient_id_from(request)
    connection = get_connection()
    try:
        orders = load_orders(connection, patient_id=patient_id, order_id=order_id)
    finally:
        connection.close()
    if not orders or orders[0]["status"] == "Cancelled":
        raise HTTPException(404, "Receipt is not available for cancelled orders.")
    contents = create_receipt(orders[0])
    return StreamingResponse(contents, media_type="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="TCM-Receipt-{order_id:06d}.pdf"',
        "Cache-Control": "private, no-store"
    })



class ReviewPayload(BaseModel):
    productName: str = Field(min_length=1, max_length=150)
    rating: int = Field(ge=1, le=5)
    comment: str = Field(min_length=1)


@router.get("/reviews")
def public_product_reviews(productId: str = "", productName: str = ""):
    connection = get_connection()
    try:
        cursor = connection.cursor()
        conditions = ["r.IsHidden = 0"]
        parameters = []
        if productId and productName:
            conditions.append("(r.InventoryProductID = ? OR LOWER(LTRIM(RTRIM(r.ProductName))) = LOWER(LTRIM(RTRIM(?))))")
            parameters.extend([productId, productName])
        elif productId:
            conditions.append("r.InventoryProductID = ?")
            parameters.append(productId)
        elif productName:
            conditions.append("LOWER(LTRIM(RTRIM(r.ProductName))) = LOWER(LTRIM(RTRIM(?)))")
            parameters.append(productName)
        where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
        cursor.execute("""
            SELECT TOP 500 r.ReviewID, r.ProductName, r.InventoryProductID,
                r.Rating, r.Comment, r.CreatedAt, r.EditedByStaffAt, p.FullName,
                r.IsFeatured, r.StaffReply
            FROM dbo.TCMProductReviews r
            JOIN dbo.Patients p ON p.PatientID = r.PatientID
        """ + where + " ORDER BY r.IsFeatured DESC, r.CreatedAt DESC, r.ReviewID DESC", *parameters)
        reviews = []
        for row in cursor.fetchall():
            words = str(row.FullName or "Customer").strip().split()
            display_name = words[0] + (" " + words[-1][0] + "." if len(words) > 1 else "")
            reviews.append({
                "reviewId": int(row.ReviewID),
                "productName": row.ProductName,
                "productId": row.InventoryProductID,
                "rating": int(row.Rating),
                "comment": row.Comment,
                "customerName": display_name,
                "editedByStaff": row.EditedByStaffAt is not None,
                "featured": bool(row.IsFeatured),
                "staffReply": str(row.StaffReply or ""),
                "createdAt": row.CreatedAt.isoformat()
            })
        return {"reviews": reviews}
    finally:
        connection.close()


@router.get("/reviews/mine")
def my_product_reviews(request: Request):
    patient_id = patient_id_from(request)
    connection = get_connection()
    try:
        cursor = connection.cursor()
        cursor.execute("""
            SELECT ReviewID, OrderID, ProductName, Rating, Comment, CreatedAt, IsHidden, EditedByStaffAt
            FROM dbo.TCMProductReviews
            WHERE PatientID = ?
            ORDER BY ReviewID DESC
        """, patient_id)
        return {"reviews": [
            {
                "reviewId": int(row.ReviewID),
                "orderId": int(row.OrderID),
                "productName": row.ProductName,
                "rating": int(row.Rating),
                "comment": row.Comment,
                "hidden": bool(row.IsHidden),
                "editedByStaff": row.EditedByStaffAt is not None,
                "createdAt": row.CreatedAt.isoformat()
            } for row in cursor.fetchall()
        ]}
    finally:
        connection.close()


@router.post("/orders/{order_id}/reviews", status_code=201)
def submit_product_review(order_id: int, payload: ReviewPayload, request: Request):
    patient_id = patient_id_from(request)
    name = payload.productName.strip()
    message = payload.comment.strip()
    if not message:
        raise HTTPException(422, "Please enter your review.")
    connection = get_connection()
    try:
        cursor = connection.cursor()
        cursor.execute("""
            SELECT Status FROM dbo.TCMCheckoutOrders WITH (UPDLOCK, HOLDLOCK)
            WHERE OrderID = ? AND PatientID = ?
        """, order_id, patient_id)
        order = cursor.fetchone()
        if order is None:
            raise HTTPException(404, "Order not found.")
        if order.Status != "Completed":
            raise HTTPException(409, "You can review products only after order completion.")
        cursor.execute("""
            SELECT TOP 1 ProductName, InventoryProductID
            FROM dbo.TCMCheckoutItems
            WHERE OrderID = ? AND ProductName = ?
        """, order_id, name)
        item = cursor.fetchone()
        if item is None:
            raise HTTPException(422, "The product is not part of this order.")
        cursor.execute("""
            SELECT 1 FROM dbo.TCMProductReviews WITH (UPDLOCK, HOLDLOCK)
            WHERE OrderID = ? AND ProductName = ?
        """, order_id, name)
        if cursor.fetchone():
            raise HTTPException(409, "You have already reviewed this product for this order.")
        cursor.execute("""
            INSERT INTO dbo.TCMProductReviews
                (OrderID, PatientID, ProductName, InventoryProductID, Rating, Comment)
            OUTPUT INSERTED.ReviewID
            VALUES (?, ?, ?, ?, ?, ?)
        """, order_id, patient_id, item.ProductName, item.InventoryProductID,
            payload.rating, message)
        review_id = int(cursor.fetchone()[0])
        connection.commit()
        return {"message": "Thank you for your review!", "reviewId": review_id}
    except HTTPException:
        connection.rollback()
        raise
    except Exception as error:
        connection.rollback()
        print("Review SQL error:", repr(error))
        raise HTTPException(500, "Unable to save review.")
    finally:
        connection.close()
