import hashlib
import hmac
import json
import os
import re
import secrets
import tempfile
import threading
import time
from collections import defaultdict, deque
from pathlib import Path
from urllib.parse import urlparse

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

OTP_LIFETIME = 180
VERIFIED_LIFETIME = 600
REQUESTS_PER_WINDOW = 10
REQUEST_WINDOW = 900
STATE_FILE = Path(os.getenv('TCM_OTP_STATE_FILE', str(Path(__file__).with_name('.local_password_otp_state.json'))))


class EmailRequest(BaseModel):
    email: str = Field(min_length=5, max_length=254)


class VerifyCode(BaseModel):
    challengeId: str = Field(min_length=10, max_length=256)
    otp: str = Field(pattern=r'^\d{6}$')


class ResetPassword(VerifyCode):
    newPassword: str = Field(min_length=8, max_length=1024)
    confirmPassword: str = Field(min_length=8, max_length=1024)


def create_reset_router(repository, digest, valid_password, sessions):
    router = APIRouter(prefix='/api/user/password-recovery', tags=['password-recovery'])
    lock = threading.RLock()

    def allow_only_local(request):
        hostname = (request.url.hostname or '').lower()
        client = (request.client.host or '').lower() if request.client else ''
        enabled = os.getenv('TCM_ENABLE_LOCAL_OTP', 'true').lower() == 'true'
        local = ('localhost', '127.0.0.1', '::1')
        if not enabled or hostname not in local or client not in local + ('testclient',):
            raise HTTPException(403, 'On-screen OTP is only available from localhost.')
        for header in ('origin', 'referer'):
            value = request.headers.get(header, '')
            if value and (urlparse(value).hostname or '').lower() not in local:
                raise HTTPException(403, 'On-screen OTP is only available from localhost.')

    def read_state():
        if not STATE_FILE.exists():
            return {'challenges': {}, 'requests': {}}
        try:
            data = json.loads(STATE_FILE.read_text(encoding='utf-8'))
            if not isinstance(data.get('challenges'), dict) or not isinstance(data.get('requests'), dict):
                raise ValueError('Invalid OTP state')
            return data
        except (OSError, ValueError, json.JSONDecodeError) as error:
            raise HTTPException(503, 'Cannot read the OTP temporary file. Check folder permissions.') from error

    def save_state(data):
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        filename = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=STATE_FILE.parent, prefix='.otp-', suffix='.tmp', delete=False) as handle:
                filename = handle.name
                json.dump(data, handle, separators=(',', ':'))
            os.replace(filename, STATE_FILE)
        except OSError as error:
            raise HTTPException(503, 'Cannot save OTP temporary file. Check folder permissions.') from error
        finally:
            if filename and os.path.exists(filename):
                os.unlink(filename)

    def cleanup(state, now):
        for token, item in list(state['challenges'].items()):
            deadline = item.get('verified_until', item['expires'])
            if deadline <= now and not item.get('resetting', False):
                state['challenges'].pop(token, None)
        for key, requests in list(state['requests'].items()):
            recent = [stamp for stamp in requests if stamp > now - REQUEST_WINDOW]
            if recent:
                state['requests'][key] = recent
            else:
                state['requests'].pop(key, None)

    @router.post('/start')
    def start(payload: EmailRequest, request: Request):
        allow_only_local(request)
        email = payload.email.strip().lower()
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
            raise HTTPException(422, 'Enter a valid email address.')
        now = time.time()
        code = f'{secrets.randbelow(1_000_000):06d}'
        challenge_id = secrets.token_urlsafe(32)
        with lock:
            state = read_state()
            cleanup(state, now)
            for key in ('email:' + email, 'ip:' + (request.client.host if request.client else '')):
                if len(state['requests'].get(key, [])) >= REQUESTS_PER_WINDOW:
                    raise HTTPException(429, 'Too many OTP requests. Try again in 15 minutes.')
            for key in ('email:' + email, 'ip:' + (request.client.host if request.client else '')):
                state['requests'].setdefault(key, []).append(now)
            for token, item in list(state['challenges'].items()):
                if item['email'] == email:
                    state['challenges'].pop(token, None)
            state['challenges'][challenge_id] = {
                'email': email,
                'hash': hashlib.sha256((challenge_id + code).encode()).hexdigest(),
                'expires': now + OTP_LIFETIME,
                'verified': False,
                'resetting': False,
            }
            save_state(state)
        return {'challengeId': challenge_id, 'otp': code, 'expiresIn': OTP_LIFETIME}

    @router.post('/verify')
    def verify(payload: VerifyCode, request: Request):
        allow_only_local(request)
        with lock:
            now = time.time()
            state = read_state()
            cleanup(state, now)
            entry = state['challenges'].get(payload.challengeId)
            if not entry:
                save_state(state)
                return {'verified': False, 'needNewOtp': True, 'message': 'OTP session was lost or replaced. Click Get OTP again.'}
            if not entry['verified'] and now >= entry['expires']:
                state['challenges'].pop(payload.challengeId, None)
                save_state(state)
                return {'verified': False, 'needNewOtp': True, 'message': 'OTP expired after 3 minutes. Click Get OTP again.'}
            if entry['verified']:
                remaining = entry['verified_until'] - now
                if remaining <= 0:
                    state['challenges'].pop(payload.challengeId, None)
                    save_state(state)
                    return {'verified': False, 'needNewOtp': True, 'message': 'OTP verification has expired. Click Get OTP again.'}
                return {'verified': True, 'resetExpiresIn': max(0, int(remaining))}
            candidate = hashlib.sha256((payload.challengeId + payload.otp).encode()).hexdigest()
            if not hmac.compare_digest(candidate, entry['hash']):
                state['challenges'].pop(payload.challengeId, None)
                save_state(state)
                return {'verified': False, 'needNewOtp': True, 'message': 'Incorrect OTP. Click Get OTP to receive a new code.'}
            entry['verified'] = True
            entry['verified_until'] = now + VERIFIED_LIFETIME
            save_state(state)
            return {'verified': True, 'resetExpiresIn': VERIFIED_LIFETIME}

    @router.post('/reset')
    def reset(payload: ResetPassword, request: Request):
        allow_only_local(request)
        if payload.newPassword != payload.confirmPassword:
            raise HTTPException(422, 'Passwords do not match. OTP is still verified.')
        if not valid_password(payload.newPassword):
            raise HTTPException(422, 'Use at least 8 characters, 4 numbers, 1 uppercase letter and 1 symbol. OTP is still verified.')

        with lock:
            now = time.time()
            state = read_state()
            cleanup(state, now)
            entry = state['challenges'].get(payload.challengeId)
            if not entry or not entry.get('verified') or entry.get('verified_until', 0) <= now:
                save_state(state)
                raise HTTPException(400, 'OTP verification expired. Click Get OTP again.')
            candidate = hashlib.sha256((payload.challengeId + payload.otp).encode()).hexdigest()
            if not hmac.compare_digest(candidate, entry['hash']):
                state['challenges'].pop(payload.challengeId, None)
                save_state(state)
                raise HTTPException(400, 'OTP mismatch. Click Get OTP again.')
            if entry.get('resetting'):
                raise HTTPException(409, 'Password update already in progress. Try again shortly.')
            entry['resetting'] = True
            save_state(state)
            email = entry['email']

        try:
            user = repository.find_by_email(email)
            if not user:
                raise HTTPException(404, 'This email is not registered. Check your email address.')
            user_id = user['id']
            if user.get('salt') and hmac.compare_digest(digest(payload.newPassword, user['salt']), user['password_hash']):
                raise HTTPException(422, 'New password must differ from your current password. OTP is still verified.')
            salt = secrets.token_hex(16)
            try:
                repository.update_password(user_id, salt, digest(payload.newPassword, salt), user['salt'] + '$' + user['password_hash'])
            except ValueError as error:
                raise HTTPException(409, 'Account password changed in another session. Please request a new OTP.') from error
        except HTTPException as error:
            with lock:
                state = read_state()
                current = state['challenges'].get(payload.challengeId)
                if current:
                    current['resetting'] = False
                    if error.status_code == 409 and 'request a new OTP' in str(error.detail):
                        state['challenges'].pop(payload.challengeId, None)
                    save_state(state)
            raise
        except Exception as error:
            with lock:
                state = read_state()
                current = state['challenges'].get(payload.challengeId)
                if current:
                    current['resetting'] = False
                    save_state(state)
            raise HTTPException(503, 'Could not save to SQL Server. You may retry with the verified OTP.') from error

        with lock:
            state = read_state()
            state['challenges'].pop(payload.challengeId, None)
            save_state(state)
        for key, session in list(sessions.items()):
            if session.get('user_id') == user_id:
                sessions.pop(key, None)
        return {'message': 'Password reset successfully. Please log in with your new password.'}

    return router
