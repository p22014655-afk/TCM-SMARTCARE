// Keep Dashboard and other patient headers synced with the active user's SQL profile.
(() => {
    const storageKey = "tcmPatientProfile";
    const avatarSelector = ".topbar .profile-top-link .patient-avatar";
    const nameSelector = ".topbar .profile-top-link strong";
    const greetingSelector = "#welcomeName";

    function avatarInitials(fullName) {
        return String(fullName || "Patient").trim().split(/\s+/).filter(Boolean)
            .slice(0, 2).map(word => word[0].toUpperCase()).join("") || "P";
    }

    function currentCache() {
        try {
            const value = JSON.parse(localStorage.getItem(storageKey) || "{}");
            const signedInEmail = (sessionStorage.getItem("tcmPatientEmail") || "").trim().toLowerCase();
            if (!signedInEmail || !value || typeof value !== "object" ||
                String(value.email || "").trim().toLowerCase() !== signedInEmail) return null;
            return value;
        } catch (_) {
            return null;
        }
    }

    function renderProfile(profile) {
        if (!profile) return;
        const name = String(profile.fullName || "").trim();
        const avatar = document.querySelector(avatarSelector);
        const headerName = document.querySelector(nameSelector);
        const greetingName = document.querySelector(greetingSelector);
        if (headerName && name) headerName.textContent = name;
        if (greetingName && name) greetingName.textContent = name;
        if (!avatar) return;

        const photo = String(profile.photo || "");
        if (/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/i.test(photo)) {
            avatar.textContent = "";
            avatar.classList.add("profile-image");
            avatar.style.backgroundImage = `url("${photo}")`;
            avatar.style.backgroundSize = "cover";
            avatar.style.backgroundPosition = "center";
            avatar.style.backgroundRepeat = "no-repeat";
        } else {
            avatar.classList.remove("profile-image");
            avatar.style.backgroundImage = "";
            avatar.textContent = avatarInitials(name);
        }
    }

    let pending = null;
    async function refreshFromSql() {
        if (pending) return pending;
        pending = (async () => {
            try {
                const response = await fetch("/api/user/me", {
                    credentials: "same-origin",
                    cache: "no-store"
                });
                if (!response.ok) return;
                const result = await response.json();
                const user = result && result.user;
                if (!user || !user.id) return;
                // SQL Server is authoritative. Never substitute another user's cached photo.
                localStorage.setItem(storageKey, JSON.stringify(user));
                if (user.fullName) sessionStorage.setItem("tcmPatientName", user.fullName);
                if (user.email) sessionStorage.setItem("tcmPatientEmail", user.email);
                renderProfile(user);
            } catch (error) {
                console.warn("Could not refresh the patient profile.", error);
            }
        })();
        try { await pending; } finally { pending = null; }
    }

    function init() {
        const cached = currentCache();
        if (cached) renderProfile(cached);
        else {
            const signedInName = sessionStorage.getItem("tcmPatientName") || "";
            if (signedInName) renderProfile({fullName: signedInName, photo: ""});
        }
        refreshFromSql();
        // The Profile can be edited in another tab. Refresh when returning here.
        window.addEventListener("pageshow", refreshFromSql);
        document.addEventListener("visibilitychange", () => {
            if (!document.hidden) refreshFromSql();
        });
        window.addEventListener("storage", event => {
            if (event.key === storageKey) {
                const updated = currentCache();
                if (updated) renderProfile(updated);
                refreshFromSql();
            }
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();

/* Avatar lightbox: preview only. No changes to any uploaded or saved photos. */
(() => {
    if (window.__tcmAvatarZoomInstalled) return;
    window.__tcmAvatarZoomInstalled = true;
    const isAdminPortal = document.body?.classList.contains("admin-shell") ||
        document.querySelector(".admin-shell") !== null;
    const selector = isAdminPortal
        ? ["#adminAvatar", ".account-person .avatar", ".person-cell .avatar",
           ".patient-profile-head .avatar", ".admin-profile-photo-preview",
           "#doctorPicturePreview", "#scheduleDoctorAvatar", ".admin-conversation-avatar"].join(", ")
        : [".patient-avatar", ".practitioner-photo", ".doctor-modal-avatar",
           "#profilePreview", ".conversation-avatar"].join(", ");
    let overlay = null;
    let previousFocus = null;

    function findName(el) {
        const img = el.matches("img") ? el : el.querySelector("img");
        const card = el.closest(".practitioner-card, .account-person, .person-cell, .patient-profile-head, .chat-heading");
        const nearby = card?.querySelector("h3, h2, strong")?.textContent?.trim();
        if (nearby) return nearby;
        if (el.id === "doctorModalAvatar") return document.getElementById("doctorModalName")?.textContent?.trim() || "Practitioner";
        if (el.id === "adminAvatar") return document.getElementById("adminName")?.textContent?.trim() || "Profile picture";
        if (el.classList.contains("patient-avatar") || el.id === "profilePreview") {
            return document.querySelector(".topbar .profile-top-link strong")?.textContent?.trim() ||
                document.getElementById("fullName")?.value?.trim() || "Profile picture";
        }
        return img?.alt?.trim() || el.getAttribute("aria-label") || "Profile picture";
    }

    function photoSource(el) {
        const image = el.matches("img") ? el : el.querySelector("img");
        if (image?.getAttribute("src") && getComputedStyle(image).visibility !== "hidden") {
            return image.currentSrc || image.src;
        }
        const style = getComputedStyle(el).backgroundImage;
        if (style && style !== "none") {
            const match = /^url\(["']?(.*?)["']?\)$/.exec(style);
            if (match) return match[1];
        }
        return "";
    }

    function dismiss() {
        if (!overlay) return;
        overlay.remove();
        overlay = null;
        previousFocus?.isConnected && previousFocus.focus({preventScroll: true});
        previousFocus = null;
    }

    function show(el) {
        dismiss();
        previousFocus = document.activeElement;
        const name = findName(el);
        const src = photoSource(el);
        overlay = document.createElement("div");
        overlay.id = "tcm-avatar-zoom";
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-modal", "true");
        overlay.setAttribute("aria-label", `${name} enlarged profile picture`);
        const panel = document.createElement("div");
        panel.className = "tcm-avatar-zoom-panel";
        const close = document.createElement("button");
        close.type = "button";
        close.className = "tcm-avatar-zoom-close";
        close.setAttribute("aria-label", "Close enlarged picture");
        close.textContent = "×";
        const circle = document.createElement("div");
        circle.className = "tcm-avatar-zoom-circle";
        if (src) {
            const image = document.createElement("img");
            image.src = src;
            image.alt = `${name} profile picture`;
            image.onerror = () => { circle.replaceChildren(); circle.textContent = el.textContent.trim() || "?"; };
            circle.appendChild(image);
        } else {
            circle.textContent = el.textContent.trim() || "?";
        }
        const caption = document.createElement("p");
        caption.className = "tcm-avatar-zoom-name";
        caption.textContent = name;
        panel.append(close, circle, caption);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);
        close.addEventListener("click", dismiss);
        overlay.addEventListener("click", e => { if (e.target === overlay) dismiss(); });
        close.focus({preventScroll: true});
    }

    const css = document.createElement("style");
    css.id = "tcm-avatar-zoom-style";
    css.textContent = `
        ${selector} { cursor: zoom-in !important; }
        ${selector}:focus-visible { outline: 3px solid #328d83 !important; outline-offset: 3px; }
        #tcm-avatar-zoom { position: fixed; inset: 0; z-index: 2147483000;
            background: rgba(12,38,39,.78); display: flex; align-items: center;
            justify-content: center; padding: 20px; box-sizing: border-box; }
        #tcm-avatar-zoom .tcm-avatar-zoom-panel { box-sizing: border-box;
            position: relative; display: flex; align-items: center; flex-direction: column;
            gap: 16px; width: min(440px, 100%); max-height: 95vh;
            padding: 50px 20px 26px; border-radius: 18px; background: #fff;
            box-shadow: 0 18px 60px rgba(0,0,0,.35); }
        #tcm-avatar-zoom .tcm-avatar-zoom-close { position: absolute; top: 12px; right: 14px;
            border: 0; border-radius: 50%; width: 38px; height: 38px;
            display: grid; place-items: center; background: #edf5f2; color: #184f4b;
            font: normal 28px/1 system-ui,sans-serif; cursor: pointer; }
        #tcm-avatar-zoom .tcm-avatar-zoom-close:hover { background: #d9ebe6; }
        #tcm-avatar-zoom .tcm-avatar-zoom-circle { width: min(320px, 70vw, 52vh);
            height: min(320px, 70vw, 52vh); border-radius: 50%; overflow: hidden;
            display: flex; align-items: center; justify-content: center;
            background: #dcece7; color: #205d5a;
            font: 700 clamp(48px, 12vw, 100px)/1 system-ui,sans-serif; }
        #tcm-avatar-zoom .tcm-avatar-zoom-circle img { width: 100%; height: 100%;
            object-fit: cover; display: block; }
        #tcm-avatar-zoom .tcm-avatar-zoom-name { margin: 0;
            font: 700 17px/1.4 system-ui,sans-serif; text-align: center; color: #153c39; }
    `;
    document.head.appendChild(css);

    // Capture clicks before the photo's enclosing profile or doctor-card handler.
    document.addEventListener("click", event => {
        if (overlay && event.target.closest("#tcm-avatar-zoom")) return;
        const el = event.target instanceof Element ? event.target.closest(selector) : null;
        if (!el) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        show(el);
    }, true);
    document.addEventListener("keydown", event => {
        if (overlay && event.key === "Escape") {
            event.preventDefault(); event.stopImmediatePropagation(); dismiss(); return;
        }
        if (event.key !== "Enter" && event.key !== " ") return;
        const el = document.activeElement;
        if (!(el instanceof Element) || !el.matches(selector)) return;
        event.preventDefault(); event.stopImmediatePropagation(); show(el);
    }, true);

    const enhance = () => document.querySelectorAll(selector).forEach(el => {
        if (el.tabIndex < 0) el.tabIndex = 0;
        if (!el.hasAttribute("role")) el.setAttribute("role", "button");
        if (!el.getAttribute("title")) el.setAttribute("title", "Click to enlarge picture");
    });
    const initialize = () => {
        enhance();
        let scheduled = false;
        const observer = new MutationObserver(() => {
            if (scheduled) return;
            scheduled = true;
            requestAnimationFrame(() => { scheduled = false; enhance(); });
        });
        observer.observe(document.body, {childList: true, subtree: true});
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialize);
    else initialize();
})();
