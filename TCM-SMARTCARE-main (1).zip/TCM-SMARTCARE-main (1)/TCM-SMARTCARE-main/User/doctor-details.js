const doctorModal = document.getElementById("doctorModal");
const doctorDescriptions = {
    "dr-lim": "General TCM consultation and acupuncture treatments.",
    "dr-tan": "Tuina therapy, general TCM consultation and women's wellness.",
    "dr-wong": "Acupuncture and cupping therapy treatments."
};

function openDoctorDetails(card) {
    if (!doctorModal) return;
    const name = card.querySelector("h3")?.textContent.trim() || "Practitioner";
    const role = card.querySelector(".practitioner-details > p")?.textContent.trim() || "TCM Practitioner";
    const doctorCode = card.dataset.doctorId || "";
    const services = [...card.querySelectorAll(".treatment-tag")]
        .map(tag => tag.textContent.replace(/^✓\s*/, "").trim())
        .filter(value => value && value !== "Services pending setup");
    document.getElementById("doctorModalName").textContent = name;
    document.getElementById("doctorModalRole").textContent = role;
    const modalAvatar = document.getElementById("doctorModalAvatar");
    const cardAvatar = card.querySelector(".practitioner-photo");
    const cardPhoto = cardAvatar?.querySelector("img.practitioner-profile-image");
    modalAvatar.replaceChildren();
    if (cardPhoto) {
        const image = document.createElement("img");
        image.src = cardPhoto.src;
        image.alt = `${name} profile picture`;
        image.style.cssText = "width:100%;height:100%;object-fit:cover;border-radius:50%;";
        modalAvatar.appendChild(image);
    } else {
        modalAvatar.textContent = cardAvatar?.textContent || "DR";
    }
    document.getElementById("doctorModalDescription").textContent =
        doctorDescriptions[doctorCode] || `${name} is part of the TCM SmartCare+ clinical team. Appointment times and available treatments are managed by clinic staff.`;
    const container = document.getElementById("doctorModalServices");
    container.replaceChildren();
    services.forEach(name => {
        const tag = document.createElement("span");
        tag.textContent = name;
        container.append(tag);
    });
    document.getElementById("doctorMessageLink").href =
        `messages.html?doctor=${encodeURIComponent(doctorCode)}`;
    doctorModal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    doctorModal.querySelector(".doctor-modal-close")?.focus();
}

function closeDoctorDetails() {
    if (!doctorModal) return;
    doctorModal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
}

// Only the doctor's name button opens this modal, not the full doctor card.
// Service pills and time buttons have separate booking actions.
document.querySelector(".practitioner-list")?.addEventListener("click", event => {
    const nameButton = event.target.closest(".doctor-name-trigger");
    if (!nameButton) return;
    const card = nameButton.closest(".practitioner-card");
    if (card) openDoctorDetails(card);
});

doctorModal?.querySelectorAll("[data-close-doctor-modal]").forEach(button =>
    button.addEventListener("click", closeDoctorDetails));

document.addEventListener("keydown", event => {
    if (event.key === "Escape" && doctorModal?.getAttribute("aria-hidden") === "false") {
        closeDoctorDetails();
    }
});
