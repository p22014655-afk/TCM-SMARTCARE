(() => {
    const cartKey = "tcmCart";
    const pendingPaymentKey = "tcmPendingPayment";
    const deliveryCharge = 5;
    const form = document.getElementById("paymentForm");
    const bankField = document.getElementById("bankField");
    const bankSelect = document.getElementById("bankSelect");
    const status = document.getElementById("paymentStatus");
    const payButton = document.getElementById("payButton");
    const orderItems = document.getElementById("orderItems");
    const orderTotal = document.getElementById("orderTotal");
    const subtotalText = document.getElementById("productSubtotal");
    const feeRow = document.getElementById("deliveryFeeRow");
    const pickupPanel = document.getElementById("pickupInformation");
    const deliveryPanel = document.getElementById("deliveryInformation");
    const methodText = document.getElementById("collectionMethodText");
    const pickupDate = document.getElementById("pickupDate");
    const pickupTime = document.getElementById("pickupTime");
    const deliveryState = document.getElementById("deliveryState");
    const deliveryCity = document.getElementById("deliveryCity");
    const deliveryPostcode = document.getElementById("deliveryPostcode");
    const deliveryLocationStatus = document.getElementById("deliveryLocationStatus");
    const retryDeliveryAreas = document.getElementById("retryDeliveryAreas");
    let deliveryLocations = null;
    let locationsLoading = false;
    
    function formatPickupDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }

    function setPickupDateRange() {
        const today = new Date();
        const lastDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 14);
        pickupDate.min = formatPickupDate(today);
        pickupDate.max = formatPickupDate(lastDate);

        if (pickupDate.value && (pickupDate.value < pickupDate.min || pickupDate.value > pickupDate.max)) {
            pickupDate.value = "";
            pickupTime.value = "";
        }
    }

    function updatePickupTimeOptions() {
        const previous = pickupTime.value;
        pickupTime.replaceChildren(new Option("Select Pickup Time", ""));
        const selectedDate = pickupDate.value;

        if (!selectedDate || selectedDate < pickupDate.min || selectedDate > pickupDate.max) {
            pickupTime.value = "";
            return;
        }

        const now = new Date();
        const todayString = formatPickupDate(now);

        for (let minutes = 7 * 60; minutes <= 20 * 60; minutes += 30) {
            const hour = Math.floor(minutes / 60);
            const minute = minutes % 60;
            const value = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;

            if (selectedDate === todayString && new Date(`${selectedDate}T${value}:00`) <= now) {
                continue;
            }

            const period = hour >= 12 ? "PM" : "AM";
            const displayHour = hour % 12 || 12;
            const label = `${displayHour}:${String(minute).padStart(2, "0")} ${period}`;
            pickupTime.add(new Option(label, value));
        }

        if (Array.from(pickupTime.options).some(option => option.value === previous && previous)) {
            pickupTime.value = previous;
        } else {
            pickupTime.value = "";
        }
    }

    setPickupDateRange();
    updatePickupTimeOptions();

    pickupDate.addEventListener("change", () => {
        setPickupDateRange();
        pickupTime.value = "";
        updatePickupTimeOptions();
    });

    pickupDate.addEventListener("focus", setPickupDateRange);
    pickupDate.addEventListener("click", setPickupDateRange);

    const deliveryFields = ["recipientName", "deliveryPhone", "deliveryAddress", "deliveryCity", "deliveryState", "deliveryPostcode", "deliveryNotes"];
    function resetSelect(element, placeholder, values = []) {
        element.replaceChildren(new Option(placeholder, ""));
        values.forEach(item => element.add(new Option(item, item)));
        element.value = "";
    }

    function refreshDeliveryDropdowns() {
        const isDelivery = chosen("fulfillmentMethod") === "delivery";
        const cities = deliveryLocations?.[deliveryState.value] || null;
        const postcodes = cities?.[deliveryCity.value] || null;
        deliveryState.disabled = !isDelivery || !deliveryLocations;
        deliveryCity.disabled = !isDelivery || !cities;
        deliveryPostcode.disabled = !isDelivery || !postcodes;
    }

    async function loadDeliveryLocations() {
        if (deliveryLocations || locationsLoading) return;
        locationsLoading = true;
        retryDeliveryAreas.hidden = true;
        deliveryLocationStatus.textContent = "Loading available delivery areas...";
        resetSelect(deliveryState, "Loading states...");
        resetSelect(deliveryCity, "Select state first");
        resetSelect(deliveryPostcode, "Select city / area first");
        refreshDeliveryDropdowns();
        try {
            const response = await fetch("/api/user/delivery-areas", {
                credentials: "same-origin",
                cache: "no-store"
            });
            const result = await response.json();
            if (!response.ok || !result.states || typeof result.states !== "object") {
                throw new Error(result.detail || "Unable to load delivery areas.");
            }
            deliveryLocations = result.states;
            resetSelect(deliveryState, "Select West Malaysia State", Object.keys(deliveryLocations).sort());
            const coverage = result.coverage;
            deliveryLocationStatus.textContent = coverage
                ? `West Malaysia only: ${coverage.states} states, ${coverage.areas} cities / areas. Select state, area and matching postcode.`
                : "Select state, city / area and matching postcode.";
        } catch (error) {
            resetSelect(deliveryState, "Delivery areas unavailable");
            deliveryLocationStatus.textContent = error.message;
            retryDeliveryAreas.hidden = false;
        } finally {
            locationsLoading = false;
            refreshDeliveryDropdowns();
        }
    }

    retryDeliveryAreas.addEventListener("click", loadDeliveryLocations);

    deliveryState.addEventListener("change", () => {
        const cityNames = Object.keys(deliveryLocations?.[deliveryState.value] || {}).sort();
        resetSelect(deliveryCity, cityNames.length ? "Select City / Area" : "Select state first", cityNames);
        resetSelect(deliveryPostcode, "Select city / area first");
        refreshDeliveryDropdowns();
    });

    deliveryCity.addEventListener("change", () => {
        const codes = deliveryLocations?.[deliveryState.value]?.[deliveryCity.value] || [];
        resetSelect(deliveryPostcode, codes.length ? "Select Postcode" : "Select city / area first", codes);
        refreshDeliveryDropdowns();
    });
    const price = (number) => `RM ${Number(number).toFixed(2)}`;
    const value = (id) => document.getElementById(id).value.trim();
    const chosen = (name) => form.querySelector(`input[name="${name}"]:checked`)?.value || "";

    function readCart() {
        try {
            const value = JSON.parse(localStorage.getItem(cartKey) || "[]");
            if (!Array.isArray(value)) return [];
            return value.filter(item => item && typeof item.name === "string" && Number.isFinite(Number(item.price)) && Number(item.price) >= 0 && Number.isInteger(Number(item.quantity)) && Number(item.quantity) > 0 && Number(item.quantity) <= 99);
        } catch {
            return [];
        }
    }

    const cart = readCart();
    let subtotal = 0;

    function renderCartPrices() {
        orderItems.replaceChildren();
        subtotal = 0;
        for (const item of cart) {
            const line = document.createElement("div");
            line.className = "order-line";
            const name = document.createElement("span");
            name.textContent = `${item.name} × ${item.quantity}`;
            const amount = document.createElement("span");
            const lineAmount = Number(item.price) * Number(item.quantity);
            subtotal += lineAmount;
            amount.textContent = price(lineAmount);
            line.append(name, amount);
            orderItems.append(line);
        }
        subtotalText.textContent = price(subtotal);
        amounts();
    }

    async function verifyCartStock() {
        const response = await fetch("/api/user/products", {
            credentials: "same-origin",
            cache: "no-store"
        });
        const result = await response.json();
        if (!response.ok || !Array.isArray(result.products)) {
            throw new Error(result.detail || "Unable to check product stock.");
        }
        const catalog = new Map(result.products.map(product => [
            String(product.name).trim().toLowerCase(), product
        ]));
        let changed = false;
        for (const item of cart) {
            const product = catalog.get(String(item.name).trim().toLowerCase());
            if (!product) {
                throw new Error(`${item.name} is no longer available.`);
            }
            if (Number(item.quantity) > Number(product.stock)) {
                throw new Error(`${item.name} has only ${product.stock} unit(s) left. Please update your cart.`);
            }
            if (Number(item.price) !== Number(product.price)) {
                item.price = Number(product.price);
                changed = true;
            }
        }
        if (changed) {
            localStorage.setItem(cartKey, JSON.stringify(cart));
            renderCartPrices();
            throw new Error("Product prices have been updated. Please review the new total and click Confirm payment again.");
        }
    }

    renderCartPrices();

    function amounts() {
        const fee = chosen("fulfillmentMethod") === "delivery" ? deliveryCharge : 0;
        orderTotal.textContent = price(subtotal + fee);
        feeRow.hidden = !fee;
        return { subtotal, deliveryFee: fee, total: subtotal + fee };
    }

    function updateFulfillment() {
        const pickup = chosen("fulfillmentMethod") === "pickup";
        const delivery = chosen("fulfillmentMethod") === "delivery";
        pickupPanel.hidden = !pickup;
        deliveryPanel.hidden = !delivery;
        pickupDate.disabled = !pickup;
        pickupTime.disabled = !pickup;
        pickupDate.required = pickup;
        pickupTime.required = pickup;
        for (const id of deliveryFields) {
            const field = document.getElementById(id);
            field.disabled = !delivery;
            field.required = delivery && id !== "deliveryNotes";
        }
        refreshDeliveryDropdowns();
        if (delivery) loadDeliveryLocations();
        methodText.textContent = pickup ? "Pickup" : delivery ? "Delivery" : "Not selected";
        amounts();
    }

    function updatePayment() {
        const fpx = chosen("paymentMethod") === "fpx";
        bankField.hidden = !fpx;
        bankSelect.disabled = !fpx;
        bankSelect.required = fpx;
    }

    form.querySelectorAll('input[name="fulfillmentMethod"]').forEach(radio => radio.addEventListener("change", updateFulfillment));
    form.querySelectorAll('input[name="paymentMethod"]').forEach(radio => radio.addEventListener("change", updatePayment));
    updateFulfillment();
    updatePayment();

    if (!cart.length) {
        form.hidden = true;
        status.textContent = "Your cart is empty. Please add products first.";
    }

    form.addEventListener("submit", async event => {
        event.preventDefault();
        status.textContent = "";
        const fulfillmentMethod = chosen("fulfillmentMethod");
        const paymentMethod = chosen("paymentMethod");
        if (!["pickup", "delivery"].includes(fulfillmentMethod)) {
            status.textContent = "Please select Pickup or Delivery.";
            return;
        }
        if (!["fpx", "card", "tng-ewallet"].includes(paymentMethod)) {
            status.textContent = "Please select a payment method.";
            return;
        }
        if (paymentMethod === "fpx" && !bankSelect.value) {
            status.textContent = "Please select your bank.";
            return;
        }
        let pickupInfo = null;
        let deliveryInfo = null;
        if (fulfillmentMethod === "pickup") {
            setPickupDateRange();
            updatePickupTimeOptions();

            if (!pickupDate.value || !pickupTime.value) {
                status.textContent = "Please select a pickup date and time.";
                return;
            }

            if (pickupDate.value < pickupDate.min || pickupDate.value > pickupDate.max) {
                status.textContent = "Pickup date must be within the next 14 days.";
                return;
            }

            const selectedTime = pickupTime.value;
            const available = Array.from(pickupTime.options).some(
                option => option.value === selectedTime && selectedTime !== ""
            );

            if (!available) {
                status.textContent = "Please select an available pickup time.";
                return;
            }

            const pickupAt = new Date(`${pickupDate.value}T${selectedTime}:00`);
            if (Number.isNaN(pickupAt.getTime()) || pickupAt <= new Date()) {
                status.textContent = "Please choose a future pickup date and time.";
                return;
            }

            pickupInfo = { date: pickupDate.value, time: selectedTime };
        } else {
            deliveryInfo = {
                recipientName: value("recipientName"),
                phoneNumber: value("deliveryPhone"),
                address: value("deliveryAddress"),
                city: value("deliveryCity"),
                state: value("deliveryState"),
                postcode: value("deliveryPostcode"),
                notes: value("deliveryNotes")
            };
            if (!deliveryInfo.recipientName || !deliveryInfo.phoneNumber || !deliveryInfo.address || !deliveryInfo.city || !deliveryInfo.state || !deliveryInfo.postcode) {
                status.textContent = "Please fill in all required delivery information.";
                return;
            }
            const digits = deliveryInfo.phoneNumber.replace(/\D/g, "");
            if (digits.length < 9 || digits.length > 12) {
                status.textContent = "Please enter a valid Malaysian phone number.";
                return;
            }
            const allowedPostcodes = deliveryLocations?.[deliveryInfo.state]?.[deliveryInfo.city];
            if (!Array.isArray(allowedPostcodes) || !allowedPostcodes.includes(deliveryInfo.postcode)) {
                status.textContent = "This postcode does not match the selected state and city / area.";
                return;
            }
        }
        if (!form.reportValidity()) return;
        payButton.disabled = true;
        try {
            await verifyCartStock();
        } catch (error) {
            status.textContent = error.message;
            payButton.disabled = false;
            return;
        }
        const checkoutFingerprint = JSON.stringify({cart, fulfillmentMethod, pickupInfo, deliveryInfo, paymentMethod, bank: bankSelect.value});
        let checkoutReference = crypto.randomUUID();
        try {
            const previous = JSON.parse(sessionStorage.getItem("tcmCheckoutReference") || "null");
            if (previous?.fingerprint === checkoutFingerprint && previous?.reference) {
                checkoutReference = previous.reference;
            } else {
                sessionStorage.setItem("tcmCheckoutReference", JSON.stringify({fingerprint: checkoutFingerprint, reference: checkoutReference}));
            }
        } catch {
            sessionStorage.setItem("tcmCheckoutReference", JSON.stringify({fingerprint: checkoutFingerprint, reference: checkoutReference}));
        }
        const checkout = {
            checkoutReference,
            fulfillmentMethod,
            pickupInfo,
            deliveryInfo,
            paymentMethod,
            method: paymentMethod,
            bank: paymentMethod === "fpx" ? bankSelect.value : "",
            ...amounts(),
            items: cart,
            createdAt: new Date().toISOString()
        };
        payButton.disabled = true;
        try {
            sessionStorage.setItem(pendingPaymentKey, JSON.stringify(checkout));
            window.location.href = paymentMethod === "card" ? "card-demo.html" : "demo-payment.html";
        } catch {
            payButton.disabled = false;
            status.textContent = "Unable to start checkout. Check browser storage.";
        }
    });

    document.getElementById("menuButton")?.addEventListener("click", () => {
        document.querySelector(".sidebar")?.classList.toggle("open");
    });
})();