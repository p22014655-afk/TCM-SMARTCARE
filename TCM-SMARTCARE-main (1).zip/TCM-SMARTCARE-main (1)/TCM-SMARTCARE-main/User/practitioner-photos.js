(() => {
    const cards = Array.from(document.querySelectorAll(".team-card[data-practitioner-name]"));
    if (!cards.length) return;

    const normalize = value => String(value || "")
        .normalize("NFKC")
        .replace(/^dr\.?\s+/i, "")
        .trim()
        .replace(/\s+/g, " ")
        .toLocaleLowerCase();
    const isPhoto = value => typeof value === "string" &&
        value.length < 350000 &&
        /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(value);
    const originalInitials = new Map(cards.map(card => [card, card.querySelector("[data-practitioner-avatar]").textContent.trim()]));
    const shownPhotos = new Map();
    let loading = false;
    let dialog = null;
    let lastFocus = null;

    function getDialog() {
        if (dialog) return dialog;
        dialog = document.createElement("div");
        dialog.id = "practitioner-photo-dialog";
        dialog.hidden = true;
        dialog.setAttribute("role", "dialog");
        dialog.setAttribute("aria-modal", "true");
        dialog.setAttribute("aria-label", "Doctor profile picture");

        const panel = document.createElement("div");
        panel.className = "practitioner-zoom-panel";
        const close = document.createElement("button");
        close.type = "button";
        close.className = "practitioner-zoom-close";
        close.textContent = "×";
        close.setAttribute("aria-label", "Close photo");
        const image = document.createElement("img");
        image.className = "practitioner-zoom-photo";
        const name = document.createElement("p");
        name.className = "practitioner-zoom-name";
        const caption = document.createElement("p");
        caption.className = "practitioner-zoom-caption";
        caption.textContent = "TCM SmartCare+ Practitioner";
        panel.append(close, image, name, caption);
        dialog.append(panel);
        document.body.append(dialog);

        const dismiss = () => {
            dialog.hidden = true;
            document.body.style.overflow = dialog.dataset.previousOverflow || "";
            if (lastFocus instanceof HTMLElement) lastFocus.focus();
            lastFocus = null;
        };
        close.addEventListener("click", dismiss);
        dialog.addEventListener("click", event => {
            if (event.target === dialog) dismiss();
        });
        document.addEventListener("keydown", event => {
            if (dialog.hidden) return;
            if (event.key === "Escape") dismiss();
            if (event.key === "Tab") {
                event.preventDefault();
                close.focus();
            }
        });
        return dialog;
    }

    function openPhoto(card) {
        const photo = shownPhotos.get(card);
        if (!photo) return;
        const modal = getDialog();
        modal.querySelector(".practitioner-zoom-photo").src = photo;
        modal.querySelector(".practitioner-zoom-photo").alt = card.dataset.practitionerName + " profile picture";
        modal.querySelector(".practitioner-zoom-name").textContent = card.dataset.practitionerName;
        lastFocus = document.activeElement;
        modal.dataset.previousOverflow = document.body.style.overflow;
        document.body.style.overflow = "hidden";
        modal.hidden = false;
        modal.querySelector(".practitioner-zoom-close").focus();
    }

    function applyPhoto(card, photo) {
        const avatar = card.querySelector("[data-practitioner-avatar]");
        if (!avatar) return;
        if (!isPhoto(photo)) {
            shownPhotos.delete(card);
            avatar.replaceChildren(document.createTextNode(originalInitials.get(card)));
            avatar.classList.remove("has-photo");
            avatar.disabled = true;
            return;
        }
        if (shownPhotos.get(card) === photo) return;
        const image = document.createElement("img");
        image.alt = "";
        image.decoding = "async";
        image.src = photo;
        image.addEventListener("error", () => {
            if (shownPhotos.get(card) === photo) applyPhoto(card, "");
        }, {once:true});
        avatar.replaceChildren(image);
        avatar.classList.add("has-photo");
        avatar.disabled = false;
        shownPhotos.set(card, photo);
    }

    async function refreshPhotos() {
        if (loading || document.hidden) return;
        loading = true;
        try {
            const response = await fetch("/api/user/booking-data", {cache:"no-store", credentials:"same-origin"});
            if (!response.ok) throw new Error("Unable to load doctor photos");
            const payload = await response.json();
            if (!Array.isArray(payload.doctors)) throw new Error("Doctor list unavailable");
            const byName = new Map(payload.doctors.map(doctor => [normalize(doctor.name), doctor]));
            for (const card of cards) {
                const doctor = byName.get(normalize(card.dataset.practitionerName));
                applyPhoto(card, doctor?.photo || "");
            }
        } catch (error) {
            console.warn("Practitioner photos could not be refreshed:", error);
        } finally {
            loading = false;
        }
    }

    for (const card of cards) {
        const avatar = card.querySelector("[data-practitioner-avatar]");
        avatar?.addEventListener("click", () => openPhoto(card));
    }

    refreshPhotos();
    window.setInterval(refreshPhotos, 45000);
    window.addEventListener("focus", refreshPhotos);
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) refreshPhotos();
    });
})();
