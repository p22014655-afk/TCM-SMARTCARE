(() => {
    const list = document.getElementById("reviewsList");
    const search = document.getElementById("reviewSearch");
    const ratingFilter = document.getElementById("reviewRating");
    const productFilter = document.getElementById("reviewProduct");
    const count = document.getElementById("reviewsCount");
    const heading = document.getElementById("reviewsHeading");
    const subheading = document.getElementById("reviewsSubheading");
    const escape = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
    const query = new URLSearchParams(window.location.search);
    const presetProductId = query.get("productId") || "";
    const presetProductName = query.get("productName") || "";
    let reviews = [];

    function normalize(value) {
        return String(value || "").trim().toLocaleLowerCase();
    }

    function buildProductOptions() {
        const current = productFilter.value;
        const unique = [];
        const seen = new Set();
        for (const review of reviews) {
            const key = normalize(review.productId || review.productName);
            if (!key || seen.has(key)) continue;
            seen.add(key);
            unique.push({
                value: review.productId || review.productName,
                label: review.productName
            });
        }
        unique.sort((a, b) => a.label.localeCompare(b.label));
        productFilter.innerHTML = '<option value="">All products</option>' + unique.map(item => `<option value="${escape(item.value)}">${escape(item.label)}</option>`).join("");
        if (presetProductId && unique.some(item => String(item.value) === presetProductId)) {
            productFilter.value = presetProductId;
        } else if (presetProductName) {
            const matched = unique.find(item => normalize(item.label) === normalize(presetProductName));
            if (matched) productFilter.value = matched.value;
        } else if (current && unique.some(item => String(item.value) === current)) {
            productFilter.value = current;
        }
    }

    function getFilteredReviews() {
        const text = normalize(search.value);
        const rating = Number(ratingFilter.value);
        const selectedProduct = normalize(productFilter.value);
        return reviews.filter(review => {
            const matchesRating = !rating || review.rating === rating;
            const matchesSearch = !text || [review.productName, review.comment, review.customerName].join(" ").toLocaleLowerCase().includes(text);
            const matchesProduct = !selectedProduct || normalize(review.productId) === selectedProduct || normalize(review.productName) === selectedProduct;
            return matchesRating && matchesSearch && matchesProduct;
        });
    }

    function render() {
        const filtered = getFilteredReviews();
        list.replaceChildren();
        const selectedOption = productFilter.options[productFilter.selectedIndex];
        const selectedProductLabel = productFilter.value ? (selectedOption?.textContent || "Selected product") : "";
        count.textContent = `${filtered.length} review${filtered.length === 1 ? "" : "s"}` + (selectedProductLabel ? ` for ${selectedProductLabel}` : "");

        if (!filtered.length) {
            const p = document.createElement("div");
            p.className = "review-page-empty-state";
            p.innerHTML = reviews.length ? "No reviews match your current filters." : "No product reviews yet. Reviews can be submitted after an order is completed.";
            list.append(p);
            return;
        }

        filtered.sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || String(b.createdAt || "").localeCompare(String(a.createdAt || "")) || Number(b.reviewId) - Number(a.reviewId));
        for (const review of filtered) {
            const card = document.createElement("article");
            card.className = "review-card";
            const metaBits = [
                `<span>${escape(review.customerName)}</span>`,
                `<span class="review-meta-dot"></span>`,
                `<span>${escape(String(review.createdAt || "").slice(0, 10))}</span>`
            ];
            card.innerHTML = `
                <div class="review-card-header">
                    <div>
                        <div class="review-card-heading">
                            <h3>${escape(review.productName)}</h3>
                            <span class="review-product-badge">Product Review</span>
                            ${review.featured ? '<span class="product-featured-tag">★ Featured review</span>' : ''}
                        </div>
                        <p class="review-card-meta">${metaBits.join("")}</p>
                    </div>
                    <span class="review-rating" aria-label="${review.rating} out of 5 stars">${"★".repeat(review.rating)}${"☆".repeat(5 - review.rating)}</span>
                </div>
                <p class="review-text">${escape(review.comment)}</p>
                ${review.editedByStaff ? '<p class="review-moderation-label">Edited by shop staff</p>' : ''}
                ${review.staffReply ? `<div class="product-clinic-reply"><strong>Clinic reply:</strong> ${escape(review.staffReply)}</div>` : ''}
            `;
            list.append(card);
        }
    }

    async function load() {
        try {
            const response = await fetch("/api/user/reviews", {
                cache: "no-store",
                credentials: "same-origin"
            });
            const payload = await response.json();
            if (!response.ok) throw new Error(typeof payload.detail === "string" ? payload.detail : "Unable to load reviews.");
            reviews = Array.isArray(payload.reviews) ? payload.reviews : [];
            buildProductOptions();
            if (presetProductName) {
                heading.textContent = `Customer reviews for ${presetProductName}`;
                subheading.textContent = "Browse ratings, comments, featured feedback, and clinic replies for this product.";
            }
            render();
        } catch (error) {
            list.replaceChildren();
            count.textContent = error.message;
        }
    }

    search.addEventListener("input", render);
    ratingFilter.addEventListener("change", render);
    productFilter.addEventListener("change", render);
    document.getElementById("clearReviewFilter").addEventListener("click", () => {
        search.value = "";
        ratingFilter.value = "";
        productFilter.value = "";
        heading.textContent = "Reviews from completed orders";
        subheading.textContent = "Explore customer ratings and experiences for our herbal products.";
        window.history.replaceState({}, "", window.location.pathname);
        render();
    });
    document.getElementById("menuButton")?.addEventListener("click", () => {
        document.querySelector(".sidebar")?.classList.toggle("open");
    });
    load();
})();
