(() => {
    const container = document.getElementById("reviewCards");
    const errorElement = document.getElementById("reviewsError");
    const countElement = document.getElementById("appointmentReviewsCount");
    const searchElement = document.getElementById("appointmentReviewSearch");
    const ratingElement = document.getElementById("appointmentReviewRating");
    const doctorElement = document.getElementById("appointmentReviewDoctor");
    const serviceElement = document.getElementById("appointmentReviewService");
    const clearButton = document.getElementById("clearAppointmentReviewFilters");
    const tabs = Array.from(document.querySelectorAll(".appointment-review-tab"));
    const params = new URLSearchParams(window.location.search);
    const highlightBooking = params.get("booking") || "";
    let mode = params.get("view") === "mine" ? "mine" : "public";
    let reviews = [];
    let serviceCatalog = [];
    let reviewsReady = false;
    let loadId = 0;
    let highlightScrolled = false;

    function normalize(value) {
        return String(value ?? "").trim().toLocaleLowerCase();
    }

    function makeElement(tag, className, value) {
        const element = document.createElement(tag);
        if (className) element.className = className;
        if (value !== undefined) element.textContent = String(value);
        return element;
    }

    function displayTabs() {
        tabs.forEach(tab => {
            const active = tab.dataset.view === mode;
            tab.classList.toggle("active", active);
            tab.setAttribute("aria-selected", String(active));
            tab.tabIndex = active ? 0 : -1;
        });
    }

    function fillOptions(select, key, allText) {
        const selected = select.value;
        const names = new Map();
        reviews.forEach(review => {
            const name = String(review[key] || "").trim();
            if (name && !names.has(normalize(name))) names.set(normalize(name), name);
        });
        if (key === "service") {
            serviceCatalog.forEach(name => {
                if (name && !names.has(normalize(name))) names.set(normalize(name), name);
            });
        }
        const sorted = Array.from(names.values()).sort((a, b) => a.localeCompare(b));
        select.replaceChildren(new Option(allText, ""));
        sorted.forEach(name => select.add(new Option(name, normalize(name))));
        if (sorted.some(name => normalize(name) === selected)) select.value = selected;
    }

    function filterReviews() {
        const text = normalize(searchElement.value);
        const rating = Number(ratingElement.value);
        const doctor = doctorElement.value;
        const service = serviceElement.value;
        return reviews.filter(review => {
            const matchesSearch = !text || [review.service, review.doctor, review.reviewText, mode === "mine" ? review.appointmentId : ""].some(value => normalize(value).includes(text));
            const matchesRating = !rating || Number(review.rating) === rating;
            const matchesDoctor = !doctor || normalize(review.doctor) === doctor;
            const matchesService = !service || normalize(review.service) === service;
            return matchesSearch && matchesRating && matchesDoctor && matchesService;
        });
    }

    function createCard(review) {
        const card = makeElement("article", "appointment-review-card" + (review.featured ? " is-featured" : ""));
        if (mode === "mine" && highlightBooking && review.appointmentId === highlightBooking) {
            card.id = "selected-review";
            card.classList.add("selected-review");
        }
        const head = makeElement("div", "appointment-review-card-head");
        const titleArea = makeElement("div");
        const titleLine = makeElement("div", "appointment-review-card-title");
        titleLine.append(makeElement("h3", "", [review.service, review.doctor].filter(Boolean).join(" — ") || "Consultation"));
        titleLine.append(makeElement("span", "appointment-review-type-badge", "Appointment Review"));
        if (review.featured) titleLine.append(makeElement("span", "appointment-review-featured", "★ Featured review"));
        titleArea.append(titleLine);
        const meta = makeElement("p", "appointment-review-card-meta");
        const details = mode === "mine"
            ? [review.appointmentDate, review.appointmentId].filter(Boolean)
            : ["Anonymous patient"];
        details.forEach((detail, index) => {
            if (index) meta.append(makeElement("span", "appointment-review-meta-dot"));
            meta.append(makeElement("span", "", detail));
        });
        titleArea.append(meta);
        head.append(titleArea);
        const stars = Math.max(0, Math.min(5, Math.round(Number(review.rating) || 0)));
        const rating = makeElement("span", "appointment-review-stars", "★".repeat(stars) + "☆".repeat(5 - stars));
        rating.setAttribute("aria-label", `${stars} out of 5 stars`);
        head.append(rating);
        card.append(head);
        if (mode === "mine" && review.status) {
            const status = makeElement("span", "appointment-review-status" + (normalize(review.status) === "published" ? " status-published" : ""), review.status);
            status.style.marginTop = "13px";
            card.append(status);
        }
        card.append(makeElement("p", "appointment-review-text", review.reviewText || ""));
        if (review.adminReply) {
            const reply = makeElement("div", "appointment-review-reply");
            const label = makeElement("strong", "", "Clinic reply: ");
            reply.append(label, document.createTextNode(review.adminReply));
            card.append(reply);
        }
        return card;
    }

    function render() {
        const matches = filterReviews();
        matches.sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || String(b.createdAt || "").localeCompare(String(a.createdAt || "")) || Number(b.reviewId || 0) - Number(a.reviewId || 0));
        countElement.textContent = `${matches.length} review${matches.length === 1 ? "" : "s"}`;
        container.replaceChildren();
        if (!matches.length) {
            const selection = serviceElement.options[serviceElement.selectedIndex];
            const serviceName = serviceElement.value && selection ? selection.textContent : "";
            const emptyMessage = reviews.length
                ? serviceName && !searchElement.value && !ratingElement.value && !doctorElement.value
                    ? `No ${mode === "mine" ? "personal" : "published"} reviews for ${serviceName} yet.`
                    : "No reviews match your filters."
                : serviceName
                    ? `No ${mode === "mine" ? "personal" : "published"} reviews for ${serviceName} yet.`
                    : mode === "mine" ? "You have no appointment reviews yet." : "No published appointment reviews yet.";
            container.append(makeElement("div", "appointment-review-empty", emptyMessage));
            return;
        }
        const fragment = document.createDocumentFragment();
        matches.forEach(review => fragment.append(createCard(review)));
        container.append(fragment);
        if (!highlightScrolled && mode === "mine" && highlightBooking) {
            const selected = document.getElementById("selected-review");
            if (selected) {
                highlightScrolled = true;
                selected.scrollIntoView({ block: "center", behavior: "smooth" });
            }
        }
    }

    async function loadServiceCatalog() {
        try {
            const response = await fetch("/api/user/booking-data", {
                credentials: "same-origin",
                cache: "no-store"
            });
            if (!response.ok) throw new Error("Unable to load services.");
            const data = await response.json();
            if (!Array.isArray(data.services)) throw new Error("Invalid service data.");
            serviceCatalog = data.services.map(item => String(item.serviceName || "").trim()).filter(Boolean);
        } catch (_) {
            serviceCatalog = ["TCM Consultation", "Acupuncture", "Cupping Therapy", "Tuina Therapy"];
        }
        fillOptions(serviceElement, "service", "All services");
        if (reviewsReady) render();
    }

    async function loadReviews() {
        reviewsReady = false;
        const currentId = ++loadId;
        errorElement.hidden = true;
        errorElement.textContent = "";
        countElement.textContent = "Loading reviews...";
        container.replaceChildren();
        try {
            const url = mode === "mine" ? "/api/user/appointment-reviews" : "/api/user/appointment-reviews/public";
            const response = await fetch(url, { credentials: "same-origin", cache: "no-store" });
            const data = await response.json().catch(() => ({}));
            if (currentId !== loadId) return;
            if (!response.ok) {
                if (response.status === 401) throw new Error("Please log in to view your own reviews.");
                throw new Error(typeof data.detail === "string" ? data.detail : "Unable to load appointment reviews.");
            }
            reviews = Array.isArray(data.reviews) ? data.reviews : [];
            fillOptions(doctorElement, "doctor", "All doctors");
            fillOptions(serviceElement, "service", "All services");
            reviewsReady = true;
            render();
        } catch (error) {
            if (currentId !== loadId) return;
            reviews = [];
            fillOptions(doctorElement, "doctor", "All doctors");
            fillOptions(serviceElement, "service", "All services");
            countElement.textContent = "Could not load reviews";
            container.replaceChildren();
            errorElement.textContent = error.message || "Unable to load appointment reviews.";
            errorElement.hidden = false;
        }
    }

    function clearFilters() {
        searchElement.value = "";
        ratingElement.value = "";
        doctorElement.value = "";
        serviceElement.value = "";
        render();
    }

    [searchElement, ratingElement, doctorElement, serviceElement].forEach(element => {
        element.addEventListener(element === searchElement ? "input" : "change", render);
    });
    clearButton.addEventListener("click", clearFilters);
    tabs.forEach(tab => tab.addEventListener("click", () => {
        if (mode === tab.dataset.view) return;
        mode = tab.dataset.view;
        searchElement.value = "";
        ratingElement.value = "";
        doctorElement.value = "";
        serviceElement.value = "";
        displayTabs();
        const url = new URL(window.location.href);
        if (mode === "mine") url.searchParams.set("view", "mine");
        else {
            url.searchParams.delete("view");
            url.searchParams.delete("booking");
        }
        window.history.replaceState(null, "", url);
        loadReviews();
    }));
    document.getElementById("menuButton")?.addEventListener("click", () => {
        document.querySelector(".sidebar")?.classList.toggle("open");
    });
    document.getElementById("logoutButton")?.addEventListener("click", async () => {
        try {
            await fetch("/api/user/logout", { method: "POST", credentials: "same-origin" });
        } catch (_) {}
        sessionStorage.removeItem("tcmPatientName");
        sessionStorage.removeItem("tcmPatientEmail");
        window.location.href = "login.html";
    });
    displayTabs();
    loadServiceCatalog();
    loadReviews();
})();
