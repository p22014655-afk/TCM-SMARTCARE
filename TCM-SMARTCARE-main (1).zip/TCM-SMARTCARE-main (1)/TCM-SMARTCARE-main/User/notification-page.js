(() => {
    const menuButton = document.getElementById("menuButton");
    const logoutButton = document.getElementById("logoutButton");

    menuButton?.addEventListener("click", () => {
        document.querySelector(".sidebar")?.classList.toggle("open");
    });

    logoutButton?.addEventListener("click", async () => {
        if (logoutButton.disabled) return;
        logoutButton.disabled = true;
        try {
            const response = await fetch("/api/user/logout", {
                method: "POST",
                credentials: "same-origin",
                cache: "no-store"
            });
            if (!response.ok) throw new Error("Unable to sign out. Please try again.");
            sessionStorage.removeItem("tcmPatientName");
            sessionStorage.removeItem("tcmPatientEmail");
            localStorage.removeItem("tcmPatientProfile");
            localStorage.removeItem("tcmPatientAccount");
            window.location.replace("/User/login.html");
        } catch (error) {
            logoutButton.disabled = false;
            window.alert(error.message || "Unable to sign out. Please try again.");
        }
    });
})();
