(() => {
    const key = "tcmPendingPayment";
    const approvalCard = document.getElementById("approvalCard");
    const successCard = document.getElementById("successCard");
    const approveButton = document.getElementById("approveButton");
    const methodNames = { fpx: "Online Banking (FPX)", "tng-ewallet": "Touch 'n Go eWallet" };
    let pending;
    try {
        pending = JSON.parse(sessionStorage.getItem(key) || "null");
    } catch {
        pending = null;
    }
    if (!pending || !Array.isArray(pending.items) || !["fpx", "tng-ewallet"].includes(pending.paymentMethod)) {
        document.getElementById("paymentTitle").textContent = "No pending payment";
        document.getElementById("paymentDescription").textContent = "Return to your cart and start checkout again.";
        document.getElementById("demoWarning").textContent = "";
        approveButton.hidden = true;
        return;
    }
    const methodName = methodNames[pending.paymentMethod];
    document.getElementById("pageTitle").textContent = methodName;
    document.getElementById("paymentTitle").textContent = `Review ${methodName}`;
    document.getElementById("paymentDescription").textContent = `Collection: ${pending.fulfillmentMethod === "pickup" ? "Pickup" : "Delivery"}`;
    document.getElementById("demoTotal").textContent = `RM ${Number(pending.total).toFixed(2)}`;
    document.getElementById("demoWarning").textContent = "";



    approveButton.addEventListener("click", async () => {
        approveButton.disabled = true;
        approveButton.textContent = "Processing payment...";
        try {
            const response = await fetch("/api/user/orders", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "same-origin",
                body: JSON.stringify(pending)
            });
            const result = await response.json();
            if (!response.ok) {
                throw new Error(typeof result.detail === "string" ? result.detail : "Unable to save order.");
            }
            const order = result.order;
            localStorage.removeItem("tcmCart");
            sessionStorage.removeItem(key);
            localStorage.setItem("tcmLastOrder", JSON.stringify(order));
            document.getElementById("successText").textContent = `Order ${order.orderNumber} saved. Tracking ID: ${order.trackingId}. Total: RM ${Number(order.total).toFixed(2)}. Payment simulated; no real charge.`;
            const receipt = document.getElementById("receiptDownload");
            receipt.href = `/api/user/orders/${encodeURIComponent(order.orderId)}/receipt`;
            receipt.hidden = false;
            sessionStorage.removeItem("tcmCheckoutReference");
            approvalCard.hidden = true;
            successCard.hidden = false;
        } catch (error) {
            document.getElementById("demoWarning").textContent = error.message;
            approveButton.disabled = false;
            approveButton.textContent = "Confirm payment";
        }
    });
    document.getElementById("menuButton")?.addEventListener("click", () => document.querySelector(".sidebar")?.classList.toggle("open"));
})();
