const profileStorageKey = "tcmPatientProfile";
const profileForm = document.getElementById("profileForm");
const photoInput = document.getElementById("photoInput");
const profilePreview = document.getElementById("profilePreview");
const headerAvatar = document.getElementById("headerAvatar");
const headerName = document.getElementById("headerName");
const toast = document.getElementById("profileToast");

let toastTimer;
let profilePhotoData = "";

function showToast(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function initials(name) {
    return name.trim().split(/\s+/).slice(0, 2)
        .map((part) => part.charAt(0).toUpperCase()).join("") || "JL";
}

function renderAvatar(imageData, name) {
    if (imageData) {
        profilePreview.src = imageData;
        profilePreview.style.visibility = "visible";
        headerAvatar.innerHTML = "";
        headerAvatar.classList.add("profile-image");
        headerAvatar.style.backgroundImage = `url("${imageData}")`;
        headerAvatar.style.backgroundSize = "cover";
        headerAvatar.style.backgroundPosition = "center";
        headerAvatar.textContent = "";
    } else {
        profilePreview.removeAttribute("src");
        profilePreview.style.visibility = "hidden";
        headerAvatar.classList.remove("profile-image");
        headerAvatar.style.backgroundImage = "";
        headerAvatar.textContent = initials(name);
    }

    headerName.textContent = name || "Jamie Lee";
}

function getSavedProfile() {
    try {
        return JSON.parse(localStorage.getItem(profileStorageKey) || "{}");
    } catch {
        return {};
    }
}

function saveProfile(profile) {
    localStorage.setItem(profileStorageKey, JSON.stringify(profile));
}

function loadProfile() {
    const profile = getSavedProfile();
    const sessionName = sessionStorage.getItem("tcmPatientName");
    const name = profile.fullName || (sessionName
        ? sessionName.charAt(0).toUpperCase() + sessionName.slice(1)
        : "Jamie Lee");

    document.getElementById("fullName").value = name;
    document.getElementById("email").value = profile.email || "";
    document.getElementById("phone").value = profile.phone || "";
    document.getElementById("birthDate").value = profile.birthDate || "";
    document.getElementById("contactMethod").value = profile.contactMethod || "phone";
    document.getElementById("address").value = profile.address || "";

    profilePhotoData = profile.photo || "";
    renderAvatar(profilePhotoData, name);
}

async function readApi(url, options = {}) {
    const response = await fetch(url, { credentials: "same-origin", cache: "no-store", ...options });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
        if (response.status === 401) {location.href="login.html";throw new Error("Please log in again.");}
        throw new Error(typeof body.detail === "string" ? body.detail : "Could not save changes.");
    }
    return body;
}

async function refreshProfile() {
    try {
        const data = await readApi("/api/user/me");
        let profile = {...data.user};
        // One-time recovery of profile extras previously stored only in this browser.
        // Never copy one patient's cached details into another person's SQL record.
        const old = getSavedProfile();
        const samePatient = old.email && String(old.email).toLowerCase() ===
            String(profile.email).toLowerCase() &&
            (!old.id || String(old.id) === String(profile.id));
        const oldExtras = old.photo || old.birthDate || old.address;
        if (!profile.profileDetailsSaved && samePatient && oldExtras) {
            try {
                const migrated = await readApi("/api/user/profile", {
                    method: "PUT", headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({
                        fullName: profile.fullName, email: profile.email, phone: profile.phone,
                        birthDate: old.birthDate || "", address: old.address || "",
                        contactMethod: ["phone", "email"].includes(old.contactMethod)
                            ? old.contactMethod : "phone",
                        photo: old.photo || "", currentPassword: ""
                    })
                });
                profile = migrated.user;
            } catch (_) {
                // The User can still re-upload their photo and save profile normally.
            }
        }
        saveProfile(profile);
        sessionStorage.setItem("tcmPatientName", data.user.fullName);
        sessionStorage.setItem("tcmPatientEmail", data.user.email);
        loadProfile();
    } catch (error) {showToast(error.message);}
}

profileForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!profileForm.reportValidity()) return;
    const current = getSavedProfile();
    const profile = {
        ...current,
        fullName: document.getElementById("fullName").value.trim(),
        email: document.getElementById("email").value.trim().toLowerCase(),
        phone: document.getElementById("phone").value.trim(),
        birthDate: document.getElementById("birthDate").value,
        contactMethod: document.getElementById("contactMethod").value,
        address: document.getElementById("address").value.trim(),
        photo: profilePhotoData
    };
    const originalEmail = sessionStorage.getItem("tcmPatientEmail") || current.email || "";
    const currentPassword = document.getElementById("emailCurrentPassword").value;
    if (profile.email !== originalEmail.toLowerCase() && !currentPassword) {
        showToast("Enter your current password to change email.");return;
    }
    const button = profileForm.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const result = await readApi("/api/user/profile", { method: "PUT",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify({...profile, currentPassword})
        });
        saveProfile({...profile,...result.user});
        sessionStorage.setItem("tcmPatientName", result.user.fullName);
        sessionStorage.setItem("tcmPatientEmail", result.user.email);
        document.getElementById("emailCurrentPassword").value = "";
        renderAvatar(profilePhotoData, result.user.fullName);
        showToast("Profile saved to SQL Server.");
    } catch (error) {showToast(error.message);}
    finally {button.disabled=false;}
});

photoInput.addEventListener("change", () => {
    const file = photoInput.files[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
        showToast("Choose an image file.");
        photoInput.value = "";
        return;
    }

    if (file.size > 2 * 1024 * 1024) {
        showToast("Choose an image smaller than 2 MB.");
        photoInput.value = "";
        return;
    }

    const reader = new FileReader();

    reader.addEventListener("load", () => {
        const image = new Image();

        image.addEventListener("load", () => {
            const maxSize = 512;
            const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
            const canvas = document.createElement("canvas");

            canvas.width = Math.round(image.width * scale);
            canvas.height = Math.round(image.height * scale);

            const context = canvas.getContext("2d");
            context.drawImage(image, 0, 0, canvas.width, canvas.height);

            profilePhotoData = canvas.toDataURL("image/jpeg", 0.8);

            // Save directly to SQL Server so refreshing, logging out, or
            // switching devices never loses the patient photo.
            (async () => {
                try {
                    const saved = await readApi("/api/user/profile-photo", {
                        method: "PUT", headers: {"Content-Type": "application/json"},
                        body: JSON.stringify({photo: profilePhotoData})
                    });
                    saveProfile(saved.user);
                    renderAvatar(saved.user.photo || "", saved.user.fullName);
                    showToast("Profile picture saved to SQL Server.");
                } catch (error) {
                    await refreshProfile();
                    showToast(error.message || "Could not save picture.");
                }
            })();
        });

        image.addEventListener("error", () => {
            showToast("Could not open that image. Try another file.");
        });

        image.src = reader.result;
    });

    reader.addEventListener("error", () => {
        showToast("Could not read that image. Try another file.");
    });

    reader.readAsDataURL(file);
});

document.getElementById("removePhoto").addEventListener("click", async () => {
    try {
        const saved = await readApi("/api/user/profile-photo", {
            method: "PUT", headers: {"Content-Type": "application/json"},
            body: JSON.stringify({photo: ""})
        });
        profilePhotoData = "";
        photoInput.value = "";
        saveProfile(saved.user);
        renderAvatar("", saved.user.fullName);
        showToast("Profile picture removed from SQL Server.");
    } catch (error) {
        showToast(error.message || "Could not remove picture.");
    }
});

document.getElementById("resetProfile").addEventListener("click", () => {
    setTimeout(loadProfile);
});

document.getElementById("passwordForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const currentPassword = form.elements.currentPassword.value;
    const newPassword = form.elements.newPassword.value;
    const confirmPassword = form.elements.confirmPassword.value;
    const note = document.getElementById("passwordNote");
    if (newPassword !== confirmPassword) {note.textContent="Passwords do not match.";return;}
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    note.textContent = "Updating password...";
    try {
        const result = await readApi("/api/user/password", {method:"PUT",
            headers:{"Content-Type":"application/json"},
            body: JSON.stringify({current_password:currentPassword,new_password:newPassword})
        });
        form.reset();
        note.textContent = result.message;
        showToast("Password updated. Please log in again.");

        // Password is now verified in SQL Server. End this session so
        // the next Login checks the new password on the same user backend.
        try {
            await fetch("/api/user/logout", {
                method: "POST", credentials: "same-origin", cache: "no-store"
            });
        } catch (_) {
            // Even if logout cannot be reached, the backend invalidates
            // previous sessions when a password changes.
        }
        sessionStorage.removeItem("tcmPatientName");
        sessionStorage.removeItem("tcmPatientEmail");
        localStorage.removeItem("tcmPatientProfile");
        localStorage.removeItem("tcmPatientAccount");
        location.replace("/User/login.html?password_changed=1");
    } catch (error) {note.textContent=error.message;}
    finally {button.disabled=false;}
});

document.getElementById("logoutButton").addEventListener("click", async () => {
    try {await fetch("/api/user/logout", {method:"POST",credentials:"same-origin"});} catch (_) {}
    sessionStorage.removeItem("tcmPatientName");
    sessionStorage.removeItem("tcmPatientEmail");
    localStorage.removeItem("tcmPatientProfile");
    localStorage.removeItem("tcmPatientAccount");
    location.href="login.html";
});

document.getElementById("menuButton").addEventListener("click", () => {
    document.querySelector(".sidebar").classList.toggle("open");
});

loadProfile();
refreshProfile();


/* Avatar lightbox: preview only. No changes to any uploaded or saved photos. */
(() => {
    if (window.__tcmAvatarZoomInstalled) return;
    window.__tcmAvatarZoomInstalled = true;
    const isAdminPortal = document.body?.classList.contains("admin-shell") ||
        document.querySelector(".admin-shell") !== null;
    const selector = isAdminPortal
        ? ["#adminAvatar", ".account-person .avatar", ".person-cell .avatar",
           ".patient-profile-head .avatar", ".admin-profile-photo-preview",
           "#doctorPicturePreview", "#scheduleDoctorAvatar", ".admin-conversation-avatar"].join(", ")
        : [".patient-avatar", ".practitioner-photo", ".doctor-modal-avatar",
           "#profilePreview", ".conversation-avatar"].join(", ");
    let overlay = null;
    let previousFocus = null;

    function findName(el) {
        const img = el.matches("img") ? el : el.querySelector("img");
        const card = el.closest(".practitioner-card, .account-person, .person-cell, .patient-profile-head, .chat-heading");
        const nearby = card?.querySelector("h3, h2, strong")?.textContent?.trim();
        if (nearby) return nearby;
        if (el.id === "doctorModalAvatar") return document.getElementById("doctorModalName")?.textContent?.trim() || "Practitioner";
        if (el.id === "adminAvatar") return document.getElementById("adminName")?.textContent?.trim() || "Profile picture";
        if (el.classList.contains("patient-avatar") || el.id === "profilePreview") {
            return document.querySelector(".topbar .profile-top-link strong")?.textContent?.trim() ||
                document.getElementById("fullName")?.value?.trim() || "Profile picture";
        }
        return img?.alt?.trim() || el.getAttribute("aria-label") || "Profile picture";
    }

    function photoSource(el) {
        const image = el.matches("img") ? el : el.querySelector("img");
        if (image?.getAttribute("src") && getComputedStyle(image).visibility !== "hidden") {
            return image.currentSrc || image.src;
        }
        const style = getComputedStyle(el).backgroundImage;
        if (style && style !== "none") {
            const match = /^url\(["']?(.*?)["']?\)$/.exec(style);
            if (match) return match[1];
        }
        return "";
    }

    function dismiss() {
        if (!overlay) return;
        overlay.remove();
        overlay = null;
        previousFocus?.isConnected && previousFocus.focus({preventScroll: true});
        previousFocus = null;
    }

    function show(el) {
        dismiss();
        previousFocus = document.activeElement;
        const name = findName(el);
        const src = photoSource(el);
        overlay = document.createElement("div");
        overlay.id = "tcm-avatar-zoom";
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-modal", "true");
        overlay.setAttribute("aria-label", `${name} enlarged profile picture`);
        const panel = document.createElement("div");
        panel.className = "tcm-avatar-zoom-panel";
        const close = document.createElement("button");
        close.type = "button";
        close.className = "tcm-avatar-zoom-close";
        close.setAttribute("aria-label", "Close enlarged picture");
        close.textContent = "×";
        const circle = document.createElement("div");
        circle.className = "tcm-avatar-zoom-circle";
        if (src) {
            const image = document.createElement("img");
            image.src = src;
            image.alt = `${name} profile picture`;
            image.onerror = () => { circle.replaceChildren(); circle.textContent = el.textContent.trim() || "?"; };
            circle.appendChild(image);
        } else {
            circle.textContent = el.textContent.trim() || "?";
        }
        const caption = document.createElement("p");
        caption.className = "tcm-avatar-zoom-name";
        caption.textContent = name;
        panel.append(close, circle, caption);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);
        close.addEventListener("click", dismiss);
        overlay.addEventListener("click", e => { if (e.target === overlay) dismiss(); });
        close.focus({preventScroll: true});
    }

    const css = document.createElement("style");
    css.id = "tcm-avatar-zoom-style";
    css.textContent = `
        ${selector} { cursor: zoom-in !important; }
        ${selector}:focus-visible { outline: 3px solid #328d83 !important; outline-offset: 3px; }
        #tcm-avatar-zoom { position: fixed; inset: 0; z-index: 2147483000;
            background: rgba(12,38,39,.78); display: flex; align-items: center;
            justify-content: center; padding: 20px; box-sizing: border-box; }
        #tcm-avatar-zoom .tcm-avatar-zoom-panel { box-sizing: border-box;
            position: relative; display: flex; align-items: center; flex-direction: column;
            gap: 16px; width: min(440px, 100%); max-height: 95vh;
            padding: 50px 20px 26px; border-radius: 18px; background: #fff;
            box-shadow: 0 18px 60px rgba(0,0,0,.35); }
        #tcm-avatar-zoom .tcm-avatar-zoom-close { position: absolute; top: 12px; right: 14px;
            border: 0; border-radius: 50%; width: 38px; height: 38px;
            display: grid; place-items: center; background: #edf5f2; color: #184f4b;
            font: normal 28px/1 system-ui,sans-serif; cursor: pointer; }
        #tcm-avatar-zoom .tcm-avatar-zoom-close:hover { background: #d9ebe6; }
        #tcm-avatar-zoom .tcm-avatar-zoom-circle { width: min(320px, 70vw, 52vh);
            height: min(320px, 70vw, 52vh); border-radius: 50%; overflow: hidden;
            display: flex; align-items: center; justify-content: center;
            background: #dcece7; color: #205d5a;
            font: 700 clamp(48px, 12vw, 100px)/1 system-ui,sans-serif; }
        #tcm-avatar-zoom .tcm-avatar-zoom-circle img { width: 100%; height: 100%;
            object-fit: cover; display: block; }
        #tcm-avatar-zoom .tcm-avatar-zoom-name { margin: 0;
            font: 700 17px/1.4 system-ui,sans-serif; text-align: center; color: #153c39; }
    `;
    document.head.appendChild(css);

    // Capture clicks before the photo's enclosing profile or doctor-card handler.
    document.addEventListener("click", event => {
        if (overlay && event.target.closest("#tcm-avatar-zoom")) return;
        const el = event.target instanceof Element ? event.target.closest(selector) : null;
        if (!el) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        show(el);
    }, true);
    document.addEventListener("keydown", event => {
        if (overlay && event.key === "Escape") {
            event.preventDefault(); event.stopImmediatePropagation(); dismiss(); return;
        }
        if (event.key !== "Enter" && event.key !== " ") return;
        const el = document.activeElement;
        if (!(el instanceof Element) || !el.matches(selector)) return;
        event.preventDefault(); event.stopImmediatePropagation(); show(el);
    }, true);

    const enhance = () => document.querySelectorAll(selector).forEach(el => {
        if (el.tabIndex < 0) el.tabIndex = 0;
        if (!el.hasAttribute("role")) el.setAttribute("role", "button");
        if (!el.getAttribute("title")) el.setAttribute("title", "Click to enlarge picture");
    });
    const initialize = () => {
        enhance();
        let scheduled = false;
        const observer = new MutationObserver(() => {
            if (scheduled) return;
            scheduled = true;
            requestAnimationFrame(() => { scheduled = false; enhance(); });
        });
        observer.observe(document.body, {childList: true, subtree: true});
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialize);
    else initialize();
})();
