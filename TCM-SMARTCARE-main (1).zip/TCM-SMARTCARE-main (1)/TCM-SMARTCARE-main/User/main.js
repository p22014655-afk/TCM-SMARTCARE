
const savedName = sessionStorage.getItem("tcmPatientName");

if (savedName) {
    const name = savedName.charAt(0).toUpperCase() + savedName.slice(1);
    document.getElementById("patientName")?.replaceChildren(document.createTextNode(name));
    document.getElementById("welcomeName")?.replaceChildren(document.createTextNode(name));
}

const moodButtons = document.querySelectorAll(".mood-row button");

moodButtons.forEach((button) => {
    button.addEventListener("click", () => {
        moodButtons.forEach((item) => item.classList.remove("selected"));
        button.classList.add("selected");
    });
});

document.querySelector(".save-button")?.addEventListener("click", () => {
    const toast = document.getElementById("toast");
    if (!toast) return;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3000);
});

const serviceFilterRow = document.querySelector(".filter-row");
const dayButtons = document.querySelectorAll(".day-button");
const practitionerList = document.querySelector(".practitioner-list");
const doctorSearch = document.getElementById("doctorSearch");
const noResults = document.getElementById("noResults");
const bookingSuccess = document.getElementById("bookingSuccess");
const bookingMessage = document.getElementById("bookingMessage");
const bookingConfirmation = document.getElementById("bookingConfirmation");
const confirmationDetails = document.getElementById("confirmationDetails");
const confirmBookingButton = document.getElementById("confirmBooking");
const appointmentNotice = document.getElementById("appointmentNotice");
const appointmentNoticeMessage = document.getElementById("appointmentNoticeMessage");

// Keep the existing Dashboard HTML and Sidebar unchanged; add the instruction beside its filters.
if (serviceFilterRow && !document.getElementById("serviceSelectionNote")) {
    const note = document.createElement("p");
    note.id = "serviceSelectionNote";
    note.className = "service-selection-note";
    note.setAttribute("aria-live", "polite");
    serviceFilterRow.insertAdjacentElement("afterend", note);
}

// The top filters only narrow doctors; they do NOT select a booking service.
let selectedService = "all";
// Exactly one doctor + one service may be selected for the next appointment.
let selectedDoctorId = null;
let selectedDoctorServiceId = null;
let selectedDay = "week";
let sqlBookingData = null;
let bookingLoadError = "";
let pendingBooking = null;
let lastBookingSignature = "";
let bookingRequestInProgress = false;

function localDate(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
}

function toMinutes(time) {
    const parts = String(time ?? "").split(":");
    if (parts.length < 2) return NaN;

    const hours = Number(parts[0]);
    const minutes = Number(parts[1]);

    if (!Number.isInteger(hours) || !Number.isInteger(minutes)) return NaN;
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return NaN;

    return hours * 60 + minutes;
}

function toTime(minutes) {
    return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
}

function displayTime(time) {
    const [hour, minute] = String(time).split(":").map(Number);
    return `${hour % 12 || 12}:${String(minute).padStart(2, "0")} ${hour >= 12 ? "PM" : "AM"}`;
}

function displayDate(dateString) {
    const [year, month, day] = dateString.split("-").map(Number);

    return new Date(year, month - 1, day).toLocaleDateString(undefined, {
        weekday: "short",
        month: "short",
        day: "numeric"
    });
}

function dateRange() {
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    if (selectedDay === "tomorrow") {
        start.setDate(start.getDate() + 1);
    }

    const count = selectedDay === "week" ? 7 : 1;

    return Array.from({ length: count }, (_, index) => {
        const date = new Date(start);
        date.setDate(date.getDate() + index);
        return date;
    });
}

function getDoctor(card) {
    if (!sqlBookingData) return null;

    return sqlBookingData.doctors.find((doctor) =>
        doctor.doctorCode === card.dataset.doctorId
    ) || null;
}

function getDoctorServices(doctor) {
    if (!doctor || !sqlBookingData) return [];

    const ids = new Set(
        sqlBookingData.doctorServices
            .filter((item) => Number(item.doctorId) === Number(doctor.doctorId))
            .map((item) => Number(item.serviceId))
    );

    return sqlBookingData.services.filter((item) =>
        ids.has(Number(item.serviceId))
    );
}

function doctorWindowsOnDate(doctorId, dateString, dayOfWeek) {
    if (!sqlBookingData || dayOfWeek === 7) return [];

    const exceptions = (sqlBookingData.dateOverrides || []).filter(item =>
        Number(item.doctorId) === Number(doctorId) && item.date === dateString
    );

    if (exceptions.length) {
        return exceptions.filter(item => !item.isClosed);
    }

    return sqlBookingData.schedules.filter(item =>
        Number(item.doctorId) === Number(doctorId) &&
        Number(item.dayOfWeek) === dayOfWeek
    );
}

function doctorTimeConflict(doctorId, dateString, dayOfWeek, start, end) {
    return sqlBookingData.doctors.some(other => {
        if (Number(other.doctorId) === Number(doctorId)) return false;
        return doctorWindowsOnDate(other.doctorId, dateString, dayOfWeek).some(window => {
            const otherStart = toMinutes(window.startTime);
            const otherEnd = toMinutes(window.endTime);
            return Number.isFinite(otherStart) && Number.isFinite(otherEnd) &&
                start < otherEnd && otherStart < end;
        });
    });
}

function isSlotCancelled(doctorId, date, start, end) {
    return (sqlBookingData?.cancelledSlots || []).some(item =>
        Number(item.doctorId) === Number(doctorId) &&
        item.date === date &&
        start < toMinutes(item.endTime) &&
        toMinutes(item.startTime) < end
    );
}

function isSlotBooked(doctorId, date, start, end, capacity) {
    const count = (sqlBookingData.bookedSlots || []).filter(item =>
        Number(item.doctorId) === Number(doctorId) &&
        item.date === date &&
        start < toMinutes(item.endTime) &&
        toMinutes(item.startTime) < end
    ).length;
    return count >= capacity;
}

function availableSlots(card) {
    const doctor = getDoctor(card);
    if (!doctor || !sqlBookingData) return [];

    const now = new Date();
    const slots = [];

    dateRange().forEach(date => {
        const dateString = localDate(date);
        const dayOfWeek = ((date.getDay() + 6) % 7) + 1;
        const dailySchedules = doctorWindowsOnDate(doctor.doctorId, dateString, dayOfWeek);

        dailySchedules.forEach(schedule => {
            const start = toMinutes(schedule.startTime);
            const end = toMinutes(schedule.endTime);
            const duration = Number(schedule.slotDuration);
            const capacity = Number(schedule.capacity);

            if (!Number.isFinite(start) || !Number.isFinite(end) ||
                !Number.isInteger(duration) || duration <= 0 ||
                !Number.isInteger(capacity) || capacity < 1 || end <= start) return;

            for (let time = start; time + duration <= end; time += duration) {
                const slotDate = new Date(date.getFullYear(), date.getMonth(),
                    date.getDate(), Math.floor(time / 60), time % 60);
                if (slotDate <= now) continue;
                if (doctorTimeConflict(doctor.doctorId, dateString, dayOfWeek, time, time + duration)) continue;
                if (isSlotCancelled(doctor.doctorId, dateString, time, time + duration)) continue;
                if (isSlotBooked(doctor.doctorId, dateString, time, time + duration, capacity)) continue;

                slots.push({ date: dateString, time: toTime(time), endTime: toTime(time + duration) });
            }
        });
    });

    const unique = new Map();
    slots.forEach(slot => unique.set(`${slot.date} ${slot.time}`, slot));
    return [...unique.values()].sort((a,b) =>
        `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`));
}

function explainNoSlots(doctor) {
    const now = new Date();
    let hasScheduledTime = false;
    let futureSlots = 0;
    let conflictedSlots = 0;
    let cancelledSlots = 0;
    let bookedSlots = 0;

    for (const date of dateRange()) {
        const dateString = localDate(date);
        const dayOfWeek = ((date.getDay() + 6) % 7) + 1;
        const windows = doctorWindowsOnDate(doctor.doctorId, dateString, dayOfWeek);

        for (const window of windows) {
            const start = toMinutes(window.startTime);
            const end = toMinutes(window.endTime);
            const duration = Number(window.slotDuration);
            const capacity = Number(window.capacity);

            if (!Number.isFinite(start) || !Number.isFinite(end) ||
                !Number.isInteger(duration) || duration <= 0 ||
                !Number.isInteger(capacity) || capacity <= 0 || end <= start) continue;

            hasScheduledTime = true;

            for (let minute = start; minute + duration <= end; minute += duration) {
                const slotDate = new Date(date.getFullYear(), date.getMonth(),
                    date.getDate(), Math.floor(minute / 60), minute % 60);
                if (slotDate <= now) continue;
                futureSlots++;

                if (doctorTimeConflict(doctor.doctorId, dateString,
                    dayOfWeek, minute, minute + duration)) {
                    conflictedSlots++;
                } else if (isSlotCancelled(doctor.doctorId, dateString,
                    minute, minute + duration)) {
                    cancelledSlots++;
                } else if (isSlotBooked(doctor.doctorId, dateString,
                    minute, minute + duration, capacity)) {
                    bookedSlots++;
                }
            }
        }
    }

    if (!hasScheduledTime) return "Doctor is off duty on the selected date. Try Next 7 days.";
    if (!futureSlots) return "Today's appointment times have passed. Try Next 7 days.";
    if (conflictedSlots === futureSlots)
        return "The doctor's working hours overlap another doctor. Please ask clinic staff to adjust the schedule.";
    if (cancelledSlots + conflictedSlots === futureSlots)
        return "Doctor unavailable for these hours. Try Next 7 days.";
    if (bookedSlots + cancelledSlots + conflictedSlots >= futureSlots)
        return "All appointment times are booked or unavailable. Try Next 7 days.";
    return "No available times on the selected date. Try Next 7 days.";
}

function buildDoctorCards() {
    if (!practitionerList || !sqlBookingData) return;
    practitionerList.replaceChildren();
    const palettes = ["photo-lim", "photo-tan", "photo-wong"];

    sqlBookingData.doctors.forEach((doctor, index) => {
        const card = document.createElement("article");
        card.className = "practitioner-card";
        card.dataset.doctorId = doctor.doctorCode;

        const main = document.createElement("div");
        main.className = "practitioner-main";

        const avatar = document.createElement("div");
        avatar.className = `practitioner-photo ${palettes[index % palettes.length]}`;
        const words = doctor.name.replace(/^Dr\.?\s+/i, "").trim().split(/\s+/);
        const doctorInitials = (words.length > 1 ? words[0][0] + words[words.length - 1][0] :
            (words[0] || "DR").slice(0, 2)).toUpperCase();
        if (typeof doctor.photo === "string" && /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(doctor.photo)) {
            const picture = document.createElement("img");
            picture.className = "practitioner-profile-image";
            picture.src = doctor.photo;
            picture.alt = `${doctor.name} profile picture`;
            picture.onerror = () => { picture.remove(); avatar.textContent = doctorInitials; };
            avatar.appendChild(picture);
            avatar.dataset.photo = doctor.photo;
        } else {
            avatar.textContent = doctorInitials;
        }

        const details = document.createElement("div");
        details.className = "practitioner-details";
        const heading = document.createElement("h3");
        const doctorNameButton = document.createElement("button");
        doctorNameButton.type = "button";
        doctorNameButton.className = "doctor-name-trigger";
        doctorNameButton.textContent = doctor.name;
        doctorNameButton.title = `View ${doctor.name}'s practitioner details`;
        doctorNameButton.setAttribute("aria-label", `View details for ${doctor.name}`);
        heading.appendChild(doctorNameButton);
        const specialization = document.createElement("p");
        specialization.textContent = doctor.specialization || "TCM Practitioner";
        details.append(heading, specialization);

        const offeredServices = getDoctorServices(doctor);
        const serviceChoices = document.createElement("div");
        serviceChoices.className = "doctor-service-choices";
        serviceChoices.setAttribute("role", "group");
        serviceChoices.setAttribute("aria-label", `Choose a service with ${doctor.name}`);
        for (const service of offeredServices) {
            const tag = document.createElement("button");
            tag.type = "button";
            tag.className = "treatment-tag";
            tag.dataset.serviceId = String(service.serviceId);
            tag.dataset.serviceName = service.serviceName;
            tag.setAttribute("aria-pressed", "false");
            tag.textContent = service.serviceName;
            tag.title = `Select ${service.serviceName} with ${doctor.name}`;
            serviceChoices.append(tag);
        }
        if (!offeredServices.length) {
            const tag = document.createElement("span");
            tag.className = "treatment-tag unavailable";
            tag.textContent = "Services pending setup";
            serviceChoices.append(tag);
        }
        details.append(serviceChoices);
        if (offeredServices.length) {
            const prompt = document.createElement("p");
            prompt.className = "doctor-service-prompt";
            prompt.textContent = "Step 1: Choose a service above to view available times.";
            details.append(prompt);
        }

        // The avatar opens a photo preview; only the doctor's name opens details.
        avatar.setAttribute("role", "button");
        avatar.setAttribute("tabindex", "0");
        avatar.setAttribute("aria-label", `Enlarge picture of ${doctor.name}`);
        avatar.title = `Click to enlarge ${doctor.name}'s picture`;
        main.append(avatar, details);
        const slots = document.createElement("div");
        slots.className = "time-slots";
        card.append(main, slots);
        practitionerList.appendChild(card);
    });
}


/* Booking doctor avatars: click the picture to enlarge it (separate from doctor details). */
(() => {
    if (!practitionerList || window.__tcmBookingAvatarZoomInstalled) return;
    window.__tcmBookingAvatarZoomInstalled = true;

    const style = document.createElement("style");
    style.id = "tcm-booking-avatar-zoom-style";
    style.textContent = `
        .practitioner-list .practitioner-photo { cursor: zoom-in !important; }
        .practitioner-list .practitioner-photo:focus-visible,
        #doctorModalAvatar:focus-visible { outline: 3px solid #168079; outline-offset: 3px; }
        #tcm-booking-avatar-zoom { position: fixed; inset: 0; z-index: 2147483645;
            display: flex; justify-content: center; align-items: center;
            background: rgba(11, 34, 35, .76); padding: 20px; box-sizing: border-box; }
        #tcm-booking-avatar-zoom .zoom-panel { position: relative; background: #fff;
            color: #173d3c; border-radius: 20px; padding: 52px 22px 28px;
            box-sizing: border-box; width: min(420px, 100%);
            display: flex; flex-direction: column; align-items: center; gap: 18px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, .30); }
        #tcm-booking-avatar-zoom .zoom-close { position: absolute; top: 10px; right: 12px;
            border: 0; border-radius: 50%; background: #ebf3f0;
            width: 40px; height: 40px; color: #174e4b; cursor: pointer;
            font: normal 28px/1 system-ui, sans-serif; }
        #tcm-booking-avatar-zoom .zoom-picture { width: min(300px, 70vw, 48vh);
            height: min(300px, 70vw, 48vh); overflow: hidden; border-radius: 50%;
            background: #e2efec; display: flex; align-items: center; justify-content: center;
            color: #286967; font: 700 clamp(46px, 11vw, 94px)/1 system-ui, sans-serif; }
        #tcm-booking-avatar-zoom .zoom-picture img { width: 100%; height: 100%;
            object-fit: cover; display: block; }
        #tcm-booking-avatar-zoom .zoom-name { margin: 0; text-align: center;
            color: #173d3c; font: 700 18px/1.4 system-ui, sans-serif; }
    `;
    document.head.appendChild(style);

    let overlay = null;
    let focusedBefore = null;

    function closePreview() {
        if (!overlay) return;
        overlay.remove();
        overlay = null;
        if (focusedBefore?.isConnected) focusedBefore.focus({ preventScroll: true });
        focusedBefore = null;
    }

    function showPreview(avatar) {
        closePreview();
        const card = avatar.closest(".practitioner-card");
        const name = card?.querySelector(".doctor-name-trigger")?.textContent.trim() ||
            document.getElementById("doctorModalName")?.textContent.trim() || "Doctor";
        const img = avatar.querySelector("img.practitioner-profile-image, img");
        focusedBefore = document.activeElement;

        overlay = document.createElement("div");
        overlay.id = "tcm-booking-avatar-zoom";
        overlay.setAttribute("role", "dialog");
        overlay.setAttribute("aria-modal", "true");
        overlay.setAttribute("aria-label", `${name} enlarged picture`);

        const panel = document.createElement("div");
        panel.className = "zoom-panel";
        const close = document.createElement("button");
        close.type = "button";
        close.className = "zoom-close";
        close.setAttribute("aria-label", "Close picture preview");
        close.textContent = "×";
        const picture = document.createElement("div");
        picture.className = "zoom-picture";
        if (img?.src) {
            const enlarged = document.createElement("img");
            enlarged.src = img.src;
            enlarged.alt = `${name} profile picture`;
            enlarged.onerror = () => { picture.replaceChildren(); picture.textContent = avatar.textContent.trim() || "DR"; };
            picture.appendChild(enlarged);
        } else {
            picture.textContent = avatar.textContent.trim() || "DR";
        }
        const title = document.createElement("p");
        title.className = "zoom-name";
        title.textContent = name;
        panel.append(close, picture, title);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);

        close.addEventListener("click", closePreview);
        overlay.addEventListener("click", event => {
            if (event.target === overlay) closePreview();
        });
        close.focus({ preventScroll: true });
    }

    // Capture the avatar click before other booking/card or generic avatar handlers.
    document.addEventListener("click", event => {
        const target = event.target;
        if (!(target instanceof Element)) return;
        const avatar = target.closest(".practitioner-list .practitioner-photo");
        if (!avatar) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        showPreview(avatar);
    }, true);

    document.addEventListener("keydown", event => {
        if (overlay && event.key === "Escape") {
            event.preventDefault();
            event.stopImmediatePropagation();
            closePreview();
            return;
        }
        if (event.key !== "Enter" && event.key !== " ") return;
        const avatar = document.activeElement;
        if (!(avatar instanceof Element) || !avatar.matches(".practitioner-list .practitioner-photo")) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        showPreview(avatar);
    }, true);
})();

function buildServiceFilters() {
    if (!serviceFilterRow || !sqlBookingData) return;
    const activeServices = new Set(sqlBookingData.doctorServices.map(link => Number(link.serviceId)));
    const options = sqlBookingData.services.filter(service => activeServices.has(Number(service.serviceId)));
    const existing = String(selectedService);
    if (existing !== "all" && !options.some(service => String(service.serviceId) === existing)) selectedService = "all";

    serviceFilterRow.replaceChildren();
    const addButton = (value, label) => {
        const button = document.createElement("button");
        button.className = "filter-button" + (String(selectedService) === String(value) ? " active" : "");
        button.type = "button";
        button.dataset.service = String(value);
        button.textContent = label;
        serviceFilterRow.appendChild(button);
    };
    addButton("all", "All services");
    options.forEach(service => addButton(service.serviceId, service.serviceName));
}

function showBookingMessage(title, message) {
    if (!bookingSuccess || !bookingMessage) return;

    const heading = bookingSuccess.querySelector("strong");

    if (heading) {
        heading.textContent = title;
    }

    bookingMessage.textContent = message;
    bookingSuccess.classList.add("show");
}

function updatePractitionerList() {
    if (!noResults || !practitionerList) return;
    if (!sqlBookingData) {
        practitionerList.replaceChildren();
        noResults.textContent = bookingLoadError || "Loading doctor schedules...";
        noResults.classList.add("show");
        return;
    }

    // Guard against a doctor/service being removed while schedules refresh.
    if (selectedDoctorId !== null) {
        const selectedDoctor = sqlBookingData.doctors.find(doctor =>
            String(doctor.doctorCode) === String(selectedDoctorId));
        const valid = selectedDoctor && getDoctorServices(selectedDoctor).some(service =>
            String(service.serviceId) === String(selectedDoctorServiceId));
        if (!valid) {
            selectedDoctorId = null;
            selectedDoctorServiceId = null;
        }
    }

    const searchText = (doctorSearch?.value || "").trim().toLowerCase();
    const selectionNote = document.getElementById("serviceSelectionNote");
    const currentDoctor = sqlBookingData.doctors.find(doctor =>
        String(doctor.doctorCode) === String(selectedDoctorId));
    const currentService = sqlBookingData.services.find(service =>
        String(service.serviceId) === String(selectedDoctorServiceId));
    if (selectionNote) {
        selectionNote.textContent = currentDoctor && currentService
            ? `✓ ${currentService.serviceName} selected with ${currentDoctor.name}. Now choose ONE available time.`
            : "First select ONE service beside a doctor (✓). Only then can you choose an appointment time.";
    }

    let visibleCards = 0;
    practitionerList.querySelectorAll(".practitioner-card").forEach(card => {
        const doctor = getDoctor(card);
        const timeSlots = card.querySelector(".time-slots");
        if (!doctor || !timeSlots) return;
        const offeredServices = getDoctorServices(doctor);
        const serviceIds = offeredServices.map(service => String(service.serviceId));
        const serviceNames = offeredServices.map(service => service.serviceName);
        const matchesFilter = selectedService === "all" || serviceIds.includes(String(selectedService));
        const matchesSearch = `${doctor.name} ${doctor.specialization || ""} ${serviceNames.join(" ")}`
            .toLowerCase().includes(searchText);

        const isThisDoctorSelected = String(selectedDoctorId) === String(doctor.doctorCode);
        const hasSelectedService = isThisDoctorSelected && serviceIds.includes(String(selectedDoctorServiceId));
        card.classList.toggle("doctor-service-selected", hasSelectedService);

        card.querySelectorAll(".treatment-tag[data-service-id]").forEach(button => {
            const isSelected = hasSelectedService &&
                String(button.dataset.serviceId) === String(selectedDoctorServiceId);
            button.classList.toggle("active", isSelected);
            button.setAttribute("aria-pressed", String(isSelected));
            // Show the tick only on the chosen pill; never imply all services are selected.
            const label = button.dataset.serviceName || button.textContent.replace(/^✓\s*/, "").trim();
            button.textContent = `${isSelected ? "✓ " : ""}${label}`;
        });
        const prompt = card.querySelector(".doctor-service-prompt");
        if (prompt) prompt.textContent = hasSelectedService
            ? `✓ ${currentService?.serviceName || "Service"} chosen. Select one 30-minute time below.`
            : "Choose one service above first to show available times.";

        // Time buttons are not rendered unless a service is chosen on THIS doctor's card.
        timeSlots.hidden = !hasSelectedService;
        timeSlots.replaceChildren();
        if (hasSelectedService) {
            const slots = availableSlots(card);
            if (slots.length) {
                const list = document.createElement("div");
                list.className = "slot-list";
                const grouped = new Map();
                slots.forEach(slot => {
                    if (!grouped.has(slot.date)) grouped.set(slot.date, []);
                    grouped.get(slot.date).push(slot);
                });
                grouped.forEach((dateSlots, date) => {
                    const group = document.createElement("div");
                    group.className = "slot-group";
                    const label = document.createElement("strong");
                    label.className = "availability-date";
                    label.textContent = displayDate(date);
                    const buttons = document.createElement("div");
                    buttons.className = "slot-times";
                    dateSlots.forEach(slot => {
                        const button = document.createElement("button");
                        button.className = "time-button";
                        button.type = "button";
                        button.dataset.date = slot.date;
                        button.dataset.time = slot.time;
                        button.dataset.endTime = slot.endTime;
                        button.textContent = displayTime(slot.time);
                        buttons.appendChild(button);
                    });
                    group.append(label, buttons);
                    list.append(group);
                });
                timeSlots.append(list);
            } else {
                const message = document.createElement("strong");
                message.className = "doctor-no-slots";
                message.textContent = explainNoSlots(doctor);
                timeSlots.appendChild(message);
            }
        }
        const show = matchesFilter && matchesSearch;
        card.classList.toggle("hidden", !show);
        if (show) visibleCards++;
    });

    noResults.classList.remove("appointment-booked");
    noResults.textContent = "No doctors match this service or search.";
    noResults.classList.toggle("show", visibleCards === 0);
}

async function loadSQLBookingData() {
    if (bookingRequestInProgress) return;
    bookingRequestInProgress = true;
    try {
        const response = await fetch("/api/user/booking-data", {
            method: "GET", cache: "no-store", credentials: "same-origin"
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        if (data.status !== "success" || !Array.isArray(data.doctors) ||
            !Array.isArray(data.services) || !Array.isArray(data.doctorServices) ||
            !Array.isArray(data.schedules)) throw new Error("Invalid booking data received");

        bookingLoadError = "";
        const signature = JSON.stringify(data);
        if (signature !== lastBookingSignature) {
            lastBookingSignature = signature;
            sqlBookingData = data;
            buildServiceFilters();
            buildDoctorCards();
        } else {
            sqlBookingData = data;
        }
        updatePractitionerList();
    } catch (error) {
        bookingLoadError = "Unable to load doctor schedules. Please refresh.";
        if (!sqlBookingData) updatePractitionerList();
        console.error("SQL Booking Error:", error);
    } finally {
        bookingRequestInProgress = false;
    }
}

serviceFilterRow?.addEventListener("click", event => {
    const button = event.target.closest(".filter-button");
    if (!button) return;
    selectedService = button.dataset.service || "all";
    // Filtering alone must NEVER enable booking or mark a doctor's service as chosen.
    if (selectedService !== "all" && selectedDoctorServiceId !== null &&
        String(selectedDoctorServiceId) !== String(selectedService)) {
        selectedDoctorId = null;
        selectedDoctorServiceId = null;
    }
    serviceFilterRow.querySelectorAll(".filter-button").forEach(item =>
        item.classList.toggle("active", item === button));
    updatePractitionerList();
});

dayButtons.forEach((button) => {
    button.addEventListener("click", () => {
        dayButtons.forEach((item) => {
            item.classList.remove("active");
        });

        button.classList.add("active");

        selectedDay = button.dataset.day || "today";

        updatePractitionerList();
    });
});

doctorSearch?.addEventListener("input", updatePractitionerList);

document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
        loadSQLBookingData();
    }
});

function closeBookingConfirmation() {
    pendingBooking = null;

    bookingConfirmation?.classList.remove("show");
    bookingConfirmation?.setAttribute("aria-hidden", "true");
}

document.querySelectorAll("[data-close-booking-confirmation]")
    .forEach((element) => {
        element.addEventListener("click", closeBookingConfirmation);
    });

function closeAppointmentNotice() {
    appointmentNotice?.classList.remove("show");
    appointmentNotice?.setAttribute("aria-hidden", "true");
}

document.querySelectorAll("[data-close-appointment-notice]")
    .forEach((element) => {
        element.addEventListener("click", closeAppointmentNotice);
    });

document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;

    if (bookingConfirmation?.classList.contains("show")) {
        closeBookingConfirmation();
    }

    if (appointmentNotice?.classList.contains("show")) {
        closeAppointmentNotice();
    }
});

document.querySelector(".practitioner-list")
    ?.addEventListener("click", (event) => {
        const serviceButton = event.target.closest(".treatment-tag[data-service-id]");
        if (serviceButton) {
            // Do not let a service click also trigger the practitioner details modal.
            event.stopImmediatePropagation();
            const card = serviceButton.closest(".practitioner-card");
            const doctor = card && getDoctor(card);
            if (!doctor) return;
            const service = getDoctorServices(doctor).find(item =>
                String(item.serviceId) === serviceButton.dataset.serviceId);
            if (!service) return;

            // Single selection across doctor cards: choosing a different service
            // replaces the previous choice; clicking the same pill deselects it.
            const isSameChoice = String(selectedDoctorId) === String(doctor.doctorCode) &&
                String(selectedDoctorServiceId) === String(service.serviceId);
            selectedDoctorId = isSameChoice ? null : doctor.doctorCode;
            selectedDoctorServiceId = isSameChoice ? null : String(service.serviceId);
            // A discovery filter should never make the chosen doctor disappear.
            if (selectedDoctorServiceId !== null && selectedService !== "all" &&
                String(selectedService) !== String(selectedDoctorServiceId)) {
                selectedService = "all";
                serviceFilterRow?.querySelectorAll(".filter-button").forEach(filter =>
                    filter.classList.toggle("active", filter.dataset.service === "all"));
            }
            updatePractitionerList();
            return;
        }

        const button = event.target.closest(".time-button");

        if (!button) return;

        const card = button.closest(".practitioner-card");
        const doctor = card && getDoctor(card);

        if (!doctor) return;

        // Safety guard: even manually triggered clicks cannot book without choosing
        // a service for the specific doctor first.
        if (String(selectedDoctorId) !== String(doctor.doctorCode) ||
            selectedDoctorServiceId === null) {
            showBookingMessage("Choose a service first",
                "Select one service next to this doctor before choosing a time.");
            return;
        }

        const slot = availableSlots(card).find((item) =>
            item.date === button.dataset.date &&
            item.time === button.dataset.time
        );

        if (!slot) {
            showBookingMessage(
                "Time no longer available",
                "Please select another time."
            );

            updatePractitionerList();
            return;
        }

        const doctorServices = getDoctorServices(doctor);

        // One appointment = one explicitly chosen service and one time slot.
        const service = doctorServices.find(item =>
            String(item.serviceId) === String(selectedDoctorServiceId));

        if (!service) {
            showBookingMessage(
                "Service unavailable",
                "Please choose another service."
            );
            return;
        }

        pendingBooking = {
            doctorId: doctor.doctorId,
            doctor: doctor.name,
            serviceId: service.serviceId,
            service: service.serviceName,
            date: slot.date,
            time: slot.time,
            endTime: slot.endTime
        };

        if (confirmationDetails) {
            confirmationDetails.textContent =
                `${pendingBooking.service} · ` +
                `${displayDate(slot.date)} at ` +
                `${displayTime(slot.time)} · ${doctor.name}`;
        }

        bookingConfirmation?.classList.add("show");
        bookingConfirmation?.setAttribute("aria-hidden", "false");

        confirmBookingButton?.focus();
    });

confirmBookingButton?.addEventListener("click", async () => {
    if (!pendingBooking) return;

    const booking = { ...pendingBooking };

    const email = (
        sessionStorage.getItem("tcmPatientEmail") || ""
    ).trim();

    if (!email) {
        closeBookingConfirmation();

        showBookingMessage(
            "Please sign in to book",
            "Sign in to your patient account first."
        );

        return;
    }

    confirmBookingButton.disabled = true;

    try {
        const response = await fetch("/api/user/appointments", {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                doctorId: booking.doctorId,
                serviceId: booking.serviceId,
                appointmentDate: booking.date,
                startTime: booking.time,
                endTime: booking.endTime
            })
        });

        let result = {};

        try {
            result = await response.json();
        } catch {
            result = {};
        }

        if (!response.ok) {
            if (
                response.status === 404 ||
                response.status === 405
            ) {
                throw new Error(
                    "The appointment-saving API is not set up yet."
                );
            }

            throw new Error(
                typeof result.detail === "string"
                    ? result.detail
                    : `Booking failed (HTTP ${response.status}).`
            );
        }

        closeBookingConfirmation();

        showBookingMessage(
            "Appointment booked",
            `${booking.service} with ${booking.doctor} · ` +
            `${displayDate(booking.date)} at ` +
            `${displayTime(booking.time)}. Booking ID: APT-SQL-${result.appointmentId}. View it in My Appointments.`
        );
        window.dispatchEvent(new Event('tcm-appointment-updated'));
        selectedDoctorId = null;
        selectedDoctorServiceId = null;

        bookingSuccess?.scrollIntoView({
            behavior: "smooth",
            block: "nearest"
        });

        await loadSQLBookingData();

    } catch (error) {
        console.error("Appointment booking error:", error);

        closeBookingConfirmation();

        showBookingMessage(
            "Booking not saved",
            error.message
        );

    } finally {
        confirmBookingButton.disabled = false;
    }
});

document.getElementById("logoutButton")
    ?.addEventListener("click", () => {
        sessionStorage.removeItem("tcmPatientName");
        sessionStorage.removeItem("tcmPatientEmail");

        window.location.href = "login.html";
    });

document.getElementById("menuButton")
    ?.addEventListener("click", () => {
        document.querySelector(".sidebar")
            ?.classList.toggle("open");
    });

loadSQLBookingData();

setInterval(() => {
    if (!document.hidden) loadSQLBookingData();
}, 10000);
