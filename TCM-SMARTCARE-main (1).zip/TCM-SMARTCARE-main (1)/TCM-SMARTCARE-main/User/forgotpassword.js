const form = document.getElementById("recoveryForm");
const emailInput = document.getElementById("resetEmail");
const otpInput = document.getElementById("otpInput");
const requestButton = document.getElementById("requestOtpButton");
const verifyButton = document.getElementById("verifyButton");
const passwordSection = document.getElementById("newPasswordSection");
const newPasswordInput = document.getElementById("newPassword");
const confirmPasswordInput = document.getElementById("confirmPassword");
const resetButton = document.getElementById("resetButton");
const statusText = document.getElementById("recoveryStatus");
const otpDialog = document.getElementById("otpDialog");
const otpDisplay = document.getElementById("otpDisplay");
const countdown = document.getElementById("otpCountdown");
const verifiedMessage = document.getElementById("passwordVerifiedMessage");

let challengeId = "";
let challengeEmail = "";
let verifiedOtp = "";
let expiresAt = 0;
let verifiedUntil = 0;
let timerId = null;
let busy = false;

async function requestRecovery(action, payload) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), action === "reset" ? 20000 : 8000);
    try {
        const response = await fetch(`/api/user/password-recovery/${action}`, {
            method: "POST",
            credentials: "same-origin",
            cache: "no-store",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload),
            signal: controller.signal
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) {
            const error = new Error(typeof result.detail === "string" ? result.detail : "Request failed. Please try again.");
            error.status = response.status;
            throw error;
        }
        return result;
    } catch (error) {
        if (error.name === "AbortError") {
            throw new Error("The request took too long. Please check that the User Backend is running on port 8001.");
        }
        throw error;
    } finally {
        clearTimeout(timeout);
    }
}

function showStatus(message, error = false) {
    statusText.textContent = message;
    statusText.classList.toggle("is-error", error);
}

function showPasswordFields(enabled) {
    passwordSection.hidden = false;
    verifiedMessage.hidden = !enabled;
    newPasswordInput.disabled = !enabled;
    confirmPasswordInput.disabled = !enabled;
    resetButton.disabled = !enabled;
    if (!enabled) {
        newPasswordInput.value = "";
        confirmPasswordInput.value = "";
    }
}

function resetChallenge(message = "", error = false) {
    challengeId = "";
    challengeEmail = "";
    verifiedOtp = "";
    verifiedUntil = 0;
    expiresAt = 0;
    if (timerId !== null) {
        clearInterval(timerId);
        timerId = null;
    }
    otpInput.value = "";
    otpInput.readOnly = false;
    otpDisplay.textContent = "";
    verifyButton.disabled = true;
    showPasswordFields(false);
    if (otpDialog.open) otpDialog.close();
    showStatus(message, error);
}

function timeLeftSeconds() {
    return Math.max(0, Math.ceil((expiresAt - Date.now()) / 1000));
}

function stopCountdown() {
    if (timerId !== null) {
        clearInterval(timerId);
        timerId = null;
    }
}

function refreshCountdown() {
    if (!challengeId) return;
    const remaining = timeLeftSeconds();
    countdown.textContent = `${String(Math.floor(remaining / 60)).padStart(2, "0")}:${String(remaining % 60).padStart(2, "0")}`;
    if (remaining === 0) {
        if (verifiedOtp) {
            stopCountdown();
            return;
        }
        resetChallenge("OTP expired after 3 minutes. Click Get OTP to request a new code.", true);
    }
}

emailInput.addEventListener("input", () => resetChallenge());

requestButton.addEventListener("click", async () => {
    if (busy || !emailInput.reportValidity()) return;
    const email = emailInput.value.trim().toLowerCase();
    resetChallenge();
    busy = true;
    requestButton.disabled = true;
    showStatus("Generating OTP...");
    try {
        const result = await requestRecovery("start", {email});
        if (!result.challengeId || !/^\d{6}$/.test(String(result.otp))) {
            throw new Error("OTP response was incomplete. Restart the User Backend and refresh this page.");
        }
        challengeId = result.challengeId;
        challengeEmail = email;
        expiresAt = Date.now() + (Number(result.expiresIn) || 180) * 1000;
        otpDisplay.textContent = result.otp;
        verifyButton.disabled = false;
        refreshCountdown();
        timerId = setInterval(refreshCountdown, 250);
        showStatus("OTP created. Enter the 6-digit code below and click Verify OTP.");
        if (typeof otpDialog.showModal === "function") {
            otpDialog.showModal();
        } else {
            alert(`Your OTP Code: ${result.otp}\nValid for 3 minutes.`);
            otpInput.focus();
        }
    } catch (error) {
        resetChallenge(error.message, true);
    } finally {
        busy = false;
        requestButton.disabled = false;
    }
});

document.getElementById("fillOtpButton").addEventListener("click", () => {
    if (!challengeId || timeLeftSeconds() === 0) return;
    otpInput.value = otpDisplay.textContent.trim();
    otpDialog.close();
    otpInput.focus();
});

document.getElementById("closeOtpDialog").addEventListener("click", () => {
    otpDialog.close();
    otpInput.focus();
});

verifyButton.addEventListener("click", async () => {
    if (busy) return;
    if (!challengeId || challengeEmail !== emailInput.value.trim().toLowerCase() || timeLeftSeconds() === 0) {
        resetChallenge("OTP has expired or is missing. Click Get OTP again.", true);
        return;
    }
    if (!otpInput.reportValidity()) return;
    busy = true;
    verifyButton.disabled = true;
    showStatus("Verifying OTP...");
    try {
        const result = await requestRecovery("verify", {challengeId, otp: otpInput.value.trim()});
        if (result.verified !== true) {
            resetChallenge(result.message || "Incorrect or expired OTP. Click Get OTP to get another code.", true);
            otpInput.focus();
            return;
        }
        verifiedOtp = otpInput.value.trim();
        verifiedUntil = Date.now() + (Number(result.resetExpiresIn) || 600) * 1000;
        stopCountdown();
        if (otpDialog.open) otpDialog.close();
        otpInput.readOnly = true;
        showPasswordFields(true);
        showStatus("OTP verified. Set your new password below.");
        newPasswordInput.focus();
    } catch (error) {
        if (error.status === 400) {
            resetChallenge(error.message, true);
        } else {
            showStatus(error.message, true);
            verifyButton.disabled = false;
        }
    } finally {
        busy = false;
        if (!verifiedOtp) otpInput.readOnly = false;
    }
});

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (busy) return;
    if (!verifiedOtp || !challengeId || Date.now() >= verifiedUntil) {
        resetChallenge("OTP verification has expired. Please get a new OTP.", true);
        return;
    }
    const newPassword = newPasswordInput.value;
    const confirmPassword = confirmPasswordInput.value;
    if (newPassword !== confirmPassword) {
        showStatus("Passwords do not match.", true);
        return;
    }
    if (newPassword.length < 8 || (newPassword.match(/\d/g) || []).length < 4 || !/[A-Z]/.test(newPassword) || !/[^A-Za-z0-9]/.test(newPassword)) {
        showStatus("Use at least 8 characters, 4 numbers, 1 uppercase letter and 1 symbol.", true);
        return;
    }
    busy = true;
    resetButton.disabled = true;
    showStatus("Saving your new password...");
    try {
        const result = await requestRecovery("reset", {
            challengeId,
            otp: verifiedOtp,
            newPassword,
            confirmPassword
        });
        resetChallenge(result.message);
        emailInput.value = "";
        form.reset();
        showStatus("Password changed successfully. Use your new password to log in.");
        setTimeout(() => location.replace("login.html?reset=1"), 1000);
    } catch (error) {
        if (error.status === 400 || (error.status === 409 && /request a new OTP/i.test(error.message))) {
            resetChallenge(error.message, true);
        } else {
            showStatus(error.message, true);
            resetButton.disabled = false;
        }
    } finally {
        busy = false;
    }
});
