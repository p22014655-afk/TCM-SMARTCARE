(() => {
    const list = document.getElementById("historyList");
    const empty = document.getElementById("historyEmpty");
    const escape = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
    const money = amount => `RM ${Number(amount || 0).toFixed(2)}`;
    const formatDate = value => {
        if (!value) return "Not available";
        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString("en-MY", {year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});
    };
    const reviewKey = (id, name) => `${id}:${String(name).toLocaleLowerCase()}`;
    let loading = false;
    let reviewsByOrder = new Map();

    function productReview(order, item, index) {
        const key = reviewKey(order.orderId, item.name);
        const saved = reviewsByOrder.get(key);
        if (saved) {
            return `<div class="product-review-saved"><strong>${escape(item.name)}</strong><span class="review-stars-read">${"★".repeat(saved.rating)}${"☆".repeat(5 - saved.rating)}</span><p>${escape(saved.comment)}</p><small>${saved.hidden ? "This review is hidden by shop staff" : saved.editedByStaff ? "Edited by shop staff" : "Review submitted"}</small></div>`;
        }
        const groupId = `rating-${order.orderId}-${index}`;
        return `<form class="product-review-form" data-order-id="${order.orderId}" data-product-name="${escape(item.name)}">
            <strong>Review ${escape(item.name)}</strong>
            <fieldset class="review-star-fieldset"><legend>Your rating *</legend><div class="review-stars">
            ${[1,2,3,4,5].map(value => `<label title="${value} stars"><input type="radio" name="rating" value="${value}" aria-label="${value} stars" required><span aria-hidden="true">★</span></label>`).join("")}
            </div></fieldset>
            <label class="review-comment-label">Your review *<textarea name="comment" rows="3" required placeholder="Share your experience with this product..."></textarea></label>
            <div class="review-form-actions"><button type="submit">Submit Review</button><span class="review-form-message" role="status"></span></div>
        </form>`;
    }

    function orderCard(order, reviewOpen = false) {
        const card = document.createElement("article");
        card.className = "history-order";
        const details = order.fulfillmentMethod === "pickup"
            ? `Pickup: ${escape(order.pickupInfo?.date || "-")} at ${escape(order.pickupInfo?.time?.slice(0,5) || "-")}`
            : `Delivery to: ${escape(order.deliveryInfo?.recipientName || "")} · ${escape(order.deliveryInfo?.phoneNumber || "")} · ${escape([order.deliveryInfo?.address, order.deliveryInfo?.city, order.deliveryInfo?.state, order.deliveryInfo?.postcode].filter(Boolean).join(", "))}`;
        const items = (order.items || []).map(item => `<div class="history-item"><span class="history-item-name">${escape(item.name)} · Qty ${Number(item.quantity)}</span><span>${money(Number(item.quantity) * Number(item.price))}</span></div>`).join("");
        const events = (order.events || []).map(event => `<div class="order-event">${escape(event.message)}</div>`).join("");
        const cancelled = order.status === "Cancelled";
        const completed = order.status === "Completed";
        card.innerHTML = `
            <div class="history-order-header"><div><h3>Order ${escape(order.orderNumber)}</h3><p>Tracking ID: <strong>${escape(order.trackingId || "-")}</strong></p><p>${escape(formatDate(order.purchasedAt))}</p></div><span class="history-order-status ${cancelled ? "order-status-cancelled" : completed ? "order-status-completed" : ""}">${escape(order.status)}</span></div>
            <div class="history-items">${items}</div>
            <p class="history-payment-method">${details}</p>
            <p class="history-payment-method">Payment method: ${escape(order.paymentMethod || "Not recorded")}</p>
            <div class="history-order-footer"><span>Subtotal ${money(order.subtotal)} + Delivery ${money(order.deliveryFee)}</span><strong>Total: ${money(order.total)}</strong></div>
            ${completed ? '<div class="order-completed-banner">Order Completed! You can review the products you received.</div>' : ""}
            ${cancelled ? '<div class="order-cancelled-banner">Order Cancelled. This order is no longer active, and its receipt is unavailable.</div>' : `<p><a class="receipt-history-link" href="/api/user/orders/${encodeURIComponent(order.orderId)}/receipt">Download E-Receipt (PDF)</a></p>`}
            ${completed ? `<details class="order-review-section" data-order-id="${escape(order.orderId)}"${reviewOpen ? " open" : ""}>
                <summary class="order-review-toggle">
                    <span class="order-review-title">Rate your products</span>
                    <span class="order-review-toggle-action"><span class="review-show">Show</span><span class="review-hide">Hide</span> reviews <span class="order-review-arrow" aria-hidden="true">⌄</span></span>
                </summary>
                <div class="order-review-body">${(order.items || []).map((item, index) => productReview(order,item,index)).join("")}<p><a href="reviews.html">View all product reviews</a></p></div>
            </details>` : ""}
            <div class="order-events">${events}</div>
        `;
        return card;
    }

    async function refresh() {
        if (loading || document.activeElement?.closest("#historyList .product-review-form")) return;
        loading = true;
        try {
            const [orderResponse, reviewResponse] = await Promise.all([
                fetch("/api/user/orders", {credentials:"same-origin",cache:"no-store"}),
                fetch("/api/user/reviews/mine", {credentials:"same-origin",cache:"no-store"})
            ]);
            const orders = await orderResponse.json();
            if (!orderResponse.ok) throw new Error(typeof orders.detail === "string" ? orders.detail : "Cannot load orders.");
            const myReviews = reviewResponse.ok ? await reviewResponse.json() : {reviews:[]};
            reviewsByOrder = new Map((myReviews.reviews || []).map(review => [reviewKey(review.orderId, review.productName), review]));
            // Keep each order's review section open/closed when orders refresh automatically.
            const openReviewOrders = new Set(Array.from(
                list.querySelectorAll("details.order-review-section[open]"),
                section => section.dataset.orderId
            ));
            list.replaceChildren();
            empty.hidden = orders.orders.length > 0;
            for (const order of orders.orders) {
                list.appendChild(orderCard(order, openReviewOrders.has(String(order.orderId))));
            }
        } catch (error) {
            empty.hidden = true;
            list.replaceChildren();
            const p = document.createElement("p");
            p.textContent = error.message + " Please log in to your patient account.";
            list.append(p);
        } finally {
            loading = false;
        }
    }

    list.addEventListener("submit", async event => {
        const form = event.target.closest(".product-review-form");
        if (!form) return;
        event.preventDefault();
        if (!form.reportValidity()) return;
        const orderId = Number(form.dataset.orderId);
        const productName = form.dataset.productName;
        const rating = Number(new FormData(form).get("rating"));
        const comment = String(new FormData(form).get("comment") || "").trim();
        const button = form.querySelector('button[type="submit"]');
        const message = form.querySelector(".review-form-message");
        button.disabled = true;
        message.textContent = "Submitting...";
        try {
            const response = await fetch(`/api/user/orders/${orderId}/reviews`, {
                method:"POST", credentials:"same-origin",
                headers:{"Content-Type":"application/json"},
                body:JSON.stringify({productName,rating,comment})
            });
            const result = await response.json();
            if (!response.ok) throw new Error(typeof result.detail === "string" ? result.detail : "Unable to submit review.");
            document.activeElement?.blur();
            await refresh();
        } catch (error) {
            message.textContent = error.message;
            button.disabled = false;
        }
    });

    document.getElementById("menuButton")?.addEventListener("click", () => document.querySelector(".sidebar")?.classList.toggle("open"));
    refresh();
    setInterval(refresh, 20000);
    window.addEventListener("focus", refresh);
})();
