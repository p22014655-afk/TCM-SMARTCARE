(() => {
    const grid = document.querySelector(".products");
    const searchInput = document.getElementById("search");
    const filters = [...document.querySelectorAll(".filters button")];
    const cartCount = document.getElementById("cartCount");
    const emptyMessage = document.getElementById("emptyMessage");
    const cartKey = "tcmCart";
    let selectedCategory = "all";
    let products = [];
    let loading = false;
    let lastProductSignature = null;

    function escapeHtml(text) {
        return String(text ?? "").replace(/[&<>"']/g, character => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
        })[character]);
    }

    function categoryGroup(category) {
        const value = String(category || "").toLowerCase();
        if (value.includes("tea")) return "tea";
        if (value.includes("supplement") || value.includes("vitamin")) return "supplements";
        if (value.includes("care") || value.includes("wellness") || value.includes("balm")) return "care";
        return "herbs";
    }

    function readCart() {
        try {
            const stored = JSON.parse(localStorage.getItem(cartKey) || "[]");
            return Array.isArray(stored) ? stored : [];
        } catch {
            return [];
        }
    }

    function updateCartCount() {
        if (cartCount) {
            cartCount.textContent = String(readCart().reduce(
                (total, item) => total + (Number(item.quantity) || 0), 0
            ));
        }
    }

    function saveCart(items) {
        try {
            localStorage.setItem(cartKey, JSON.stringify(items));
            updateCartCount();
            return true;
        } catch {
            alert("Unable to save your cart.");
            return false;
        }
    }

    function filterProducts() {
        const query = String(searchInput?.value || "").trim().toLowerCase();
        let count = 0;
        grid.querySelectorAll(".product").forEach(card => {
            const categoryMatch = selectedCategory === "all" || card.dataset.category === selectedCategory;
            const queryMatch = !query || card.dataset.search.includes(query);
            card.hidden = !(categoryMatch && queryMatch);
            if (!card.hidden) count += 1;
        });
        if (emptyMessage) {
            emptyMessage.hidden = count > 0;
            emptyMessage.textContent = "No products match your search.";
        }
    }

    function ratingMarkup(product) {
        const count = Math.max(0, Number(product.reviewCount) || 0);
        const average = Math.min(5, Math.max(0, Number(product.averageRating) || 0));
        const width = `${average * 20}%`;
        const label = count
            ? `${average.toFixed(1)} out of 5 stars from ${count} reviews`
            : "No customer reviews yet";
        const details = count
            ? `${average.toFixed(1)} / 5 · ${count} review${count === 1 ? "" : "s"}`
            : "No reviews yet";
        return `
            <div class="shop-rating" aria-label="${label}">
                <span class="shop-rating-stars" aria-hidden="true">
                    <span class="shop-rating-back">★★★★★</span>
                    <span class="shop-rating-front" style="width:${width}">★★★★★</span>
                </span>
                <span class="shop-rating-label">${details}</span>
            </div>
        `;
    }

    function renderProducts(catalog) {
        products = catalog;
        grid.replaceChildren();
        for (const product of catalog) {
            const article = document.createElement("article");
            article.className = "product";
            article.dataset.category = categoryGroup(product.category);
            article.dataset.search = [
                product.name, product.category, product.description,
                product.ingredients, product.instructions, product.precautions
            ].filter(Boolean).join(" ").toLowerCase();
            const inStock = Number(product.stock) > 0;
            const photo = String(product.image || "");
            const safePhoto = /^data:image\/(png|jpeg|webp|gif);base64,/i.test(photo) || /^https:\/\//i.test(photo);
            const photoHtml = safePhoto
                ? `<img class="product-icon product-photo" alt="${escapeHtml(product.name)}" src="${escapeHtml(photo)}">`
                : `<div class="product-icon" aria-hidden="true">草本</div>`;
            const descriptions = [
                ["Description", product.description],
                ["Ingredients", product.ingredients],
                ["Instructions", product.instructions],
                ["Precautions", product.precautions]
            ].filter(([, text]) => text);
            const details = descriptions.length
                ? `<details><summary>View product details</summary>${descriptions.map(
                    ([label, text]) => `<div class="product-detail"><strong>${label}</strong><p>${escapeHtml(text)}</p></div>`
                ).join("")}</details>`
                : "";
            article.innerHTML = `
                ${photoHtml}
                <small>${escapeHtml(product.category || "Herbal ingredients")}</small>
                <h3>${escapeHtml(product.name)}</h3>
                ${ratingMarkup(product)}
                <p>${escapeHtml(product.description || "")}</p>
                ${details}
                <p class="shop-review-link"><a href="reviews.html?productId=${encodeURIComponent(String(product.id || ""))}&amp;productName=${encodeURIComponent(String(product.name || ""))}">★ Read customer reviews</a></p>
                <p class="shop-stock">${inStock ? `In stock: ${Number(product.stock)}` : "Out of Stock"}</p>
                <div class="product-buy">
                    <strong>RM ${Number(product.price).toFixed(2)}</strong>
                    <div class="product-actions">
                        <div class="quantity-picker">
                            <button class="quantity-minus" type="button" aria-label="Decrease quantity" ${inStock ? "" : "disabled"}>−</button>
                            <span class="quantity-value">1</span>
                            <button class="quantity-plus" type="button" aria-label="Increase quantity" ${inStock ? "" : "disabled"}>+</button>
                        </div>
                        <button class="add-button" type="button" ${inStock ? "" : "disabled"}>${inStock ? "Add to cart" : "Out of Stock"}</button>
                    </div>
                </div>
            `;
            const number = article.querySelector(".quantity-value");
            const decrease = article.querySelector(".quantity-minus");
            const increase = article.querySelector(".quantity-plus");
            const add = article.querySelector(".add-button");
            decrease.addEventListener("click", () => {
                number.textContent = String(Math.max(1, Number(number.textContent) - 1));
            });
            increase.addEventListener("click", () => {
                number.textContent = String(Math.min(99, Number(product.stock), Number(number.textContent) + 1));
            });
            add.addEventListener("click", () => {
                const cart = readCart();
                const count = Number(number.textContent);
                const existing = cart.find(item => String(item.name).toLowerCase() === String(product.name).toLowerCase());
                const current = existing ? Number(existing.quantity) : 0;
                if (current + count > Number(product.stock)) {
                    alert(`Only ${product.stock} units available for ${product.name}.`);
                    return;
                }
                if (existing) {
                    existing.quantity = current + count;
                    existing.price = Number(product.price);
                } else {
                    cart.push({name: product.name, price: Number(product.price), quantity: count});
                }
                if (!saveCart(cart)) return;
                add.textContent = "Added ✓";
                add.disabled = true;
                setTimeout(() => {
                    add.textContent = "Add to cart";
                    add.disabled = false;
                }, 750);
            });
            grid.append(article);
        }
        filterProducts();
    }

    async function refreshProducts() {
        if (loading) return;
        loading = true;
        try {
            const response = await fetch("/api/user/products", {
                cache: "no-store",
                credentials: "same-origin"
            });
            const result = await response.json();
            if (!response.ok || !Array.isArray(result.products)) {
                throw new Error(result.detail || "Unable to load products from SQL Server.");
            }
            const signature = JSON.stringify(result.products);
            if (signature !== lastProductSignature) {
                renderProducts(result.products);
                lastProductSignature = signature;
            }
        } catch (error) {
            lastProductSignature = null;
            grid.replaceChildren();
            emptyMessage.hidden = false;
            emptyMessage.textContent = error.message;
        } finally {
            loading = false;
        }
    }

    const headerCart = document.querySelector(".topbar .cart-link");
    if (headerCart && !document.querySelector(".history-link")) {
        const history = document.createElement("a");
        history.className = "cart-link history-link";
        history.href = "history.html";
        history.textContent = "Purchase history";
        headerCart.insertAdjacentElement("afterend", history);
    }

    filters.forEach(button => button.addEventListener("click", () => {
        filters.forEach(item => item.classList.remove("active"));
        button.classList.add("active");
        selectedCategory = button.dataset.filter || "all";
        filterProducts();
    }));
    searchInput?.addEventListener("input", filterProducts);
    document.getElementById("menuButton")?.addEventListener("click", () => {
        document.querySelector(".sidebar")?.classList.toggle("open");
    });
    document.getElementById("logoutButton")?.addEventListener("click", () => {
        fetch("/api/user/logout", {method: "POST", credentials: "same-origin"}).finally(() => {
            sessionStorage.removeItem("tcmPatientName");
            sessionStorage.removeItem("tcmPatientEmail");
            window.location.href = "login.html";
        });
    });
    window.addEventListener("storage", updateCartCount);
    window.addEventListener("focus", refreshProducts);
    window.addEventListener("pageshow", refreshProducts);
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) refreshProducts();
    });
    setInterval(() => {
        if (!document.hidden) refreshProducts();
    }, 5000);
    updateCartCount();
    refreshProducts();
})();
