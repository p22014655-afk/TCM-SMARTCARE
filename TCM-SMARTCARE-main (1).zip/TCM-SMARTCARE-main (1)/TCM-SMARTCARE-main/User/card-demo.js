(() => {
    const key = "tcmPendingPayment";
    const form = document.getElementById("cardDemoForm");
    const button = document.getElementById("cardDemoButton");
    const status = document.getElementById("cardDemoStatus");
    const success = document.getElementById("cardDemoSuccess");
    let pending;
    try {
        pending = JSON.parse(sessionStorage.getItem(key) || "null");
    } catch {
        pending = null;
    }
    if (!pending || pending.paymentMethod !== "card") {
        document.querySelector(".card-demo-panel").innerHTML = '<h2>No card demo is in progress</h2><p><a href="payment.html">Return to payment options</a></p>';
        return;
    }
    document.getElementById("cardDemoTotal").textContent = `RM ${Number(pending.total).toFixed(2)}`;
    form.addEventListener("submit", async event => {
        event.preventDefault();
        status.textContent = "";
        button.disabled = true;
        button.textContent = "Processing payment...";
        try {
            const response = await fetch("/api/user/orders", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "same-origin",
                body: JSON.stringify(pending)
            });
            const result = await response.json();
            if (!response.ok) throw new Error(typeof result.detail === "string" ? result.detail : "Unable to save order.");
            const order = result.order;
            localStorage.removeItem("tcmCart");
            sessionStorage.removeItem(key);
            localStorage.setItem("tcmLastOrder", JSON.stringify(order));
            document.getElementById("cardDemoSuccessMessage").textContent = `Order ${order.orderNumber} saved. Tracking ID: ${order.trackingId}. Total: RM ${Number(order.total).toFixed(2)}. Payment simulated; no real charge.`;
            const receipt = document.getElementById("receiptDownload");
            receipt.href = `/api/user/orders/${encodeURIComponent(order.orderId)}/receipt`;
            receipt.hidden = false;
            sessionStorage.removeItem("tcmCheckoutReference");
            form.remove();
            success.hidden = false;
            success.style.display = "block";

        } catch (error) {
            status.textContent = error.message;
            button.disabled = false;
            button.textContent = "Confirm payment";
        }
    });
    document.getElementById("menuButton")?.addEventListener("click", () => document.querySelector(".sidebar")?.classList.toggle("open"));
})();
