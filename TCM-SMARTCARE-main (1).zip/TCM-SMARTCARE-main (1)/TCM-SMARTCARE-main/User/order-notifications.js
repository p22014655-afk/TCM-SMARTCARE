(() => {
    let busy = false;
    let initialized = false;
    const seenPrefix = "tcmSeenOrderEvent:";

    function toast(message) {
        const card = document.createElement("aside");
        card.setAttribute("role", "status");
        card.style.cssText = "position:fixed;right:20px;top:20px;z-index:99999;width:min(370px,calc(100vw - 40px));padding:18px 20px;background:#e7f5ed;border:1px solid #77b99a;border-left:5px solid #25815a;border-radius:12px;color:#164b33;box-shadow:0 10px 30px #0002;font:600 14px/1.6 Arial,sans-serif";
        const messageNode = document.createElement("div");
        messageNode.textContent = message;
        const close = document.createElement("button");
        close.textContent = "×";
        close.setAttribute("aria-label", "Dismiss notification");
        close.style.cssText = "float:right;border:0;background:transparent;font-size:20px;cursor:pointer;margin-left:10px";
        close.addEventListener("click", () => card.remove());
        card.append(close, messageNode);
        document.body.append(card);
    }

    async function check() {
        if (busy) return;
        busy = true;
        try {
            const response = await fetch("/api/user/orders", {credentials:"same-origin",cache:"no-store"});
            if (!response.ok) return;
            const result = await response.json();
            for (const order of result.orders || []) {
                const alertEvents = (order.events || []).filter(event => ["Completed", "Cancelled"].includes(event.status));
                for (const event of alertEvents) {
                    const key = `${seenPrefix}${order.buyer?.email || "patient"}:${order.orderId}`;
                    const oldValue = Number(localStorage.getItem(key) || 0);
                    if (Number(event.eventId) > oldValue) {
                        localStorage.setItem(key, String(event.eventId));
                        toast(`${order.trackingId}: ${event.message}`);
                    }
                }
            }
        } catch {
        } finally {
            busy = false;
            initialized = true;
        }
    }

    check();
    setInterval(check, 25000);
    window.addEventListener("focus", check);
})();
