(() => {
    const list = document.getElementById("conversationList");
    const search = document.getElementById("conversationSearch");
    const messages = document.getElementById("chatMessages");
    const chatName = document.getElementById("chatName");
    const chatStatus = document.getElementById("chatStatus");
    const chatAvatar = document.getElementById("chatAvatar");
    const form = document.getElementById("messageForm");
    const input = document.getElementById("messageInput");
    const sendButton = form.querySelector('button[type="submit"]');
    let threads = [];
    let activeId = "care-team";
    let opened = null;
    let busy = false;
    let initial = true;
    const params = new URLSearchParams(location.search);
    const requestedDoctor = params.get("doctor");
    const escape = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));

    function initials(name) {
        return String(name || "TC").trim().split(/\s+/).slice(0, 2).map(part => part[0] || "").join("").toUpperCase();
    }

    function setAvatar(node, person) {
        const photo = String(person.photo || "");
        const name = String(person.name || "Care Team");
        node.replaceChildren();
        node.setAttribute("aria-label", `${name} profile picture`);
        if (/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(photo)) {
            const image = document.createElement("img");
            image.src = photo;
            image.alt = `${name} profile picture`;
            image.loading = "lazy";
            image.onerror = () => {node.replaceChildren(); node.textContent = initials(name);};
            node.append(image);
        } else {
            node.textContent = initials(name);
        }
    }

    function timeLabel(value) {
        if (!value) return "";
        const valueDate = new Date(value);
        return Number.isNaN(valueDate.getTime()) ? "" : valueDate.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
    }

    function showError(text) {
        let banner = document.getElementById("messagesError");
        if (!banner) {
            banner = document.createElement("p");
            banner.id = "messagesError";
            banner.className = "messages-alert";
            document.querySelector(".chat-panel").insertBefore(banner, messages);
        }
        banner.textContent = text;
        banner.hidden = !text;
    }

    async function request(path, options = {}) {
        const response = await fetch(path, {credentials:"same-origin",cache:"no-store",...options});
        const raw = await response.text();
        let payload;
        try {
            payload = JSON.parse(raw);
        } catch {
            throw new Error(`Messages server returned an invalid response (HTTP ${response.status}).`);
        }
        if (!response.ok) throw new Error(typeof payload.detail === "string" ? payload.detail : `Request failed (HTTP ${response.status}).`);
        return payload;
    }

    function renderThreads() {
        const phrase = search.value.trim().toLocaleLowerCase();
        list.replaceChildren();
        for (const thread of threads.filter(item => (item.name + " " + item.lastMessage).toLocaleLowerCase().includes(phrase))) {
            const button = document.createElement("button");
            button.className = "conversation-item" + (activeId === thread.id ? " active" : "");
            button.type = "button";
            const avatar = document.createElement("span");
            avatar.className = "conversation-avatar";
            setAvatar(avatar, thread);
            const summary = document.createElement("span");
            summary.className = "conversation-summary";
            const title = document.createElement("strong");
            title.textContent = thread.name;
            const description = document.createElement("span");
            description.className = "message-preview";
            description.textContent = thread.lastMessage || thread.subtitle;
            summary.append(title, description);
            const info = document.createElement("span");
            info.className = "conversation-meta";
            const lastTime = document.createElement("span");
            lastTime.textContent = timeLabel(thread.lastAt);
            const unread = document.createElement("span");
            unread.className = "unread-count";
            unread.textContent = thread.unread ? String(thread.unread) : "";
            info.append(lastTime, unread);
            button.append(avatar, summary, info);
            button.addEventListener("click", () => {void openThread(thread.id);});
            list.append(button);
        }
        if (!list.children.length) {
            const empty = document.createElement("p");
            empty.className = "empty-state";
            empty.textContent = "No conversations found.";
            list.append(empty);
        }
    }

    function renderMessages() {
        messages.replaceChildren();
        if (!opened) return;
        chatName.textContent = opened.name;
        chatStatus.textContent = opened.subtitle;
        setAvatar(chatAvatar, opened);
        const date = document.createElement("div");
        date.className = "message-date";
        date.textContent = "Recent messages";
        messages.append(date);
        for (const item of opened.messages) {
            const bubble = document.createElement("article");
            bubble.className = "message " + (item.from === "patient" ? "outgoing" : "incoming");
            const text = document.createElement("div");
            text.textContent = item.text;
            const time = document.createElement("time");
            time.textContent = timeLabel(item.createdAt);
            bubble.append(text, time);
            messages.append(bubble);
        }
        if (!opened.messages.length) {
            const empty = document.createElement("p");
            empty.className = "empty-state";
            empty.textContent = opened.id === "care-team" ? "Ask the Care Team about appointments or general assistance." : "You can message this doctor because you have completed an appointment with them.";
            messages.append(empty);
        }
        messages.scrollTop = messages.scrollHeight;
    }

    async function openThread(id, quiet = false) {
        if (!threads.some(thread => thread.id === id)) return;
        activeId = id;
        renderThreads();
        try {
            const result = await request(`/api/user/messages/threads/${encodeURIComponent(id)}`);
            if (activeId !== id) return;
            opened = result;
            showError("");
            const thread = threads.find(item => item.id === id);
            if (thread) thread.unread = 0;
            renderThreads();
            renderMessages();
        } catch (error) {
            if (!quiet) showError(error.message);
        }
    }

    async function refresh(quiet = false) {
        try {
            const result = await request("/api/user/messages/threads");
            threads = Array.isArray(result.threads) ? result.threads : [];
            if (initial && requestedDoctor && threads.some(item => item.id === `doctor-${requestedDoctor}`)) {
                activeId = `doctor-${requestedDoctor}`;
            } else if (!threads.some(item => item.id === activeId)) {
                activeId = "care-team";
            }
            initial = false;
            renderThreads();
            if (activeId && !busy) await openThread(activeId, quiet);
        } catch (error) {
            if (!quiet) showError(error.message);
        }
    }

    form.addEventListener("submit", async event => {
        event.preventDefault();
        const text = input.value.trim();
        if (!text || !activeId || busy) return;
        busy = true;
        sendButton.disabled = true;
        try {
            await request(`/api/user/messages/threads/${encodeURIComponent(activeId)}`, {
                method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text})
            });
            input.value = "";
            showError("");
            const current = await request("/api/user/messages/threads");
            threads = Array.isArray(current.threads) ? current.threads : [];
            renderThreads();
            await openThread(activeId);
        } catch (error) {
            showError(error.message);
        } finally {
            busy = false;
            sendButton.disabled = false;
        }
    });

    search.addEventListener("input", renderThreads);
    document.getElementById("menuButton")?.addEventListener("click", () => document.querySelector(".sidebar")?.classList.toggle("open"));
    document.getElementById("logoutButton")?.addEventListener("click", () => {location.href = "login.html";});
    try {
        const profile = JSON.parse(localStorage.getItem("tcmPatientProfile") || "{}");
        if (profile.fullName) document.getElementById("headerName").textContent = profile.fullName;
        if (profile.photo) {
            const avatar = document.getElementById("headerAvatar");
            avatar.textContent = "";
            avatar.style.backgroundImage = `url(${JSON.stringify(profile.photo)})`;
            avatar.style.backgroundSize = "cover";
            avatar.style.backgroundPosition = "center";
        }
    } catch {}
    void refresh();
    window.setInterval(() => { if (!document.hidden && !busy && !input.value.trim()) void refresh(true); }, 10000);
    window.addEventListener("focus", () => {if (!busy && !input.value.trim()) void refresh(true);});
})();
