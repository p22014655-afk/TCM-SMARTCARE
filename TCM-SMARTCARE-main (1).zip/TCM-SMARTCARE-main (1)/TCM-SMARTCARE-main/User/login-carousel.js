(() => {
    document.querySelectorAll("[data-auto-carousel]").forEach(carousel => {
        const slides = [...carousel.querySelectorAll("[data-carousel-slide]")];
        const dots = [...carousel.querySelectorAll("[data-carousel-dot]")];
        const previous = carousel.querySelector("[data-carousel-prev]");
        const next = carousel.querySelector("[data-carousel-next]");
        if (slides.length < 2) return;
        let current = Math.max(0, slides.findIndex(slide => slide.classList.contains("is-active")));
        let timer;
        const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        function show(index) {
            current = (index + slides.length) % slides.length;
            slides.forEach((slide, i) => {
                const active = i === current;
                slide.classList.toggle("is-active", active);
                slide.setAttribute("aria-hidden", String(!active));
            });
            dots.forEach((dot, i) => {
                const active = i === current;
                dot.classList.toggle("is-active", active);
                dot.setAttribute("aria-pressed", String(active));
                dot.setAttribute("aria-selected", String(active));
            });
        }
        function stop() {
            if (timer) clearInterval(timer);
            timer = undefined;
        }
        function start() {
            stop();
            if (!reducedMotion && !document.hidden) timer = setInterval(() => show(current + 1), 5000);
        }
        previous?.addEventListener("click", () => { show(current - 1); start(); });
        next?.addEventListener("click", () => { show(current + 1); start(); });
        dots.forEach((dot, i) => dot.addEventListener("click", () => { show(i); start(); }));
        carousel.addEventListener("mouseenter", stop);
        carousel.addEventListener("mouseleave", start);
        carousel.addEventListener("focusin", stop);
        carousel.addEventListener("focusout", event => { if (!carousel.contains(event.relatedTarget)) start(); });
        document.addEventListener("visibilitychange", () => document.hidden ? stop() : start());
        show(current);
        start();
    });
})();
