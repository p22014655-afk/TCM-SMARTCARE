// The patient's overview reflects the same SQL Server appointments as My Appointments.
(() => {
    const panel = document.querySelector('.appointment-panel .appointment-detail');
    if (!panel) return;
    const footer = document.querySelector('.appointment-panel .appointment-footer');
    const detailLink = '<a href="appointments.html">View details / manage appointment</a>';
    const escape = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    const dateDisplay = (value) => {
        const parts = String(value).split('-').map(Number);
        const date = new Date(parts[0],parts[1]-1,parts[2]);
        return [String(parts[2]).padStart(2,'0'), date.toLocaleDateString('en',{month:'short'}).toUpperCase(),date.toLocaleDateString('en',{weekday:'short'}).toUpperCase()];
    };
    const timeDisplay = (value) => {
        const [h,m] = String(value).split(':').map(Number);
        return `${h%12||12}:${String(m).padStart(2,'0')} ${h>=12?'PM':'AM'}`;
    };
    async function refresh() {
        try {
            const response = await fetch('/api/user/appointments', {credentials:'same-origin',cache:'no-store'});
            if (!response.ok) throw new Error('Appointments unavailable');
            const {appointments=[]} = await response.json();
            const today = new Date();
            const here = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
            const count = document.getElementById('upcomingAppointmentCount');
            if (count) count.textContent = appointments.filter(item =>
                item.date >= here && ['Scheduled','Rescheduled','Checked In','In Consultation'].includes(item.status)
            ).length;
            const appointment = appointments
                .filter(item=>item.date>=here && ['Scheduled','Rescheduled','Checked In','In Consultation'].includes(item.status))
                .sort((a,b)=>(a.date+' '+a.time).localeCompare(b.date+' '+b.time))[0];
            if (!appointment) {
                panel.textContent = 'No upcoming appointment. Choose Book appointment to find a time.';
                if (footer) footer.innerHTML = detailLink;
                return;
            }
            const [day,month,weekday] = dateDisplay(appointment.date);
            panel.innerHTML = `<div class="date-block"><strong>${day}</strong><span>${month}</span><small>${weekday}</small></div>
            <div class="doctor-info"><div class="doctor-avatar">✚</div><div><h3>${escape(appointment.doctor)}</h3>
            <p>${escape(appointment.service)} · ${escape(appointment.status)}</p>
            <span>◷ ${timeDisplay(appointment.time)} – ${timeDisplay(appointment.endTime)} · ${escape(appointment.id)}</span></div></div>`;
            if (footer) footer.innerHTML = `<span>⌖ TCM Smartcare+ Clinic, Penang</span><div>${detailLink}</div>`;
        } catch (error) {
            panel.textContent = 'Could not load your upcoming appointment from SQL Server.';
            if (footer) footer.innerHTML = detailLink;
        }
    }
    window.addEventListener('focus', refresh);
    window.addEventListener('tcm-appointment-updated', refresh);
    refresh();
})();
